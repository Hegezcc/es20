-- All In One WP Security & Firewall 4.4.4
-- MySQL dump
-- 2020-08-07 08:52:20

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `answers`;

CREATE TABLE `answers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `answer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fill_id` bigint(20) unsigned NOT NULL,
  `question_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `answers_fill_id_foreign` (`fill_id`),
  KEY `answers_question_id_foreign` (`question_id`),
  CONSTRAINT `answers_fill_id_foreign` FOREIGN KEY (`fill_id`) REFERENCES `fills` (`id`) ON DELETE CASCADE,
  CONSTRAINT `answers_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `answers` VALUES("1","ebin","1","6");
INSERT INTO `answers` VALUES("2","ebin","2","6");
INSERT INTO `answers` VALUES("3","asdf","3","4");
INSERT INTO `answers` VALUES("4","asdf","3","5");
INSERT INTO `answers` VALUES("5","Aika jees","4","1");
INSERT INTO `answers` VALUES("6","ei","4","2");
INSERT INTO `answers` VALUES("7","13","4","3");
INSERT INTO `answers` VALUES("8","Aika jees","5","1");
INSERT INTO `answers` VALUES("9","ei","5","2");
INSERT INTO `answers` VALUES("10","2322","5","3");
INSERT INTO `answers` VALUES("11","Juuh elikkäs","6","1");
INSERT INTO `answers` VALUES("12","kyllä","6","2");
INSERT INTO `answers` VALUES("13","22","6","3");


DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `role` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

INSERT INTO `employees` VALUES("1","Billy Tucker","bill@ittech.com","M","CEO");
INSERT INTO `employees` VALUES("2","Jeanette White","white@ittech.com","F","Designer");
INSERT INTO `employees` VALUES("3","Natalie Lambert","lambert@ittech.com","F","Front End Develloper");
INSERT INTO `employees` VALUES("4","Yolanda Wright","yolanda@ittech.com","F","Back End Develloper");
INSERT INTO `employees` VALUES("5","Jennifer Moran","moran@ittech.com","F","Designer");
INSERT INTO `employees` VALUES("6","Taylor Wood","taylorwood@ittech.com","M","Programmer");
INSERT INTO `employees` VALUES("7","Loretta Bowen","bowen@ittech.com","F","Test Analist");
INSERT INTO `employees` VALUES("8","Allan Ellis","allanellis@ittech.com","M","Programmer");
INSERT INTO `employees` VALUES("9","Alan Fowler","fowler@ittech.com","M","PHP Develloper");
INSERT INTO `employees` VALUES("10","Martin Hopkins","hopkins@gmail.com","M","Intern");
INSERT INTO `employees` VALUES("11","Jonathan Barnes","jbarnes@ittech.com","M","Javascript Develloper");
INSERT INTO `employees` VALUES("12","Ellis Stone","ellis.stone@ittech.com","F","Programmer");
INSERT INTO `employees` VALUES("13","Adam Elliott Jr.","adamjr@ittech.com","M","System Analist");
INSERT INTO `employees` VALUES("14","Gail Fernandez","fernandez@ittech.com","F","Human Resources");
INSERT INTO `employees` VALUES("15","Christina Parker","parker@ittech.com","F","Human Resources");
INSERT INTO `employees` VALUES("16","Shelia Green","green@ittech.com","F","Designer");
INSERT INTO `employees` VALUES("17","Megan Davis","megandavis@ittech.com","F","Programmer");
INSERT INTO `employees` VALUES("18","Cary Hammond ","cary@ittech.com","F","Intern");
INSERT INTO `employees` VALUES("19","Stacy Wallace","wallace@ittech.com","M","Art Director");
INSERT INTO `employees` VALUES("20","Derek Perkins","perkins@ittech.com","M","Engenieer");
INSERT INTO `employees` VALUES("21","Terrance Scott Williams","scottwilliams@ittech.com","M","Intern");
INSERT INTO `employees` VALUES("22","Lena Adams","lenaadams@ittech.com","F","Develloper");
INSERT INTO `employees` VALUES("23","Sue Roberson","sroberson@ittech.com","F","Designer");
INSERT INTO `employees` VALUES("24","Lowell Simpson","simpson@ittech.com","F","Engenieer");
INSERT INTO `employees` VALUES("25","Belinda Singleton","singleton@ittech.com","F","Intern");
INSERT INTO `employees` VALUES("26","Owen Burke","burke@ittech.com","M","System Analist");
INSERT INTO `employees` VALUES("27","Santos Keller","santos@ittech.com","M","Programmer");
INSERT INTO `employees` VALUES("28","Marcelo Strehl","marcelo.strehl@al.senai.br","M","Board Director");
INSERT INTO `employees` VALUES("29","Dewey Ross","ross@ittech.com","F","Board Director");
INSERT INTO `employees` VALUES("30","Nina Wong","ninawong@ittech.com","F","Manager Acount");
INSERT INTO `employees` VALUES("31","Verna Hoffman","vernahoff@gmail.com","F","Intern");
INSERT INTO `employees` VALUES("32","Jeffrey Love","love@ittech.com","M","Programmer");
INSERT INTO `employees` VALUES("33","Emilio Johnston","emilio@ittech.com","M","Programmer");
INSERT INTO `employees` VALUES("34","Eula Myers","eula@ittech.com","F","Programmer");
INSERT INTO `employees` VALUES("35","Eleanor Craig","ecraig@ittech.com","F","Database analist");
INSERT INTO `employees` VALUES("36","Harvey Williams ","harley@ittech.com","M","Information Analist");
INSERT INTO `employees` VALUES("37","Chelsea Gill ","chelseagill@gmail.com","F","Board Director");
INSERT INTO `employees` VALUES("38","Emma Roberts","emmaroberts@ittech.com","F","Database Analist");
INSERT INTO `employees` VALUES("39","Dallas Grant","dallas@ittech.com","M","System Analist");
INSERT INTO `employees` VALUES("40","Marian Hicks","mhicks@gmail.com","F","Programmer");


DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `fills`;

CREATE TABLE `fills` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `survey_id` bigint(20) unsigned NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fills_survey_id_foreign` (`survey_id`),
  KEY `fills_employee_id_foreign` (`employee_id`),
  CONSTRAINT `fills_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fills_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fills` VALUES("1","2020-08-06 12:54:58","2020-08-06 12:54:58","::1","3","");
INSERT INTO `fills` VALUES("2","2020-08-06 12:55:10","2020-08-06 12:55:10","::1","3","");
INSERT INTO `fills` VALUES("3","2020-08-06 12:55:44","2020-08-06 12:55:44","::1","2","");
INSERT INTO `fills` VALUES("4","2020-08-06 12:56:19","2020-08-06 12:56:19","::1","1","");
INSERT INTO `fills` VALUES("5","2020-08-06 13:15:10","2020-08-06 13:15:10","::1","1","");
INSERT INTO `fills` VALUES("6","2020-08-06 13:15:17","2020-08-06 13:15:17","::1","1","");


DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES("1","2019_08_19_000000_create_failed_jobs_table","1");
INSERT INTO `migrations` VALUES("2","2020_08_06_061959_import_db_dump","1");
INSERT INTO `migrations` VALUES("3","2020_08_06_062740_create_surveys_table","1");
INSERT INTO `migrations` VALUES("4","2020_08_06_062753_create_questions_table","1");
INSERT INTO `migrations` VALUES("5","2020_08_06_062806_create_fills_table","1");
INSERT INTO `migrations` VALUES("6","2020_08_06_062847_create_answers_table","1");
INSERT INTO `migrations` VALUES("7","2020_08_06_065150_create_survey_accesses_table","1");


DROP TABLE IF EXISTS `partners`;

CREATE TABLE `partners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `partners` VALUES("1","Microsoft","USA");
INSERT INTO `partners` VALUES("2","Google","USA");
INSERT INTO `partners` VALUES("3","SENAI","Brazil");
INSERT INTO `partners` VALUES("4","Teraki","Japan");
INSERT INTO `partners` VALUES("5","Toyota","Japan");
INSERT INTO `partners` VALUES("6","Oracle","USA");
INSERT INTO `partners` VALUES("7","Mozilla Foundation","USA");
INSERT INTO `partners` VALUES("8","Ford","USA");
INSERT INTO `partners` VALUES("9","Spotify","Sweden");
INSERT INTO `partners` VALUES("10","Honda","Japan");


DROP TABLE IF EXISTS `partners_employees`;

CREATE TABLE `partners_employees` (
  `employees_id` int(11) NOT NULL,
  `partners_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `role` varchar(50) NOT NULL,
  KEY `employees_id` (`employees_id`),
  KEY `partners_id` (`partners_id`),
  CONSTRAINT `partners_employees_ibfk_1` FOREIGN KEY (`employees_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `partners_employees_ibfk_2` FOREIGN KEY (`partners_id`) REFERENCES `partners` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `partners_employees` VALUES("2","4","2010-10-26","","Designer");
INSERT INTO `partners_employees` VALUES("3","8","2012-03-25","","Front End Develloper");
INSERT INTO `partners_employees` VALUES("4","6","2011-12-26","","Back End Develloper");
INSERT INTO `partners_employees` VALUES("5","1","2012-04-17","","Designer");
INSERT INTO `partners_employees` VALUES("6","1","2011-06-03","","Programmer");
INSERT INTO `partners_employees` VALUES("7","3","2012-02-18","","Test Analist");
INSERT INTO `partners_employees` VALUES("8","9","2011-08-23","","Programmer");
INSERT INTO `partners_employees` VALUES("9","10","2011-01-22","","PHP Develloper");
INSERT INTO `partners_employees` VALUES("10","3","2010-11-04","","Intern");
INSERT INTO `partners_employees` VALUES("11","6","2010-11-24","","Javascript Develloper");
INSERT INTO `partners_employees` VALUES("12","6","2011-03-30","","Programmer");
INSERT INTO `partners_employees` VALUES("13","6","2010-10-20","","System Analist");
INSERT INTO `partners_employees` VALUES("14","7","2011-11-25","","Human Resources");
INSERT INTO `partners_employees` VALUES("15","4","2011-09-03","","Human Resources");
INSERT INTO `partners_employees` VALUES("16","5","2010-11-09","","Designer");
INSERT INTO `partners_employees` VALUES("17","6","2011-09-11","","Programmer");
INSERT INTO `partners_employees` VALUES("18","4","2010-06-29","","Intern");
INSERT INTO `partners_employees` VALUES("19","7","2011-09-21","","Art Director");
INSERT INTO `partners_employees` VALUES("20","2","2010-08-22","","Engenieer");
INSERT INTO `partners_employees` VALUES("21","1","2011-03-30","","Intern");
INSERT INTO `partners_employees` VALUES("22","5","2011-10-21","","Develloper");
INSERT INTO `partners_employees` VALUES("23","6","2010-08-28","","Designer");
INSERT INTO `partners_employees` VALUES("24","2","2010-07-19","","Engenieer");
INSERT INTO `partners_employees` VALUES("25","8","2012-01-09","","Intern");
INSERT INTO `partners_employees` VALUES("26","10","2010-05-23","","System Analist");
INSERT INTO `partners_employees` VALUES("27","8","2011-10-27","","Programmer");
INSERT INTO `partners_employees` VALUES("28","4","2012-01-30","","Board Director");
INSERT INTO `partners_employees` VALUES("29","8","2011-11-21","","Board Director");
INSERT INTO `partners_employees` VALUES("30","9","2011-12-14","","Manager Acount");
INSERT INTO `partners_employees` VALUES("31","8","2011-04-13","","Intern");
INSERT INTO `partners_employees` VALUES("32","1","2010-10-12","","Programmer");
INSERT INTO `partners_employees` VALUES("33","4","2011-01-30","","Programmer");
INSERT INTO `partners_employees` VALUES("34","6","2010-05-11","","Programmer");
INSERT INTO `partners_employees` VALUES("35","9","2011-11-29","","Database analist");
INSERT INTO `partners_employees` VALUES("36","3","2010-08-20","","Information Analist");
INSERT INTO `partners_employees` VALUES("37","1","2010-10-21","","Board Director");
INSERT INTO `partners_employees` VALUES("38","1","2011-03-31","","Database Analist");
INSERT INTO `partners_employees` VALUES("39","1","2010-08-28","","System Analist");
INSERT INTO `partners_employees` VALUES("40","7","2011-03-04","","Programmer");


DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `survey_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `questions_survey_id_foreign` (`survey_id`),
  CONSTRAINT `questions_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `questions` VALUES("1","Hyvä kyssäri","text","","1");
INSERT INTO `questions` VALUES("2","Jooh","option","kyllä|ei","1");
INSERT INTO `questions` VALUES("3","Montako","number","","1");
INSERT INTO `questions` VALUES("4","Tekstikysymys","text","","2");
INSERT INTO `questions` VALUES("5","Kyllä vai ei?","option","test|asdf","2");
INSERT INTO `questions` VALUES("6","Hyvä kyssäri sieltä","text","","3");
INSERT INTO `questions` VALUES("7","Hyvä kyssäri","text","","4");


DROP TABLE IF EXISTS `survey_accesses`;

CREATE TABLE `survey_accesses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` bigint(20) unsigned NOT NULL,
  `employee_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `survey_accesses_survey_id_foreign` (`survey_id`),
  KEY `survey_accesses_employee_id_foreign` (`employee_id`),
  CONSTRAINT `survey_accesses_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_accesses_survey_id_foreign` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `survey_accesses` VALUES("1","1","16");
INSERT INTO `survey_accesses` VALUES("2","1","22");
INSERT INTO `survey_accesses` VALUES("3","1","26");
INSERT INTO `survey_accesses` VALUES("4","2","6");
INSERT INTO `survey_accesses` VALUES("5","2","17");
INSERT INTO `survey_accesses` VALUES("6","4","16");
INSERT INTO `survey_accesses` VALUES("7","4","25");
INSERT INTO `survey_accesses` VALUES("8","4","35");


DROP TABLE IF EXISTS `surveys`;

CREATE TABLE `surveys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `identification` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `surveys_identification_unique` (`identification`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `surveys` VALUES("1","asdf","asdf","restricted","2020-07-30","2020-08-29","identti","$2y$10$pAb9ufwNt9YeK6f7HhjlS.iUgEzz9I9sLJu5NRbdh8ApPuK.OFrZK","public/smxmgUlBs99yvleoi8ewjTjpr5KoHBXfM6oiCUzw.png");
INSERT INTO `surveys` VALUES("2","jooh","asdf","restricted","2020-07-30","2020-08-28","asdf","$2y$10$JoNtpOWOKACSlyEA/IwEd.L51cmKpADntF2jBsogSe9UUi1Zt2O9S","public/PSoyRmwAgrBhvueXMIFS7bIzh3m7MCyRdrJQlQoq.png");
INSERT INTO `surveys` VALUES("3","Testi","","public","2020-08-02","2020-08-28","asdf2","$2y$10$d5V8jM4x9IK3qikhg1nobemdF7rofpeOGiOK3hj3uMeE3jBO.FDY6","public/vNhxSLX5kt6DZWCEnTUvnOJ4SqIuDH3xaH0Axthp.jpeg");
INSERT INTO `surveys` VALUES("4","Testi","asdfjsaiodfj","restricted","2020-08-05","2020-08-25","testi","$2y$10$eyWKcq3cahCP7DoD07B9e.cOiw0TQwKjnC9kMcmNFkoyMpWIuNzs6","");


DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_comments` VALUES("1","1","A WordPress Commenter","wapuu@wordpress.example","https://wordpress.org/","","2020-08-07 06:09:39","2020-08-07 06:09:39","Hi, this is a comment.
To get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.
Commenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.","0","1","","","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_nextend2_image_storage`;

CREATE TABLE `wp_nextend2_image_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_nextend2_image_storage` VALUES("1","7b364d56418a8fa6de0480e463c0c92b","$upload$/slider2/Bild_08.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("2","496d9856112c84a58aea0d99e762e6ab","$upload$/slider2/Bild_07.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("3","9fb8f096257a686499df014ff87556a2","$upload$/slider2/Bild_09.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("4","b4a1a6e4161c58755c83e623356f8af4","$upload$/slider2/Bild_06.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("5","cffb2037fb24347e821d62ab116650a9","$upload$/slider2/Bild_04.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("6","5163aab8f8c9d961dfe793e5d48ee092","$upload$/slider2/Bild_12.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("7","f3e7e80d596e408dcb8996f67a6fb0db","$upload$/slider2/Bild_05.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("8","e9d4b4feff7b700b4bf0c32c7637b70f","$upload$/slider2/Bild_13.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("9","0c52b7a4c2b9facc7bdff7dfda97cee8","$upload$/slider2/Bild_15.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("10","6a04d9a17042035b4c16524099884391","$upload$/slider2/Bild_16.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("11","e33f2029a96148c5018e923bf82dc737","$upload$/slider2/Bild_17.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("12","22b227167e1a39be24594af64ddd8e21","$upload$/slider2/Bild_14.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("13","85665efb4558d8b7bde56a1a373f60a0","$upload$/slider2/Bild_10.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("14","e45758114d8880c9f94a636fda96f585","$upload$/slider2/Bild_18.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("15","5c6b27a32664fcd9e584158f256149fd","$upload$/slider2/Bild_11.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("16","46b6246a61ef930c3aeb2955f60f00a0","$upload$/slider2/Bild_19.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("17","8ce74b1cb7161bfd4c9e076967266968","$upload$/slider2/Bild_22.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("18","11afb8d6f828897ff262fc53dc8f062f","$upload$/slider2/Bild_20.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("19","7868f63c8f5e90fef718f9e2eb8a0130","$upload$/slider2/Bild_24.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("20","9c76a685205030bf7c5495523a54e3eb","$upload$/slider2/Bild_23.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("21","4ec0ab76bbb77a6e97225da477a0d235","$upload$/slider2/Bild_25.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("22","407dfdb62c95d5bc3e12dffce6e27aa6","$upload$/slider2/Bild_27.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("23","4cd9073f3329e8057df03013411816c0","$upload$/slider2/Bild_28.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("24","a7e756d591f82d3f58c04fd21eb9cb80","$upload$/slider2/Bild_29.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("25","6d3907cf42cf233b0a6f040110b61c52","$upload$/slider2/Bild_21.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("26","777226e7708553850c3a1a54bbeed54b","$upload$/slider2/Bild_31.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("27","2d244644732f69b35cb72918dbcb59a2","$upload$/slider2/Bild_26.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("28","2c9bbcf1e3bb3ec017be5470fde379e5","$upload$/slider2/Bild_02.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("29","6a6b7a1477933352ac09bee9c778aa09","$upload$/slider2/Bild_03.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("30","7457a5a44ba519e470fd780ec8cf5673","$upload$/slider2/Bild_01.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");
INSERT INTO `wp_nextend2_image_storage` VALUES("31","7188096f9ac5085e75e2a26e400aa488","$upload$/slider2/Bild_30.jpeg","eyJkZXNrdG9wIjp7InNpemUiOiIwfCp8MCJ9LCJkZXNrdG9wLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJ0YWJsZXQiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwidGFibGV0LXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9LCJtb2JpbGUiOnsiaW1hZ2UiOiIiLCJzaXplIjoiMHwqfDAifSwibW9iaWxlLXJldGluYSI6eyJpbWFnZSI6IiIsInNpemUiOiIwfCp8MCJ9fQ==");


DROP TABLE IF EXISTS `wp_nextend2_section_storage`;

CREATE TABLE `wp_nextend2_section_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencekey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `system` int(11) NOT NULL DEFAULT '0',
  `editable` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `system` (`system`),
  KEY `editable` (`editable`),
  KEY `application` (`application`,`section`(50),`referencekey`(50)),
  KEY `application_2` (`application`,`section`(50))
) ENGINE=InnoDB AUTO_INCREMENT=10090 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_nextend2_section_storage` VALUES("10000","smartslider","settings","","{\"n2_ss3_version\":\"3.4.1.8\\/b:release-3.4.1.8\\/r:70fceec40b0e84027a126b8c6fc9c014dc33808d\"}","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10001","smartslider","tutorial","GettingStarted","1","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10067","smartslider","sliderChanged","1","1","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10068","smartslider","sliderChanged","0","1","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10069","smartslider","sliderChanged","2","0","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10086","cache","notweb/n2-ss-2","data.manifest","{\"generator\":[]}","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10087","cache","notweb/n2-ss-2","variations.manifest","1","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10088","cache","notweb/n2-ss-2","slideren_US1.manifest","{\"hash\":\"\",\"nextCacheRefresh\":2145916800,\"currentPath\":\"6dd4b94d51919b35e6e68de3073981aa\",\"version\":\"3.4.1.8\"}","0","1");
INSERT INTO `wp_nextend2_section_storage` VALUES("10089","cache","notweb/n2-ss-2","slideren_US1","{\"html\":\"<div class=\\\"n2-section-smartslider fitvidsignore  n2_clear\\\" role=\\\"region\\\" aria-label=\\\"Slider\\\"><style>div#n2-ss-2{width:960px;}div#n2-ss-2 .n2-ss-slider-1{position:relative;}div#n2-ss-2 .n2-ss-slider-background-video-container{position:absolute;left:0;top:0;width:100%;height:100%;overflow:hidden;}div#n2-ss-2 .n2-ss-slider-2{position:relative;overflow:hidden;padding:0px 0px 0px 0px;height:480px;border:0px solid RGBA(62,62,62,1);border-radius:0px;background-clip:padding-box;background-repeat:repeat;background-position:50% 50%;background-size:cover;background-attachment:scroll;}div#n2-ss-2.n2-ss-mobileLandscape .n2-ss-slider-2,div#n2-ss-2.n2-ss-mobilePortrait .n2-ss-slider-2{background-attachment:scroll;}div#n2-ss-2 .n2-ss-slider-3{position:relative;width:100%;height:100%;overflow:hidden;outline:1px solid rgba(0,0,0,0);z-index:10;}div#n2-ss-2 .n2-ss-slide-backgrounds,div#n2-ss-2 .n2-ss-slider-3 > .n-particles-js-canvas-el,div#n2-ss-2 .n2-ss-slider-3 > .n2-ss-divider{position:absolute;left:0;top:0;width:100%;height:100%;}div#n2-ss-2 .n2-ss-slide-backgrounds{z-index:10;}div#n2-ss-2 .n2-ss-slider-3 > .n-particles-js-canvas-el{z-index:12;}div#n2-ss-2 .n2-ss-slide-backgrounds > *{overflow:hidden;}div#n2-ss-2 .n2-ss-slide{position:absolute;top:0;left:0;width:100%;height:100%;z-index:20;display:block;-webkit-backface-visibility:hidden;}div#n2-ss-2 .n2-ss-layers-container{position:relative;width:960px;height:480px;}div#n2-ss-2 .n2-ss-parallax-clip > .n2-ss-layers-container{position:absolute;right:0;}div#n2-ss-2 .n2-ss-slide{perspective:1500px;}div#n2-ss-2[data-ie] .n2-ss-slide{perspective:none;transform:perspective(1500px);}div#n2-ss-2 .n2-ss-slide-active{z-index:21;}div#n2-ss-2 .nextend-arrow{cursor:pointer;overflow:hidden;line-height:0 !important;z-index:20;}div#n2-ss-2 .nextend-arrow img{position:relative;min-height:0;min-width:0;vertical-align:top;width:auto;height:auto;max-width:100%;max-height:100%;display:inline;}div#n2-ss-2 .nextend-arrow img.n2-arrow-hover-img{display:none;}div#n2-ss-2 .nextend-arrow:HOVER img.n2-arrow-hover-img{display:inline;}div#n2-ss-2 .nextend-arrow:HOVER img.n2-arrow-normal-img{display:none;}div#n2-ss-2 .nextend-arrow-animated{overflow:hidden;}div#n2-ss-2 .nextend-arrow-animated > div{position:relative;}div#n2-ss-2 .nextend-arrow-animated .n2-active{position:absolute;}div#n2-ss-2 .nextend-arrow-animated-fade{transition:background 0.3s, opacity 0.4s;}div#n2-ss-2 .nextend-arrow-animated-horizontal > div{transition:all 0.4s;left:0;}div#n2-ss-2 .nextend-arrow-animated-horizontal .n2-active{top:0;}div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal:HOVER > div,div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal:FOCUS > div,div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal .n2-active{left:-100%;}div#n2-ss-2 .nextend-arrow-previous.nextend-arrow-animated-horizontal .n2-active,div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal:HOVER > div,div#n2-ss-2 .nextend-arrow-next.nextend-arrow-animated-horizontal:FOCUS > div{left:100%;}div#n2-ss-2 .nextend-arrow.nextend-arrow-animated-horizontal:HOVER .n2-active,div#n2-ss-2 .nextend-arrow.nextend-arrow-animated-horizontal:FOCUS .n2-active{left:0;}div#n2-ss-2 .nextend-arrow-animated-vertical > div{transition:all 0.4s;top:0;}div#n2-ss-2 .nextend-arrow-animated-vertical .n2-active{left:0;}div#n2-ss-2 .nextend-arrow-animated-vertical .n2-active{top:-100%;}div#n2-ss-2 .nextend-arrow-animated-vertical:HOVER > div,div#n2-ss-2 .nextend-arrow-animated-vertical:FOCUS > div{top:100%;}div#n2-ss-2 .nextend-arrow-animated-vertical:HOVER .n2-active,div#n2-ss-2 .nextend-arrow-animated-vertical:FOCUS .n2-active{top:0;}<\\/style><div id=\\\"n2-ss-2-align\\\" class=\\\"n2-ss-align\\\"><div class=\\\"n2-padding\\\"><template id=\\\"n2-ss-2\\\" data-loading-type=\\\"afterOnLoad\\\"><div id=\\\"n2-ss-2\\\" data-creator=\\\"Smart Slider 3\\\" class=\\\"n2-ss-slider n2-ow n2-has-hover n2notransition  n2-ss-load-fade \\\" style=\\\"font-size: 1rem;\\\" data-fontsize=\\\"16\\\">\\n        <div class=\\\"n2-ss-slider-1 n2_ss__touch_element n2-ow\\\" style=\\\"\\\">\\n            <div class=\\\"n2-ss-slider-2 n2-ow\\\" style=\\\"\\\">\\n                                                <div class=\\\"n2-ss-slider-3 n2-ow\\\" style=\\\"\\\">\\n\\n                    <div class=\\\"n2-ss-slide-backgrounds\\\"><\\/div><div data-first=\\\"1\\\" data-slide-duration=\\\"0\\\" data-id=\\\"3\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-3\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"7b364d56418a8fa6de0480e463c0c92b\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_08.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"4\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-4\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"496d9856112c84a58aea0d99e762e6ab\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_07.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"5\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-5\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"9fb8f096257a686499df014ff87556a2\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_09.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"6\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-6\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"b4a1a6e4161c58755c83e623356f8af4\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_06.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"7\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-7\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"cffb2037fb24347e821d62ab116650a9\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_04.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"8\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-8\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"5163aab8f8c9d961dfe793e5d48ee092\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_12.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"9\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-9\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"f3e7e80d596e408dcb8996f67a6fb0db\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_05.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"10\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-10\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"e9d4b4feff7b700b4bf0c32c7637b70f\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_13.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"11\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-11\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"0c52b7a4c2b9facc7bdff7dfda97cee8\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_15.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"12\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-12\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"6a04d9a17042035b4c16524099884391\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_16.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"13\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-13\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"e33f2029a96148c5018e923bf82dc737\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_17.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"14\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-14\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"22b227167e1a39be24594af64ddd8e21\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_14.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"15\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-15\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"85665efb4558d8b7bde56a1a373f60a0\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_10.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"16\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-16\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"e45758114d8880c9f94a636fda96f585\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_18.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"17\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-17\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"5c6b27a32664fcd9e584158f256149fd\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_11.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"18\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-18\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"46b6246a61ef930c3aeb2955f60f00a0\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_19.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"19\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-19\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"8ce74b1cb7161bfd4c9e076967266968\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_22.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"20\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-20\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"11afb8d6f828897ff262fc53dc8f062f\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_20.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"21\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-21\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"7868f63c8f5e90fef718f9e2eb8a0130\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_24.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"22\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-22\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"9c76a685205030bf7c5495523a54e3eb\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_23.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"23\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-23\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"4ec0ab76bbb77a6e97225da477a0d235\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_25.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"24\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-24\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"407dfdb62c95d5bc3e12dffce6e27aa6\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_27.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"25\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-25\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"4cd9073f3329e8057df03013411816c0\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_28.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"26\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-26\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"a7e756d591f82d3f58c04fd21eb9cb80\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_29.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"27\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-27\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"6d3907cf42cf233b0a6f040110b61c52\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_21.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"28\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-28\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"777226e7708553850c3a1a54bbeed54b\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_31.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"29\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-29\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"2d244644732f69b35cb72918dbcb59a2\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_26.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"30\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-30\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"2c9bbcf1e3bb3ec017be5470fde379e5\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_02.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"31\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-31\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"6a6b7a1477933352ac09bee9c778aa09\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_03.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"32\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-32\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"7457a5a44ba519e470fd780ec8cf5673\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_01.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div><div data-slide-duration=\\\"0\\\" data-id=\\\"33\\\" style=\\\"\\\" class=\\\" n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-33\\\"><div class=\\\"n2-ss-slide-background n2-ow\\\" data-mode=\\\"blurfit\\\"><div data-hash=\\\"7188096f9ac5085e75e2a26e400aa488\\\" data-desktop=\\\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_30.jpeg\\\" class=\\\"n2-ss-slide-background-image\\\" data-blur=\\\"0\\\" data-alt=\\\"\\\" data-title=\\\"\\\"><\\/div><\\/div><div class=\\\"n2-ss-layers-container n2-ow\\\"><div class=\\\"n2-ss-layer n2-ow\\\" style=\\\"padding:10px 10px 10px 10px;\\\" data-desktopportraitpadding=\\\"10|*|10|*|10|*|10\\\" data-sstype=\\\"slide\\\" data-csstextalign=\\\"center\\\" data-pm=\\\"default\\\"><\\/div><\\/div><\\/div>                <\\/div>\\n            <\\/div>\\n            <div data-ssleft=\\\"0+15\\\" data-sstop=\\\"sliderHeight\\/2-previousheight\\/2\\\" id=\\\"n2-ss-2-arrow-previous\\\" class=\\\"n2-ss-widget n2-ss-widget-display-hover nextend-arrow n2-ow nextend-arrow-previous  nextend-arrow-animated-fade n2-ib\\\" style=\\\"position: absolute;\\\" role=\\\"button\\\" aria-label=\\\"previous arrow\\\" tabindex=\\\"0\\\"><img class=\\\"n2-ow\\\" data-no-lazy=\\\"1\\\" data-hack=\\\"data-lazy-src\\\" src=\\\"data:image\\/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxwYXRoIGQ9Ik0xMS40MzMgMTUuOTkyTDIyLjY5IDUuNzEyYy4zOTMtLjM5LjM5My0xLjAzIDAtMS40Mi0uMzkzLS4zOS0xLjAzLS4zOS0xLjQyMyAwbC0xMS45OCAxMC45NGMtLjIxLjIxLS4zLjQ5LS4yODUuNzYtLjAxNS4yOC4wNzUuNTYuMjg0Ljc3bDExLjk4IDEwLjk0Yy4zOTMuMzkgMS4wMy4zOSAxLjQyNCAwIC4zOTMtLjQuMzkzLTEuMDMgMC0xLjQybC0xMS4yNTctMTAuMjkiCiAgICAgICAgICBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjgiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPgo8L3N2Zz4=\\\" alt=\\\"previous arrow\\\" \\/><\\/div>\\n<div data-ssright=\\\"0+15\\\" data-sstop=\\\"sliderHeight\\/2-nextheight\\/2\\\" id=\\\"n2-ss-2-arrow-next\\\" class=\\\"n2-ss-widget n2-ss-widget-display-hover nextend-arrow n2-ow nextend-arrow-next  nextend-arrow-animated-fade n2-ib\\\" style=\\\"position: absolute;\\\" role=\\\"button\\\" aria-label=\\\"next arrow\\\" tabindex=\\\"0\\\"><img class=\\\"n2-ow\\\" data-no-lazy=\\\"1\\\" data-hack=\\\"data-lazy-src\\\" src=\\\"data:image\\/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxwYXRoIGQ9Ik0xMC43MjIgNC4yOTNjLS4zOTQtLjM5LTEuMDMyLS4zOS0xLjQyNyAwLS4zOTMuMzktLjM5MyAxLjAzIDAgMS40MmwxMS4yODMgMTAuMjgtMTEuMjgzIDEwLjI5Yy0uMzkzLjM5LS4zOTMgMS4wMiAwIDEuNDIuMzk1LjM5IDEuMDMzLjM5IDEuNDI3IDBsMTIuMDA3LTEwLjk0Yy4yMS0uMjEuMy0uNDkuMjg0LS43Ny4wMTQtLjI3LS4wNzYtLjU1LS4yODYtLjc2TDEwLjcyIDQuMjkzeiIKICAgICAgICAgIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOCIgZmlsbC1ydWxlPSJldmVub2RkIi8+Cjwvc3ZnPg==\\\" alt=\\\"next arrow\\\" \\/><\\/div>\\n        <\\/div>\\n        <\\/div><\\/template><div id=\\\"n2-ss-2-spinner\\\" style=\\\"display: none;\\\"><div><div class=\\\"n2-ss-spinner-simple-white-container\\\"><div class=\\\"n2-ss-spinner-simple-white\\\"><\\/div><\\/div><\\/div><\\/div><\\/div><\\/div><div class=\\\"n2_clear\\\"><\\/div><div id=\\\"n2-ss-2-placeholder\\\" style=\\\"position: relative;z-index:2;background-color:RGBA(0,0,0,0); background-color:RGBA(255,255,255,0);\\\"><img style=\\\"width: 100%; max-width:10000px; display: block;opacity:0;margin:0px;\\\" class=\\\"n2-ow\\\" src=\\\"data:image\\/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI5NjAiIGhlaWdodD0iNDgwIiA+PC9zdmc+\\\" alt=\\\"Slider\\\" \\/><\\/div><\\/div>\",\"assets\":{\"css\":{\"staticGroup\":{\"smartslider\":\"C:\\\\xampp\\\\htdocs\\\\es2016_third\\\\module_c\\\\wp-content\\\\plugins\\\\smart-slider-3\\\\Public\\\\SmartSlider3\\\\Application\\\\Frontend\\/Assets\\/dist\\/smartslider.min.css\"},\"files\":[],\"urls\":[],\"codes\":[],\"firstCodes\":[],\"inline\":[\".n2-ss-spinner-simple-white-container {\\n    position: absolute;\\n    top: 50%;\\n    left: 50%;\\n    margin: -20px;\\n    background: #fff;\\n    width: 20px;\\n    height: 20px;\\n    padding: 10px;\\n    border-radius: 50%;\\n    z-index: 1000;\\n}\\n\\n.n2-ss-spinner-simple-white {\\n  outline: 1px solid RGBA(0,0,0,0);\\n  width:100%;\\n  height: 100%;\\n}\\n\\n.n2-ss-spinner-simple-white:before {\\n    position: absolute;\\n    top: 50%;\\n    left: 50%;\\n    width: 20px;\\n    height: 20px;\\n    margin-top: -11px;\\n    margin-left: -11px;\\n}\\n\\n.n2-ss-spinner-simple-white:not(:required):before {\\n    content: \'\';\\n    border-radius: 50%;\\n    border-top: 2px solid #333;\\n    border-right: 2px solid transparent;\\n    animation: n2SimpleWhite .6s linear infinite;\\n}\\n@keyframes n2SimpleWhite {\\n    to {transform: rotate(360deg);}\\n}\"],\"globalInline\":[]},\"less\":{\"staticGroup\":[],\"files\":[],\"urls\":[],\"codes\":[],\"firstCodes\":[],\"inline\":[],\"globalInline\":[]},\"js\":{\"staticGroup\":{\"smartslider-frontend\":\"C:\\\\xampp\\\\htdocs\\\\es2016_third\\\\module_c\\\\wp-content\\\\plugins\\\\smart-slider-3\\\\Public\\\\SmartSlider3\\\\Application\\\\Frontend\\/Assets\\/dist\\/smartslider-frontend.min.js\",\"smartslider-simple-type-frontend\":\"C:\\\\xampp\\\\htdocs\\\\es2016_third\\\\module_c\\\\wp-content\\\\plugins\\\\smart-slider-3\\\\Public\\\\SmartSlider3\\\\Slider\\\\SliderType\\\\Simple\\/Assets\\/dist\\/smartslider-simple-type-frontend.min.js\"},\"files\":[],\"urls\":[],\"codes\":[],\"firstCodes\":[],\"inline\":[\"N2R([\\\"documentReady\\\",\\\"smartslider-frontend\\\",\\\"smartslider-simple-type-frontend\\\"],function(){new N2Classes.SmartSliderSimple(\'#n2-ss-2\', {\\\"admin\\\":false,\\\"callbacks\\\":\\\"\\\",\\\"background.video.mobile\\\":1,\\\"alias\\\":{\\\"id\\\":0,\\\"smoothScroll\\\":0,\\\"slideSwitch\\\":0,\\\"scrollSpeed\\\":400},\\\"align\\\":\\\"normal\\\",\\\"isDelayed\\\":0,\\\"load\\\":{\\\"fade\\\":1,\\\"scroll\\\":0},\\\"playWhenVisible\\\":1,\\\"playWhenVisibleAt\\\":0.5,\\\"responsive\\\":{\\\"hideOn\\\":{\\\"desktopLandscape\\\":false,\\\"desktopPortrait\\\":false,\\\"tabletLandscape\\\":false,\\\"tabletPortrait\\\":false,\\\"mobileLandscape\\\":false,\\\"mobilePortrait\\\":false},\\\"onResizeEnabled\\\":true,\\\"type\\\":\\\"auto\\\",\\\"downscale\\\":1,\\\"upscale\\\":1,\\\"minimumHeight\\\":0,\\\"maximumSlideWidth\\\":{\\\"desktopLandscape\\\":10000,\\\"desktopPortrait\\\":10000,\\\"tabletLandscape\\\":10000,\\\"tabletPortrait\\\":10000,\\\"mobileLandscape\\\":10000,\\\"mobilePortrait\\\":10000},\\\"forceFull\\\":0,\\\"forceFullOverflowX\\\":\\\"body\\\",\\\"forceFullHorizontalSelector\\\":\\\"\\\",\\\"constrainRatio\\\":1,\\\"sliderHeightBasedOn\\\":\\\"real\\\",\\\"decreaseSliderHeight\\\":0,\\\"focusUser\\\":1,\\\"focusEdge\\\":\\\"auto\\\",\\\"breakpoints\\\":[{\\\"device\\\":\\\"tabletPortrait\\\",\\\"type\\\":\\\"max-screen-width\\\",\\\"portraitWidth\\\":1199,\\\"landscapeWidth\\\":1199},{\\\"device\\\":\\\"mobilePortrait\\\",\\\"type\\\":\\\"max-screen-width\\\",\\\"portraitWidth\\\":700,\\\"landscapeWidth\\\":900}],\\\"enabledDevices\\\":{\\\"desktopLandscape\\\":0,\\\"desktopPortrait\\\":1,\\\"tabletLandscape\\\":0,\\\"tabletPortrait\\\":1,\\\"mobileLandscape\\\":0,\\\"mobilePortrait\\\":1},\\\"sizes\\\":{\\\"desktopPortrait\\\":{\\\"width\\\":960,\\\"height\\\":480,\\\"max\\\":3000,\\\"min\\\":960},\\\"tabletPortrait\\\":{\\\"width\\\":701,\\\"height\\\":350,\\\"max\\\":1199,\\\"min\\\":701},\\\"mobilePortrait\\\":{\\\"width\\\":320,\\\"height\\\":160,\\\"max\\\":900,\\\"min\\\":320}},\\\"normalizedDeviceModes\\\":{\\\"unknown\\\":\\\"desktopPortrait\\\",\\\"desktopPortrait\\\":\\\"desktopPortrait\\\",\\\"desktopLandscape\\\":\\\"desktopPortrait\\\",\\\"tabletLandscape\\\":\\\"desktopPortrait\\\",\\\"tabletPortrait\\\":\\\"tabletPortrait\\\",\\\"mobileLandscape\\\":\\\"tabletPortrait\\\",\\\"mobilePortrait\\\":\\\"mobilePortrait\\\"},\\\"overflowHiddenPage\\\":0,\\\"focus\\\":{\\\"offsetTop\\\":\\\"#wpadminbar\\\",\\\"offsetBottom\\\":\\\"\\\"}},\\\"controls\\\":{\\\"mousewheel\\\":0,\\\"touch\\\":\\\"horizontal\\\",\\\"keyboard\\\":1,\\\"blockCarouselInteraction\\\":1},\\\"lazyLoad\\\":0,\\\"lazyLoadNeighbor\\\":0,\\\"blockrightclick\\\":0,\\\"maintainSession\\\":0,\\\"autoplay\\\":{\\\"enabled\\\":1,\\\"start\\\":1,\\\"duration\\\":8000,\\\"autoplayLoop\\\":1,\\\"allowReStart\\\":0,\\\"pause\\\":{\\\"click\\\":1,\\\"mouse\\\":\\\"0\\\",\\\"mediaStarted\\\":1},\\\"resume\\\":{\\\"click\\\":0,\\\"mouse\\\":\\\"0\\\",\\\"mediaEnded\\\":1,\\\"slidechanged\\\":0},\\\"interval\\\":1,\\\"intervalModifier\\\":\\\"loop\\\",\\\"intervalSlide\\\":\\\"current\\\"},\\\"perspective\\\":1500,\\\"layerMode\\\":{\\\"playOnce\\\":0,\\\"playFirstLayer\\\":1,\\\"mode\\\":\\\"skippable\\\",\\\"inAnimation\\\":\\\"mainInEnd\\\"},\\\"bgAnimationsColor\\\":\\\"RGBA(51,51,51,1)\\\",\\\"bgAnimations\\\":0,\\\"mainanimation\\\":{\\\"type\\\":\\\"horizontal\\\",\\\"duration\\\":800,\\\"delay\\\":0,\\\"ease\\\":\\\"easeOutQuad\\\",\\\"parallax\\\":0,\\\"shiftedBackgroundAnimation\\\":0},\\\"carousel\\\":1,\\\"dynamicHeight\\\":0,\\\"initCallbacks\\\":function($){N2D(\\\"SmartSliderWidgetArrowImage\\\",\\\"SmartSliderWidget\\\",function(e,i){function r(e,i,t,s,r,o){this.key=e,this.action=t,this.desktopRatio=s,this.tabletRatio=r,this.mobileRatio=o,N2Classes.SmartSliderWidget.prototype.constructor.call(this,i)}return((r.prototype=Object.create(N2Classes.SmartSliderWidget.prototype)).constructor=r).prototype.onStart=function(){this.deferred=e.Deferred(),this.slider.sliderElement.on(\\\"SliderDevice\\\",this.onDevice.bind(this)).trigger(\\\"addWidget\\\",this.deferred),this.$widget=e(\\\"#\\\"+this.slider.elementID+\\\"-arrow-\\\"+this.key).on(\\\"click\\\",function(e){e.stopPropagation(),this.slider[this.action]()}.bind(this)),this.$resize=this.$widget.find(\\\".n2-resize\\\"),0===this.$resize.length&&(this.$resize=this.$widget),e.when(this.$widget.n2imagesLoaded(),this.slider.stages.get(\\\"ResizeFirst\\\").getDeferred()).always(this.onLoad.bind(this))},r.prototype.onLoad=function(){this.$widget.addClass(\\\"n2-ss-widget--calc\\\"),this.previousWidth=this.$resize.width(),this.previousHeight=this.$resize.height(),this.$widget.removeClass(\\\"n2-ss-widget--calc\\\"),this.$resize.find(\\\"img\\\").css(\\\"width\\\",\\\"100%\\\"),this.onDevice(null,{device:this.slider.responsive.getDeviceMode()}),this.deferred.resolve()},r.prototype.onDevice=function(e,i){var t=1;switch(i.device){case\\\"tabletPortrait\\\":case\\\"tabletLandscape\\\":t=this.tabletRatio;break;case\\\"mobilePortrait\\\":case\\\"mobileLandscape\\\":t=this.mobileRatio;break;default:t=this.desktopRatio}this.$resize.width(this.previousWidth*t),this.$resize.height(this.previousHeight*t)},function(e,i,t,s){this.key=\\\"arrow\\\",this.previous=new r(\\\"previous\\\",e,\\\"previousWithDirection\\\",i,t,s),this.next=new r(\\\"next\\\",e,\\\"nextWithDirection\\\",i,t,s)}});new N2Classes.SmartSliderWidgetArrowImage(this, 1, 1, 0.5);}});});\"],\"globalInline\":[]},\"googleFonts\":{\"staticGroup\":[],\"files\":[],\"urls\":[],\"codes\":[],\"firstCodes\":[],\"inline\":[],\"globalInline\":[]},\"image\":{\"images\":[\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_08.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_07.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_09.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_06.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_04.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_12.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_05.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_13.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_15.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_16.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_17.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_14.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_10.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_18.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_11.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_19.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_22.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_20.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_24.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_23.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_25.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_27.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_28.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_29.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_21.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_31.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_26.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_02.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_03.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_01.jpeg\",\"\\/\\/localhost\\/wp-content\\/uploads\\/slider2\\/Bild_30.jpeg\"]}}}","0","1");


DROP TABLE IF EXISTS `wp_nextend2_smartslider3_generators`;

CREATE TABLE `wp_nextend2_smartslider3_generators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_nextend2_smartslider3_sliders`;

CREATE TABLE `wp_nextend2_smartslider3_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `time` datetime NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `time` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_nextend2_smartslider3_sliders` VALUES("1","","Tutorial Slider","simple","{\"aria-label\":\"Slider\",\"alias-id\":\"\",\"alias-smoothscroll\":\"\",\"alias-slideswitch\":\"\",\"background\":\"\",\"background-fixed\":\"0\",\"background-size\":\"cover\",\"background-color\":\"FFFFFF00\",\"backgroundVideoMp4\":\"\",\"backgroundVideoMuted\":\"1\",\"backgroundVideoLoop\":\"1\",\"backgroundVideoMode\":\"fill\",\"align\":\"normal\",\"margin\":\"0|*|0|*|0|*|0\",\"padding\":\"0|*|0|*|0|*|0\",\"perspective\":\"1000\",\"border-width\":\"0\",\"border-color\":\"3E3E3Eff\",\"border-radius\":\"0\",\"slider-preset\":\"\",\"slider-css\":\"\",\"width\":\"1200\",\"height\":\"600\",\"mobileportrait\":\"1\",\"mobilelandscape\":\"1\",\"tabletportrait\":\"1\",\"tabletlandscape\":\"1\",\"desktopportrait\":\"1\",\"desktoplandscape\":\"1\",\"responsiveLimitSlideWidth\":\"1\",\"responsiveSlideWidthDesktopLandscape\":\"0\",\"responsiveSlideWidthMaxDesktopLandscape\":\"1600\",\"responsiveSlideWidth\":\"0\",\"responsiveSlideWidthMax\":\"3000\",\"responsiveSlideWidthTabletLandscape\":\"0\",\"responsiveSlideWidthMaxTabletLandscape\":\"1200\",\"responsiveSlideWidthTablet\":\"0\",\"responsiveSlideWidthMaxTablet\":\"3000\",\"responsiveSlideWidthMobileLandscape\":\"0\",\"responsiveSlideWidthMaxMobileLandscape\":\"740\",\"responsiveSlideWidthMobile\":\"0\",\"responsiveSlideWidthMaxMobile\":\"480\",\"responsive-breakpoint-desktop-portrait\":\"1440\",\"responsive-breakpoint-desktop-portrait-landscape\":\"1440\",\"responsive-breakpoint-tablet-landscape\":\"1300\",\"responsive-breakpoint-tablet-landscape-landscape\":\"1300\",\"responsive-breakpoint-tablet-portrait\":\"1199\",\"responsive-breakpoint-tablet-portrait-landscape\":\"1199\",\"responsive-breakpoint-mobile-landscape\":\"900\",\"responsive-breakpoint-mobile-landscape-landscape\":\"1050\",\"responsive-breakpoint-mobile-portrait\":\"700\",\"responsive-breakpoint-mobile-portrait-landscape\":\"900\",\"responsive-breakpoint-desktop-landscape-enabled\":\"0\",\"responsive-breakpoint-tablet-landscape-enabled\":\"0\",\"responsive-breakpoint-tablet-portrait-enabled\":\"1\",\"responsive-breakpoint-mobile-landscape-enabled\":\"0\",\"responsive-breakpoint-mobile-portrait-enabled\":\"1\",\"responsive-breakpoint-global\":\"0\",\"breakpoints-orientation\":\"portrait\",\"responsive-mode\":\"fullwidth\",\"responsiveSliderHeightMin\":\"0\",\"responsiveForceFull\":\"1\",\"responsiveForceFullOverflowX\":\"body\",\"responsiveForceFullHorizontalSelector\":\"body\",\"slider-size-override\":\"0\",\"slider-size-override-mobile-portrait\":\"0\",\"mobile-portrait-width\":\"320\",\"mobile-portrait-height\":\"568\",\"slider-size-override-mobile-landscape\":\"0\",\"mobile-landscape-width\":\"568\",\"mobile-landscape-height\":\"320\",\"slider-size-override-tablet-portrait\":\"0\",\"tablet-portrait-width\":\"768\",\"tablet-portrait-height\":\"1024\",\"slider-size-override-tablet-landscape\":\"0\",\"tablet-landscape-width\":\"1024\",\"tablet-landscape-height\":\"768\",\"slider-size-override-desktop-landscape\":\"0\",\"desktop-landscape-width\":\"1440\",\"desktop-landscape-height\":\"900\",\"controlsTouch\":\"horizontal\",\"controlsScroll\":\"0\",\"controlsKeyboard\":\"1\",\"widget-arrow-enabled\":\"0\",\"widgetarrow\":\"imageEmpty\",\"widget-arrow-previous\":\"thin-horizontal.svg\",\"widget-arrow-previous-image\":\"\",\"widget-arrow-previous-color\":\"ffffffcc\",\"widget-arrow-previous-hover\":\"1\",\"widget-arrow-previous-hover-color\":\"ffffffff\",\"widget-arrow-mirror\":\"1\",\"widget-arrow-next\":\"thin-horizontal.svg\",\"widget-arrow-next-image\":\"\",\"widget-arrow-next-color\":\"ffffffcc\",\"widget-arrow-next-hover\":\"0\",\"widget-arrow-next-hover-color\":\"ffffffcc\",\"widget-arrow-style\":\"\",\"widget-arrow-previous-position-mode\":\"simple\",\"widget-arrow-previous-position-area\":\"6\",\"widget-arrow-previous-position-stack\":\"1\",\"widget-arrow-previous-position-offset\":\"15\",\"widget-arrow-previous-position-horizontal\":\"left\",\"widget-arrow-previous-position-horizontal-position\":\"0\",\"widget-arrow-previous-position-horizontal-unit\":\"px\",\"widget-arrow-previous-position-vertical\":\"top\",\"widget-arrow-previous-position-vertical-position\":\"0\",\"widget-arrow-previous-position-vertical-unit\":\"px\",\"widget-arrow-next-position-mode\":\"simple\",\"widget-arrow-next-position-area\":\"7\",\"widget-arrow-next-position-stack\":\"1\",\"widget-arrow-next-position-offset\":\"15\",\"widget-arrow-next-position-horizontal\":\"left\",\"widget-arrow-next-position-horizontal-position\":\"0\",\"widget-arrow-next-position-horizontal-unit\":\"px\",\"widget-arrow-next-position-vertical\":\"top\",\"widget-arrow-next-position-vertical-position\":\"0\",\"widget-arrow-next-position-vertical-unit\":\"px\",\"widget-arrow-animation\":\"fade\",\"widget-arrow-previous-alt\":\"previous arrow\",\"widget-arrow-next-alt\":\"next arrow\",\"widget-arrow-base64\":\"1\",\"widget-arrow-responsive-desktop\":\"1\",\"widget-arrow-responsive-tablet\":\"1\",\"widget-arrow-responsive-mobile\":\"0.5\",\"widget-arrow-display-hover\":\"0\",\"widget-arrow-display-mobileportrait\":\"0\",\"widget-arrow-display-mobilelandscape\":\"0\",\"widget-arrow-display-tabletportrait\":\"1\",\"widget-arrow-display-tabletlandscape\":\"1\",\"widget-arrow-display-desktopportrait\":\"1\",\"widget-arrow-display-desktoplandscape\":\"1\",\"widget-arrow-exclude-slides\":\"\",\"widget-bullet-enabled\":\"1\",\"widgetbullet\":\"transition\",\"widget-bullet-position-mode\":\"simple\",\"widget-bullet-position-area\":\"10\",\"widget-bullet-position-stack\":\"1\",\"widget-bullet-position-offset\":\"5\",\"widget-bullet-position-horizontal\":\"left\",\"widget-bullet-position-horizontal-position\":\"0\",\"widget-bullet-position-horizontal-unit\":\"px\",\"widget-bullet-position-vertical\":\"top\",\"widget-bullet-position-vertical-position\":\"0\",\"widget-bullet-position-vertical-unit\":\"px\",\"widget-bullet-action\":\"click\",\"widget-bullet-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"00000000\\\",\\\"opacity\\\":100,\\\"padding\\\":\\\"5|*|5|*|5|*|5|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"2|*|solid|*|ffffffcc\\\",\\\"borderradius\\\":\\\"50\\\",\\\"extra\\\":\\\"margin: 4px;\\\"},{\\\"extra\\\":\\\"\\\",\\\"backgroundcolor\\\":\\\"ffffffcc\\\",\\\"border\\\":\\\"2|*|solid|*|ffffffcc\\\"}]}\",\"widget-bullet-bar\":\"\",\"widget-bullet-bar-full-size\":\"0\",\"widget-bullet-align\":\"center\",\"widget-bullet-orientation\":\"auto\",\"widget-bullet-thumbnail-show-image\":\"0\",\"widget-bullet-thumbnail-width\":\"60\",\"widget-bullet-thumbnail-height\":\"60\",\"widget-bullet-thumbnail-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"00000080\\\",\\\"padding\\\":\\\"3|*|3|*|3|*|3|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"3\\\",\\\"extra\\\":\\\"margin: 5px;\\\"}]}\",\"widget-bullet-thumbnail-side\":\"before\",\"widget-bullet-display-hover\":\"0\",\"widget-bullet-display-mobileportrait\":\"1\",\"widget-bullet-display-mobilelandscape\":\"1\",\"widget-bullet-display-tabletportrait\":\"1\",\"widget-bullet-display-tabletlandscape\":\"1\",\"widget-bullet-display-desktopportrait\":\"1\",\"widget-bullet-display-desktoplandscape\":\"1\",\"widget-bullet-exclude-slides\":\"\",\"widget-bar-enabled\":\"0\",\"widgetbar\":\"horizontal\",\"widget-bar-position-mode\":\"simple\",\"widget-bar-position-area\":\"10\",\"widget-bar-position-stack\":\"1\",\"widget-bar-position-offset\":\"30\",\"widget-bar-position-horizontal\":\"left\",\"widget-bar-position-horizontal-position\":\"0\",\"widget-bar-position-horizontal-unit\":\"px\",\"widget-bar-position-vertical\":\"top\",\"widget-bar-position-vertical-position\":\"0\",\"widget-bar-position-vertical-unit\":\"px\",\"widget-bar-animate\":\"0\",\"widget-bar-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"5|*|20|*|5|*|20|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"40\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-bar-show-title\":\"1\",\"widget-bar-font-title\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000c7\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\",\\\"extra\\\":\\\"vertical-align: middle;\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http://fonts.googleapis.com/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-bar-show-description\":\"1\",\"widget-bar-font-description\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000c7\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":1,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\",\\\"extra\\\":\\\"vertical-align: middle;\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http://fonts.googleapis.com/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-bar-slide-count\":\"0\",\"widget-bar-width\":\"100%\",\"widget-bar-full-width\":\"0\",\"widget-bar-separator\":\" - \",\"widget-bar-align\":\"center\",\"widget-bar-display-hover\":\"0\",\"widget-bar-display-mobileportrait\":\"1\",\"widget-bar-display-mobilelandscape\":\"1\",\"widget-bar-display-tabletportrait\":\"1\",\"widget-bar-display-tabletlandscape\":\"1\",\"widget-bar-display-desktopportrait\":\"1\",\"widget-bar-display-desktoplandscape\":\"1\",\"widget-bar-exclude-slides\":\"\",\"widget-thumbnail-enabled\":\"0\",\"widgetthumbnail\":\"default\",\"widget-thumbnail-show-image\":\"1\",\"widget-thumbnail-width\":\"100\",\"widget-thumbnail-height\":\"60\",\"widget-thumbnail-position-mode\":\"simple\",\"widget-thumbnail-position-area\":\"12\",\"widget-thumbnail-position-stack\":\"1\",\"widget-thumbnail-position-offset\":\"0\",\"widget-thumbnail-position-horizontal\":\"left\",\"widget-thumbnail-position-horizontal-position\":\"0\",\"widget-thumbnail-position-horizontal-unit\":\"px\",\"widget-thumbnail-position-vertical\":\"top\",\"widget-thumbnail-position-vertical-position\":\"0\",\"widget-thumbnail-position-vertical-unit\":\"px\",\"widget-thumbnail-action\":\"click\",\"widget-thumbnail-align-content\":\"start\",\"widget-thumbnail-style-bar\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"242424ff\\\",\\\"padding\\\":\\\"3|*|3|*|3|*|3|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"0\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-thumbnail-style-slides\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"00000000\\\",\\\"padding\\\":\\\"0|*|0|*|0|*|0|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|ffffff00\\\",\\\"borderradius\\\":\\\"0\\\",\\\"opacity\\\":\\\"40\\\",\\\"extra\\\":\\\"margin: 3px;\\ntransition: all 0.4s;\\nbackground-size: cover;\\\"},{\\\"border\\\":\\\"0|*|solid|*|ffffffcc\\\",\\\"opacity\\\":\\\"100\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-thumbnail-title-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"3|*|10|*|3|*|10|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"0\\\",\\\"extra\\\":\\\"bottom: 0;\\nleft: 0;\\\"}]}\",\"widget-thumbnail-title\":\"0\",\"widget-thumbnail-title-font\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"12||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ab\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.2\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http://fonts.googleapis.com/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-thumbnail-description\":\"0\",\"widget-thumbnail-description-font\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"12||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ab\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http://fonts.googleapis.com/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-thumbnail-caption-placement\":\"overlay\",\"widget-thumbnail-caption-size\":\"100\",\"widget-thumbnail-arrow\":\"1\",\"widget-thumbnail-arrow-width\":\"26\",\"widget-thumbnail-arrow-offset\":\"0\",\"widget-thumbnail-arrow-prev-alt\":\"previous arrow\",\"widget-thumbnail-arrow-next-alt\":\"next arrow\",\"widget-thumbnail-arrow-image\":\"\",\"widget-thumbnail-minimum-thumbnail-count\":\"2\",\"widget-thumbnail-group\":\"1\",\"widget-thumbnail-invert-group-direction\":\"0\",\"widget-thumbnail-orientation\":\"auto\",\"widget-thumbnail-size\":\"100%\",\"widget-thumbnail-display-hover\":\"0\",\"widget-thumbnail-display-mobileportrait\":\"1\",\"widget-thumbnail-display-mobilelandscape\":\"1\",\"widget-thumbnail-display-tabletportrait\":\"1\",\"widget-thumbnail-display-tabletlandscape\":\"1\",\"widget-thumbnail-display-desktopportrait\":\"1\",\"widget-thumbnail-display-desktoplandscape\":\"1\",\"widget-thumbnail-exclude-slides\":\"\",\"widget-shadow-enabled\":\"0\",\"widgetshadow\":\"shadow\",\"widget-shadow-shadow\":\"dark.png\",\"widget-shadow-shadow-image\":\"\",\"widget-shadow-width\":\"100%\",\"widget-shadow-display-mobileportrait\":\"1\",\"widget-shadow-display-mobilelandscape\":\"1\",\"widget-shadow-display-tabletportrait\":\"1\",\"widget-shadow-display-tabletlandscape\":\"1\",\"widget-shadow-display-desktopportrait\":\"1\",\"widget-shadow-display-desktoplandscape\":\"1\",\"widget-shadow-exclude-slides\":\"\",\"widget-fullscreen-enabled\":\"0\",\"widgetfullscreen\":\"image\",\"widget-fullscreen-tonormal\":\"full1.svg\",\"widget-fullscreen-tonormal-image\":\"\",\"widget-fullscreen-tonormal-color\":\"ffffffcc\",\"widget-fullscreen-mirror\":\"1\",\"widget-fullscreen-tofull\":\"full1.svg\",\"widget-fullscreen-tofull-image\":\"\",\"widget-fullscreen-tofull-color\":\"ffffffcc\",\"widget-fullscreen-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"10|*|10|*|10|*|10|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"3\\\",\\\"extra\\\":\\\"\\\"},{\\\"backgroundcolor\\\":\\\"000000ab\\\"}]}\",\"widget-fullscreen-position-mode\":\"simple\",\"widget-fullscreen-position-area\":\"4\",\"widget-fullscreen-position-stack\":\"1\",\"widget-fullscreen-position-offset\":\"15\",\"widget-fullscreen-position-horizontal\":\"left\",\"widget-fullscreen-position-horizontal-position\":\"0\",\"widget-fullscreen-position-horizontal-unit\":\"px\",\"widget-fullscreen-position-vertical\":\"top\",\"widget-fullscreen-position-vertical-position\":\"0\",\"widget-fullscreen-position-vertical-unit\":\"px\",\"widget-fullscreen-responsive-desktop\":\"1\",\"widget-fullscreen-responsive-tablet\":\"0.7\",\"widget-fullscreen-responsive-mobile\":\"0.5\",\"widget-fullscreen-display-hover\":\"0\",\"widget-fullscreen-display-mobileportrait\":\"1\",\"widget-fullscreen-display-mobilelandscape\":\"1\",\"widget-fullscreen-display-tabletportrait\":\"1\",\"widget-fullscreen-display-tabletlandscape\":\"1\",\"widget-fullscreen-display-desktopportrait\":\"1\",\"widget-fullscreen-display-desktoplandscape\":\"1\",\"widget-fullscreen-exclude-slides\":\"\",\"widget-html-enabled\":\"0\",\"widgethtml\":\"html\",\"widget-html-position-mode\":\"simple\",\"widget-html-position-area\":\"2\",\"widget-html-position-stack\":\"1\",\"widget-html-position-offset\":\"0\",\"widget-html-position-horizontal\":\"left\",\"widget-html-position-horizontal-position\":\"0\",\"widget-html-position-horizontal-unit\":\"px\",\"widget-html-position-vertical\":\"top\",\"widget-html-position-vertical-position\":\"0\",\"widget-html-position-vertical-unit\":\"px\",\"widget-html-code\":\"\",\"widget-html-display-hover\":\"0\",\"widget-html-display-mobileportrait\":\"1\",\"widget-html-display-mobilelandscape\":\"1\",\"widget-html-display-tabletportrait\":\"1\",\"widget-html-display-tabletlandscape\":\"1\",\"widget-html-display-desktopportrait\":\"1\",\"widget-html-display-desktoplandscape\":\"1\",\"widget-html-exclude-slides\":\"\",\"animation\":\"fade\",\"animation-duration\":\"500\",\"animation-delay\":\"0\",\"animation-easing\":\"easeOutQuad\",\"animation-parallax-overlap\":\"0\",\"carousel\":\"1\",\"background-animation\":\"\",\"background-animation-color\":\"333333ff\",\"background-animation-speed\":\"normal\",\"animation-shifted-background-animation\":\"auto\",\"kenburns-animation\":\"50|*|50|*|\",\"kenburns-animation-speed\":\"default\",\"kenburns-animation-strength\":\"default\",\"shape-divider\":\"\",\"particle\":\"\",\"playfirstlayer\":\"1\",\"playonce\":\"0\",\"layer-animation-play-in\":\"end\",\"layer-animation-play-mode\":\"skippable\",\"parallax-enabled\":\"1\",\"parallax-enabled-mobile\":\"0\",\"parallax-3d\":\"0\",\"parallax-animate\":\"1\",\"parallax-horizontal\":\"mouse\",\"parallax-vertical\":\"mouse\",\"parallax-mouse-origin\":\"slider\",\"parallax-scroll-move\":\"both\",\"autoplay\":\"0\",\"autoplayDuration\":\"8000\",\"autoplayStart\":\"1\",\"autoplayAllowReStart\":\"0\",\"autoplayLoop\":\"1\",\"autoplayfinish\":\"1|*|loop|*|current\",\"loop-single-slide\":\"0\",\"autoplayStopClick\":\"1\",\"autoplayStopMouse\":\"0\",\"autoplayStopMedia\":\"1\",\"autoplayResumeClick\":\"0\",\"autoplayResumeMouse\":\"0\",\"autoplayResumeMedia\":\"1\",\"widget-autoplay-enabled\":\"0\",\"widgetautoplay\":\"image\",\"widget-autoplay-play\":\"small-light.svg\",\"widget-autoplay-play-image\":\"\",\"widget-autoplay-play-color\":\"ffffffcc\",\"widget-autoplay-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"10|*|10|*|10|*|10|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"3\\\",\\\"extra\\\":\\\"\\\"},{\\\"backgroundcolor\\\":\\\"000000ab\\\"}]}\",\"widget-autoplay-mirror\":\"1\",\"widget-autoplay-pause\":\"small-light.svg\",\"widget-autoplay-pause-image\":\"\",\"widget-autoplay-pause-color\":\"ffffffcc\",\"widget-autoplay-responsive-desktop\":\"1\",\"widget-autoplay-responsive-tablet\":\"0.7\",\"widget-autoplay-responsive-mobile\":\"0.5\",\"widget-autoplay-position-mode\":\"simple\",\"widget-autoplay-position-area\":\"4\",\"widget-autoplay-position-stack\":\"1\",\"widget-autoplay-position-offset\":\"15\",\"widget-autoplay-position-horizontal\":\"left\",\"widget-autoplay-position-horizontal-position\":\"0\",\"widget-autoplay-position-horizontal-unit\":\"px\",\"widget-autoplay-position-vertical\":\"top\",\"widget-autoplay-position-vertical-position\":\"0\",\"widget-autoplay-position-vertical-unit\":\"px\",\"widget-autoplay-display-hover\":\"0\",\"widget-autoplay-display-mobileportrait\":\"1\",\"widget-autoplay-display-mobilelandscape\":\"1\",\"widget-autoplay-display-tabletportrait\":\"1\",\"widget-autoplay-display-tabletlandscape\":\"1\",\"widget-autoplay-display-desktopportrait\":\"1\",\"widget-autoplay-display-desktoplandscape\":\"1\",\"widget-autoplay-exclude-slides\":\"\",\"widget-indicator-enabled\":\"0\",\"widgetindicator\":\"pie\",\"widget-indicator-position-mode\":\"simple\",\"widget-indicator-position-area\":\"4\",\"widget-indicator-position-stack\":\"1\",\"widget-indicator-position-offset\":\"15\",\"widget-indicator-position-horizontal\":\"left\",\"widget-indicator-position-horizontal-position\":\"0\",\"widget-indicator-position-horizontal-unit\":\"px\",\"widget-indicator-position-vertical\":\"top\",\"widget-indicator-position-vertical-position\":\"0\",\"widget-indicator-position-vertical-unit\":\"px\",\"widget-indicator-size\":\"25\",\"widget-indicator-thickness\":\"30\",\"widget-indicator-track\":\"000000ab\",\"widget-indicator-bar\":\"ffffffff\",\"widget-indicator-style\":\"\",\"widget-indicator-display-hover\":\"0\",\"widget-indicator-display-mobileportrait\":\"1\",\"widget-indicator-display-mobilelandscape\":\"1\",\"widget-indicator-display-tabletportrait\":\"1\",\"widget-indicator-display-tabletlandscape\":\"1\",\"widget-indicator-display-desktopportrait\":\"1\",\"widget-indicator-display-desktoplandscape\":\"1\",\"widget-indicator-exclude-slides\":\"\",\"imageload\":\"0\",\"imageloadNeighborSlides\":\"0\",\"optimize\":\"0\",\"optimize-quality\":\"70\",\"optimizeThumbnailWidth\":\"100\",\"optimizeThumbnailHeight\":\"60\",\"optimize-background-image-custom\":\"0\",\"optimize-background-image-width\":\"800\",\"optimize-background-image-height\":\"600\",\"layer-image-optimize\":\"0\",\"layer-image-tablet\":\"50\",\"layer-image-mobile\":\"30\",\"layer-image-base64\":\"0\",\"layer-image-base64-size\":\"50\",\"slides-background-video-mobile\":\"1\",\"playWhenVisible\":\"1\",\"playWhenVisibleAt\":\"50\",\"fadeOnLoad\":\"1\",\"fadeOnScroll\":\"0\",\"dependency\":\"\",\"delay\":\"0\",\"is-delayed\":\"0\",\"spinner\":\"simpleWhite\",\"custom-spinner\":\"\",\"custom-spinner-width\":\"100\",\"custom-spinner-height\":\"100\",\"custom-display\":\"1\",\"placeholder-background-image\":\"\",\"placeholder-color\":\"FFFFFF00\",\"backgroundMode\":\"fill\",\"dynamic-height\":\"0\",\"slide-css\":\"\",\"randomize\":\"0\",\"randomizeFirst\":\"0\",\"randomize-cache\":\"1\",\"variations\":\"5\",\"reverse-slides\":\"0\",\"maximumslidecount\":\"1000\",\"maintain-session\":\"0\",\"global-lightbox\":\"0\",\"global-lightbox-label\":\"0\",\"slide-background-parallax\":\"0\",\"slide-background-parallax-strength\":\"50\",\"bg-parallax-tablet\":\"0\",\"bg-parallax-mobile\":\"0\",\"blockrightclick\":\"0\",\"controlsBlockCarouselInteraction\":\"1\",\"clear-both\":\"1\",\"clear-both-after\":\"1\",\"overflow-hidden-page\":\"0\",\"responsiveFocusUser\":\"1\",\"responsiveFocusEdge\":\"auto\",\"classes\":\"\",\"custom-css-codes\":\"\",\"callbacks\":\"\",\"related-posts\":\"\"}","trash","2020-02-25 13:53:41","https://smartslider3.com/wp-content/uploads/slider404/tutorialsliderthumbnail-1.png","0");
INSERT INTO `wp_nextend2_smartslider3_sliders` VALUES("2","","My project","simple","{\"thumbnail\":\"\",\"aria-label\":\"Slider\",\"alias-id\":\"\",\"alias-smoothscroll\":\"\",\"alias-slideswitch\":\"\",\"align\":\"normal\",\"margin\":\"0|*|0|*|0|*|0\",\"width\":\"960\",\"height\":\"480\",\"responsiveLimitSlideWidth\":\"0\",\"responsiveSlideWidth\":\"0\",\"responsiveSlideWidthMax\":\"3000\",\"responsiveSlideWidthTablet\":\"0\",\"responsiveSlideWidthMaxTablet\":\"3000\",\"responsiveSlideWidthMobile\":\"0\",\"responsiveSlideWidthMaxMobile\":\"480\",\"responsive-breakpoint-tablet-portrait\":\"1199\",\"responsive-breakpoint-tablet-portrait-landscape\":\"1199\",\"responsive-breakpoint-mobile-portrait\":\"700\",\"responsive-breakpoint-mobile-portrait-landscape\":\"900\",\"responsive-breakpoint-tablet-portrait-enabled\":\"1\",\"responsive-breakpoint-mobile-portrait-enabled\":\"1\",\"responsive-breakpoint-global\":\"0\",\"breakpoints-orientation\":\"portrait\",\"responsive-mode\":\"auto\",\"responsiveScaleDown\":\"1\",\"responsiveScaleUp\":\"1\",\"responsiveSliderHeightMin\":\"0\",\"controlsTouch\":\"horizontal\",\"controlsScroll\":\"0\",\"controlsKeyboard\":\"1\",\"widget-arrow-enabled\":\"1\",\"widgetarrow\":\"imageEmpty\",\"widget-arrow-previous\":\"thin-horizontal.svg\",\"widget-arrow-previous-color\":\"ffffffcc\",\"widget-arrow-previous-hover\":\"0\",\"widget-arrow-previous-hover-color\":\"ffffffcc\",\"widget-arrow-style\":\"\",\"widget-arrow-previous-position-area\":\"6\",\"widget-arrow-previous-position-stack\":\"1\",\"widget-arrow-previous-position-offset\":\"15\",\"widget-arrow-next-position-area\":\"7\",\"widget-arrow-next-position-stack\":\"1\",\"widget-arrow-next-position-offset\":\"15\",\"widget-arrow-previous-alt\":\"previous arrow\",\"widget-arrow-next-alt\":\"next arrow\",\"widget-arrow-base64\":\"1\",\"widget-arrow-display-hover\":\"1\",\"widget-arrow-display-mobileportrait\":\"1\",\"widget-arrow-display-tabletportrait\":\"1\",\"widget-arrow-display-desktopportrait\":\"1\",\"widget-bullet-enabled\":\"0\",\"widgetbullet\":\"transition\",\"widget-bullet-position-area\":\"10\",\"widget-bullet-position-stack\":\"1\",\"widget-bullet-position-offset\":\"10\",\"widget-bullet-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"5|*|5|*|5|*|5|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"50\\\",\\\"extra\\\":\\\"margin: 4px;\\\"},{\\\"backgroundcolor\\\":\\\"1D81F9FF\\\"}]}\",\"widget-bullet-bar\":\"\",\"widget-bullet-thumbnail-show-image\":\"0\",\"widget-bullet-thumbnail-width\":\"60\",\"widget-bullet-thumbnail-height\":\"60\",\"widget-bullet-thumbnail-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"00000080\\\",\\\"padding\\\":\\\"3|*|3|*|3|*|3|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"3\\\",\\\"extra\\\":\\\"margin: 5px;\\\"}]}\",\"widget-bullet-thumbnail-side\":\"before\",\"widget-bullet-display-hover\":\"0\",\"widget-bullet-display-mobileportrait\":\"1\",\"widget-bullet-display-tabletportrait\":\"1\",\"widget-bullet-display-desktopportrait\":\"1\",\"widget-bar-enabled\":\"0\",\"widgetbar\":\"horizontal\",\"widget-bar-position-area\":\"10\",\"widget-bar-position-stack\":\"1\",\"widget-bar-position-offset\":\"30\",\"widget-bar-animate\":\"0\",\"widget-bar-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"5|*|20|*|5|*|20|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"40\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-bar-show-title\":\"1\",\"widget-bar-font-title\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000c7\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\",\\\"extra\\\":\\\"vertical-align: middle;\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-bar-show-description\":\"1\",\"widget-bar-font-description\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000c7\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":1,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\",\\\"extra\\\":\\\"vertical-align: middle;\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-bar-slide-count\":\"0\",\"widget-bar-full-width\":\"0\",\"widget-bar-separator\":\" - \",\"widget-bar-align\":\"center\",\"widget-bar-display-hover\":\"0\",\"widget-bar-display-mobileportrait\":\"1\",\"widget-bar-display-tabletportrait\":\"1\",\"widget-bar-display-desktopportrait\":\"1\",\"widget-thumbnail-enabled\":\"0\",\"widgetthumbnail\":\"default\",\"widget-thumbnail-width\":\"100\",\"widget-thumbnail-height\":\"60\",\"widget-thumbnail-position-area\":\"12\",\"widget-thumbnail-position-stack\":\"1\",\"widget-thumbnail-position-offset\":\"0\",\"widget-thumbnail-align-content\":\"start\",\"widget-thumbnail-style-bar\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"242424ff\\\",\\\"padding\\\":\\\"3|*|3|*|3|*|3|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"0\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-thumbnail-style-slides\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"00000000\\\",\\\"padding\\\":\\\"0|*|0|*|0|*|0|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|ffffff00\\\",\\\"borderradius\\\":\\\"0\\\",\\\"opacity\\\":\\\"40\\\",\\\"extra\\\":\\\"margin: 3px;\\\\ntransition: all 0.4s;\\\\nbackground-size: cover;\\\"},{\\\"border\\\":\\\"0|*|solid|*|ffffffcc\\\",\\\"opacity\\\":\\\"100\\\",\\\"extra\\\":\\\"\\\"}]}\",\"widget-thumbnail-title-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"3|*|10|*|3|*|10|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"0\\\",\\\"extra\\\":\\\"bottom: 0;\\\\nleft: 0;\\\"}]}\",\"widget-thumbnail-title\":\"0\",\"widget-thumbnail-title-font\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"12||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ab\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.2\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-thumbnail-description\":\"0\",\"widget-thumbnail-description-font\":\"{\\\"data\\\":[{\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"12||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ab\\\",\\\"afont\\\":\\\"Montserrat\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"bold\\\":0,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"left\\\"},{\\\"color\\\":\\\"fc2828ff\\\",\\\"afont\\\":\\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Raleway);),Arial\\\",\\\"size\\\":\\\"25||px\\\"},{}]}\",\"widget-thumbnail-caption-placement\":\"overlay\",\"widget-thumbnail-caption-size\":\"100\",\"widget-thumbnail-minimum-thumbnail-count\":\"2\",\"widget-thumbnail-display-hover\":\"0\",\"widget-thumbnail-display-mobileportrait\":\"0\",\"widget-thumbnail-display-tabletportrait\":\"1\",\"widget-thumbnail-display-desktopportrait\":\"1\",\"widget-shadow-enabled\":\"0\",\"widgetshadow\":\"shadow\",\"widget-shadow-shadow\":\"dark.png\",\"widget-shadow-display-mobileportrait\":\"0\",\"widget-shadow-display-tabletportrait\":\"1\",\"widget-shadow-display-desktopportrait\":\"1\",\"animation\":\"horizontal\",\"animation-duration\":\"800\",\"background-animation\":\"\",\"background-animation-color\":\"333333ff\",\"background-animation-speed\":\"normal\",\"autoplay\":\"1\",\"autoplayDuration\":\"8000\",\"autoplayStopClick\":\"1\",\"autoplayStopMouse\":\"0\",\"autoplayStopMedia\":\"1\",\"autoplayResumeClick\":\"0\",\"autoplayResumeMouse\":\"0\",\"autoplayResumeMedia\":\"1\",\"widget-autoplay-enabled\":\"0\",\"widgetautoplay\":\"image\",\"widget-autoplay-play\":\"small-light.svg\",\"widget-autoplay-play-color\":\"ffffffcc\",\"widget-autoplay-style\":\"{\\\"data\\\":[{\\\"backgroundcolor\\\":\\\"000000ab\\\",\\\"padding\\\":\\\"10|*|10|*|10|*|10|*|px\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"3\\\",\\\"extra\\\":\\\"\\\"},{\\\"backgroundcolor\\\":\\\"000000ab\\\"}]}\",\"widget-autoplay-position-area\":\"4\",\"widget-autoplay-position-stack\":\"1\",\"widget-autoplay-position-offset\":\"15\",\"widget-autoplay-display-hover\":\"0\",\"widget-autoplay-display-mobileportrait\":\"1\",\"widget-autoplay-display-tabletportrait\":\"1\",\"widget-autoplay-display-desktopportrait\":\"1\",\"optimize\":\"0\",\"optimize-quality\":\"70\",\"optimizeThumbnailWidth\":\"100\",\"optimizeThumbnailHeight\":\"60\",\"optimize-background-image-custom\":\"0\",\"optimize-background-image-width\":\"800\",\"optimize-background-image-height\":\"600\",\"loading-type\":\"afterOnLoad\",\"dependency\":\"\",\"delay\":\"0\",\"playWhenVisible\":\"1\",\"playWhenVisibleAt\":\"50\",\"is-delayed\":\"0\",\"backgroundMode\":\"blurfit\",\"clear-both\":\"1\",\"clear-both-after\":\"1\",\"overflow-hidden-page\":\"0\",\"responsiveFocusUser\":\"1\",\"responsiveFocusEdge\":\"auto\",\"classes\":\"\",\"custom-css-codes\":\"\",\"callbacks\":\"\",\"related-posts\":\"\"}","published","2020-08-07 06:36:22","","1");


DROP TABLE IF EXISTS `wp_nextend2_smartslider3_sliders_xref`;

CREATE TABLE `wp_nextend2_smartslider3_sliders_xref` (
  `group_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`,`slider_id`),
  KEY `ordering` (`ordering`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_nextend2_smartslider3_sliders_xref` VALUES("0","2","0");


DROP TABLE IF EXISTS `wp_nextend2_smartslider3_slides`;

CREATE TABLE `wp_nextend2_smartslider3_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `publish_up` (`publish_up`),
  KEY `publish_down` (`publish_down`),
  KEY `generator_id` (`generator_id`),
  KEY `ordering` (`ordering`),
  KEY `slider` (`slider`),
  KEY `thumbnail` (`thumbnail`(100))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("1","Slide Background","1","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[{\"type\":\"content\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":1120,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitselfalign\":\"center\",\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-IbNOabpfT5aE\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":1,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"row\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"desktopportraitgutter\":0,\"desktopportraitwrapafter\":0,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"tabletportraitgutter\":20,\"mobileportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"mobileportraitgutter\":20,\"mobileportraitwrapafter\":1,\"mobileportraitmaxwidth\":400,\"mobilelandscapewrapafter\":1,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-dtwtw9DVCwgQ\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"href\":\"\",\"href-target\":\"_self\",\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"ffffff00\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"borderwidth\":\"1|*|1|*|1|*|1\",\"borderstyle\":\"none\",\"bordercolor\":\"FFFFFFFF\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"fullwidth\":1,\"stretch\":0,\"name\":\"Row\",\"namesynced\":1,\"cols\":[{\"type\":\"col\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"left\",\"desktopportraitpadding\":\"10|*|10|*|10|*|10|*|px+\",\"desktopportraitorder\":0,\"tabletportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"mobileportraitinneralign\":\"left\",\"mobileportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"mobileportraitorder\":2,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-Fjvyu081qJeK\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"colwidth\":\"2/5\",\"href\":\"\",\"href-target\":\"_self\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"borderwidth\":\"0|*|0|*|0|*|0\",\"borderstyle\":\"solid\",\"bordercolor\":\"ffffffff\",\"name\":\"Column\",\"namesynced\":1,\"layers\":[{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":60,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Jeans Store Interior\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"36||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.2\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"01. Slide Background\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Lorem ipsum dolor sit amet, consect\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"24||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"weight\\\":300,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Every slide includes a background, which can be a picture or solid color.\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":100,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Latest Project\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffdb\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"uppercase\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Step 1\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":90,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Text\",\"namesynced\":1,\"item\":{\"type\":\"text\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"18||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.6\\\",\\\"weight\\\":400,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"}]}\",\"style\":\"\",\"content\":\"To change the background click on the label bar and in the layer window select the style tab.\",\"content-tablet-enabled\":\"0\",\"contenttablet\":\"\",\"content-mobile-enabled\":\"0\",\"contentmobile\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":100,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Latest Project\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffdb\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"uppercase\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Step 2\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":90,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Text\",\"namesynced\":1,\"item\":{\"type\":\"text\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"18||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.6\\\",\\\"weight\\\":400,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"}]}\",\"style\":\"\",\"content\":\"Choose a source from the background top tab then upload an image or pick a background color.\",\"content-tablet-enabled\":\"0\",\"contenttablet\":\"\",\"content-mobile-enabled\":\"0\",\"contentmobile\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Read More\",\"namesynced\":1,\"item\":{\"type\":\"button\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"center\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"0568f6ff\\\"}]}\",\"style\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"backgroundcolor\\\":\\\"0568f6ff\\\",\\\"opacity\\\":100,\\\"padding\\\":\\\"1|*|2|*|1|*|2|*|em\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"5\\\"},{\\\"extra\\\":\\\"\\\",\\\"backgroundcolor\\\":\\\"ffffffff\\\"}]}\",\"content\":\"Next Slide\",\"nowrap\":\"1\",\"fullwidth\":\"0\",\"href\":\"NextSlide[]\",\"href-target\":\"_self\",\"href-rel\":\"\",\"class\":\"\",\"icon\":\"\",\"iconsize\":\"100\",\"iconspacing\":\"30\",\"iconplacement\":\"left\"}}}]},{\"type\":\"col\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"left\",\"desktopportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitorder\":0,\"mobileportraitinneralign\":\"center\",\"mobileportraitorder\":1,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-LnImbm1HgUAv\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"colwidth\":\"3/5\",\"href\":\"\",\"href-target\":\"_self\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"borderwidth\":\"0|*|0|*|0|*|0\",\"borderstyle\":\"solid\",\"bordercolor\":\"ffffffff\",\"name\":\"Column\",\"namesynced\":1,\"layers\":[{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"mobileportraitmaxwidth\":300,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Image\",\"namesynced\":1,\"item\":{\"type\":\"image\",\"values\":{\"image\":\"https://smartslider3.com/wp-content/uploads/slider424/background.png\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"size\":\"auto|*|auto\",\"alt\":\"\",\"title\":\"\",\"href-class\":\"\"}}}]}]}]}]","","https://smartslider3.com/wp-content/uploads/slider424/slidebackground.jpg","{\"type\":\"slide\",\"desktopportraitfontsize\":100,\"desktopportraitpadding\":\"10|*|60|*|10|*|60\",\"tabletportraitpadding\":\"10|*|50|*|10|*|50\",\"mobileportraitpadding\":\"10|*|10|*|35|*|10\",\"record-slides\":0,\"thumbnailType\":\"default\",\"static-slide\":0,\"slide-duration\":0,\"ligthboxImage\":\"\",\"background-animation\":\"\",\"background-animation-color\":\"333333ff\",\"background-animation-speed\":\"default\",\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"href\":\"\",\"href-target\":\"\",\"background-type\":\"image\",\"backgroundColor\":\"ffffff00\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundColorOverlay\":0,\"backgroundImage\":\"https://smartslider3.com/wp-content/uploads/slider424/slide1.png\",\"backgroundFocusX\":50,\"backgroundFocusY\":50,\"backgroundImageOpacity\":100,\"backgroundImageBlur\":0,\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundMode\":\"default\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"version\":\"3.4.0\"}","1","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("2","Build & Design","1","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[{\"type\":\"content\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":1120,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitselfalign\":\"center\",\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-TPnUuKlAWVoC\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":1,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"layers\":[{\"type\":\"row\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitinneralign\":\"inherit\",\"desktopportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"desktopportraitgutter\":0,\"desktopportraitwrapafter\":0,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"tabletportraitgutter\":20,\"mobileportraitinneralign\":\"inherit\",\"mobileportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"mobileportraitgutter\":20,\"mobileportraitwrapafter\":1,\"mobileportraitmaxwidth\":400,\"mobileportraitselfalign\":\"inherit\",\"mobilelandscapewrapafter\":1,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-NmnNQvKK01kO\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"href\":\"\",\"href-target\":\"_self\",\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"ffffff00\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"borderwidth\":\"1|*|1|*|1|*|1\",\"borderstyle\":\"none\",\"bordercolor\":\"FFFFFFFF\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"fullwidth\":1,\"stretch\":0,\"name\":\"Row\",\"namesynced\":1,\"cols\":[{\"type\":\"col\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"left\",\"desktopportraitpadding\":\"10|*|10|*|10|*|10|*|px+\",\"desktopportraitorder\":0,\"tabletportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"mobileportraitmaxwidth\":0,\"mobileportraitinneralign\":\"left\",\"mobileportraitpadding\":\"10|*|0|*|10|*|0|*|px+\",\"mobileportraitorder\":2,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-R5Jkk06Nmzr4\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"colwidth\":\"2/5\",\"href\":\"\",\"href-target\":\"_self\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"borderwidth\":\"0|*|0|*|0|*|0\",\"borderstyle\":\"solid\",\"bordercolor\":\"ffffffff\",\"name\":\"Column\",\"namesynced\":1,\"layers\":[{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":60,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Jeans Store Interior\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"36||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.2\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"02. Build & Design\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Lorem ipsum dolor sit amet, consect\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"24||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.3\\\",\\\"weight\\\":300,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Build any layout with layers and customize your designs limitlessly.\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":100,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Latest Project\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffdb\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"uppercase\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Step 1\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":90,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Text\",\"namesynced\":1,\"item\":{\"type\":\"text\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"18||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.6\\\",\\\"weight\\\":400,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"}]}\",\"style\":\"\",\"content\":\"To add a layer, click the green plus button in the left sidebar and select the type of layer.\",\"content-tablet-enabled\":\"0\",\"contenttablet\":\"\",\"content-mobile-enabled\":\"0\",\"contentmobile\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":100,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Latest Project\",\"namesynced\":1,\"item\":{\"type\":\"heading\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffdb\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"uppercase\\\"},{\\\"extra\\\":\\\"\\\"}]}\",\"style\":\"\",\"priority\":\"div\",\"fullwidth\":\"1\",\"nowrap\":\"0\",\"heading\":\"Step 2\",\"title\":\"\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"split-text-transform-origin\":\"50|*|50|*|0\",\"split-text-backface-visibility\":\"1\",\"split-text-animation-in\":\"\",\"split-text-delay-in\":\"0\",\"split-text-animation-out\":\"\",\"split-text-delay-out\":\"0\",\"class\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":90,\"mobileportraitfontsize\":70,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Text\",\"namesynced\":1,\"item\":{\"type\":\"text\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffb0\\\",\\\"size\\\":\\\"18||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.6\\\",\\\"weight\\\":400,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"inherit\\\",\\\"letterspacing\\\":\\\"normal\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"1890d7ff\\\"}]}\",\"style\":\"\",\"content\":\"Select any layer and you can edit its content and style properties in the layer window.\",\"content-tablet-enabled\":\"0\",\"contenttablet\":\"\",\"content-mobile-enabled\":\"0\",\"contentmobile\":\"\"}}},{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"20|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"tabletportraitfontsize\":80,\"mobileportraitfontsize\":80,\"mobileportraitmargin\":\"10|*|0|*|0|*|0|*|px+\",\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Read More\",\"namesynced\":1,\"item\":{\"type\":\"button\",\"values\":{\"font\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"ffffffff\\\",\\\"size\\\":\\\"14||px\\\",\\\"tshadow\\\":\\\"0|*|0|*|0|*|000000ff\\\",\\\"afont\\\":\\\"Roboto\\\",\\\"lineheight\\\":\\\"1.5\\\",\\\"weight\\\":1,\\\"italic\\\":0,\\\"underline\\\":0,\\\"align\\\":\\\"center\\\",\\\"letterspacing\\\":\\\"1px\\\",\\\"wordspacing\\\":\\\"normal\\\",\\\"texttransform\\\":\\\"none\\\"},{\\\"extra\\\":\\\"\\\",\\\"color\\\":\\\"0568f6ff\\\"}]}\",\"style\":\"{\\\"data\\\":[{\\\"extra\\\":\\\"\\\",\\\"backgroundcolor\\\":\\\"0568f6ff\\\",\\\"opacity\\\":100,\\\"padding\\\":\\\"1|*|2|*|1|*|2|*|em\\\",\\\"boxshadow\\\":\\\"0|*|0|*|0|*|0|*|000000ff\\\",\\\"border\\\":\\\"0|*|solid|*|000000ff\\\",\\\"borderradius\\\":\\\"5\\\"},{\\\"extra\\\":\\\"\\\",\\\"backgroundcolor\\\":\\\"ffffffff\\\"}]}\",\"content\":\"Next Slide\",\"nowrap\":\"1\",\"fullwidth\":\"0\",\"href\":\"NextSlide[]\",\"href-target\":\"_self\",\"href-rel\":\"\",\"class\":\"\",\"icon\":\"\",\"iconsize\":\"100\",\"iconspacing\":\"30\",\"iconplacement\":\"left\"}}}]},{\"type\":\"col\",\"pm\":\"default\",\"desktopportraitfontsize\":100,\"desktopportraitmaxwidth\":0,\"desktopportraitinneralign\":\"left\",\"desktopportraitpadding\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitorder\":0,\"mobileportraitinneralign\":\"center\",\"mobileportraitorder\":1,\"opened\":1,\"id\":\"\",\"uniqueclass\":\"n-uc-iYi6ZKk8yeVp\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"bgimage\":\"\",\"bgimagex\":50,\"bgimagey\":50,\"bgcolor\":\"00000000\",\"bgcolorgradient\":\"off\",\"bgcolorgradientend\":\"00000000\",\"verticalalign\":\"center\",\"colwidth\":\"3/5\",\"href\":\"\",\"href-target\":\"_self\",\"borderradius\":0,\"boxshadow\":\"0|*|0|*|0|*|0|*|00000080\",\"borderwidth\":\"0|*|0|*|0|*|0\",\"borderstyle\":\"solid\",\"bordercolor\":\"ffffffff\",\"name\":\"Column\",\"namesynced\":1,\"layers\":[{\"type\":\"layer\",\"pm\":\"normal\",\"desktopportraitfontsize\":100,\"desktopportraitmargin\":\"0|*|0|*|0|*|0|*|px+\",\"desktopportraitheight\":0,\"desktopportraitmaxwidth\":0,\"desktopportraitselfalign\":\"inherit\",\"mobileportraitmaxwidth\":300,\"id\":\"\",\"uniqueclass\":\"\",\"generatorvisible\":\"\",\"zindex\":2,\"class\":\"\",\"crop\":\"visible\",\"rotation\":0,\"parallax\":0,\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"name\":\"Image\",\"namesynced\":1,\"item\":{\"type\":\"image\",\"values\":{\"image\":\"https://smartslider3.com/wp-content/uploads/slider424/buildanddesign.png\",\"href\":\"#\",\"href-target\":\"_self\",\"href-rel\":\"\",\"size\":\"auto|*|auto\",\"alt\":\"\",\"title\":\"\",\"href-class\":\"\"}}}]}]}]}]","","https://smartslider3.com/wp-content/uploads/slider424/buildanddesign.jpg","{\"type\":\"slide\",\"desktopportraitfontsize\":100,\"desktopportraitpadding\":\"10|*|60|*|10|*|60\",\"tabletportraitpadding\":\"10|*|50|*|10|*|50\",\"mobileportraitpadding\":\"10|*|10|*|35|*|10\",\"record-slides\":0,\"thumbnailType\":\"default\",\"static-slide\":0,\"slide-duration\":0,\"ligthboxImage\":\"\",\"background-animation\":\"\",\"background-animation-color\":\"333333ff\",\"background-animation-speed\":\"default\",\"adaptivefont\":0,\"desktopportrait\":1,\"desktoplandscape\":1,\"tabletportrait\":1,\"tabletlandscape\":1,\"mobileportrait\":1,\"mobilelandscape\":1,\"href\":\"\",\"href-target\":\"\",\"background-type\":\"image\",\"backgroundColor\":\"ffffff00\",\"backgroundGradient\":\"off\",\"backgroundColorEnd\":\"ffffff00\",\"backgroundColorOverlay\":0,\"backgroundImage\":\"https://smartslider3.com/wp-content/uploads/slider424/slide2.png\",\"backgroundFocusX\":50,\"backgroundFocusY\":50,\"backgroundImageOpacity\":100,\"backgroundImageBlur\":0,\"backgroundAlt\":\"\",\"backgroundTitle\":\"\",\"backgroundMode\":\"default\",\"guides\":\"eyJob3Jpem9udGFsIjpbXSwidmVydGljYWwiOltdfQ==\",\"version\":\"3.4.0\"}","2","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("3","Bild_08","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_08.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_08.jpeg\",\"version\":\"3.4.1.8\"}","1","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("4","Bild_07","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_07.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_07.jpeg\",\"version\":\"3.4.1.8\"}","3","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("5","Bild_09","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_09.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_09.jpeg\",\"version\":\"3.4.1.8\"}","5","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("6","Bild_06","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_06.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_06.jpeg\",\"version\":\"3.4.1.8\"}","7","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("7","Bild_04","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_04.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_04.jpeg\",\"version\":\"3.4.1.8\"}","9","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("8","Bild_12","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_12.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_12.jpeg\",\"version\":\"3.4.1.8\"}","11","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("9","Bild_05","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_05.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_05.jpeg\",\"version\":\"3.4.1.8\"}","13","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("10","Bild_13","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_13.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_13.jpeg\",\"version\":\"3.4.1.8\"}","15","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("11","Bild_15","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_15.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_15.jpeg\",\"version\":\"3.4.1.8\"}","17","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("12","Bild_16","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_16.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_16.jpeg\",\"version\":\"3.4.1.8\"}","19","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("13","Bild_17","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_17.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_17.jpeg\",\"version\":\"3.4.1.8\"}","21","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("14","Bild_14","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_14.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_14.jpeg\",\"version\":\"3.4.1.8\"}","23","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("15","Bild_10","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_10.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_10.jpeg\",\"version\":\"3.4.1.8\"}","25","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("16","Bild_18","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_18.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_18.jpeg\",\"version\":\"3.4.1.8\"}","27","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("17","Bild_11","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_11.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_11.jpeg\",\"version\":\"3.4.1.8\"}","29","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("18","Bild_19","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_19.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_19.jpeg\",\"version\":\"3.4.1.8\"}","31","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("19","Bild_22","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_22.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_22.jpeg\",\"version\":\"3.4.1.8\"}","33","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("20","Bild_20","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_20.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_20.jpeg\",\"version\":\"3.4.1.8\"}","35","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("21","Bild_24","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_24.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_24.jpeg\",\"version\":\"3.4.1.8\"}","37","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("22","Bild_23","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_23.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_23.jpeg\",\"version\":\"3.4.1.8\"}","39","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("23","Bild_25","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_25.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_25.jpeg\",\"version\":\"3.4.1.8\"}","41","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("24","Bild_27","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_27.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_27.jpeg\",\"version\":\"3.4.1.8\"}","43","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("25","Bild_28","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_28.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_28.jpeg\",\"version\":\"3.4.1.8\"}","45","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("26","Bild_29","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_29.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_29.jpeg\",\"version\":\"3.4.1.8\"}","47","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("27","Bild_21","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_21.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_21.jpeg\",\"version\":\"3.4.1.8\"}","49","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("28","Bild_31","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_31.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_31.jpeg\",\"version\":\"3.4.1.8\"}","51","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("29","Bild_26","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_26.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_26.jpeg\",\"version\":\"3.4.1.8\"}","53","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("30","Bild_02","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_02.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_02.jpeg\",\"version\":\"3.4.1.8\"}","55","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("31","Bild_03","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_03.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_03.jpeg\",\"version\":\"3.4.1.8\"}","57","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("32","Bild_01","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_01.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_01.jpeg\",\"version\":\"3.4.1.8\"}","59","0");
INSERT INTO `wp_nextend2_smartslider3_slides` VALUES("33","Bild_30","2","1970-01-01 00:00:00","1970-01-01 00:00:00","1","0","[]","","$upload$/slider2/Bild_30.jpeg","{\"background-type\":\"image\",\"backgroundImage\":\"$upload$/slider2/Bild_30.jpeg\",\"version\":\"3.4.1.8\"}","61","0");


DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://localhost","yes");
INSERT INTO `wp_options` VALUES("2","home","http://localhost","yes");
INSERT INTO `wp_options` VALUES("3","blogname","Skyloft Climbing park","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","For your excitement!","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","skyloft@example.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("29","rewrite_rules","a:94:{s:11:\"sitemap.xml\";s:33:\"index.php?aiosp_sitemap_path=root\";s:21:\"(.+)-sitemap(\\d+).xml\";s:71:\"index.php?aiosp_sitemap_path=$matches[1]&aiosp_sitemap_page=$matches[2]\";s:16:\"(.+)-sitemap.xml\";s:40:\"index.php?aiosp_sitemap_path=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=5&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:5:{i:0;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:33:\"smart-slider-3/smart-slider-3.php\";i:4;s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","0","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","wp-bootstrap-starter","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","skyloft","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","45805","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","0","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","page","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:1:{s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";s:20:\"sfsi_Unistall_plugin\";}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","5","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","76","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("93","admin_email_lifespan","1612332578","yes");
INSERT INTO `wp_options` VALUES("94","initial_db_version","45805","yes");
INSERT INTO `wp_options` VALUES("95","wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:66:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:11:\"smartslider\";b:1;s:18:\"smartslider_config\";b:1;s:16:\"smartslider_edit\";b:1;s:18:\"smartslider_delete\";b:1;s:16:\"aiosp_manage_seo\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:38:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:11:\"smartslider\";b:1;s:18:\"smartslider_config\";b:1;s:16:\"smartslider_edit\";b:1;s:18:\"smartslider_delete\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("96","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("97","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("98","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","sidebars_widgets","a:8:{s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}s:19:\"wp_inactive_widgets\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-1\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:18:\"smartslider_area_1\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("103","cron","a:10:{i:1596791380;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1596793869;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1596823779;a:2:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1596823780;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1596866979;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1596866995;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1596867358;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1596876351;a:1:{s:33:\"aioseop_cron_check_remote_notices\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1596876669;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("104","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("114","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("118","theme_mods_twentytwenty","a:10:{s:18:\"custom_css_post_id\";i:-1;s:16:\"background_color\";s:6:\"ffffff\";s:30:\"header_footer_background_color\";s:7:\"#005ca8\";s:17:\"accent_hue_active\";s:7:\"default\";s:10:\"accent_hue\";i:344;s:24:\"accent_accessible_colors\";a:2:{s:7:\"content\";a:5:{s:4:\"text\";s:7:\"#000000\";s:6:\"accent\";s:7:\"#e22658\";s:10:\"background\";s:7:\"#ffffff\";s:7:\"borders\";s:7:\"#dbdbdb\";s:9:\"secondary\";s:7:\"#6d6d6d\";}s:13:\"header-footer\";a:5:{s:4:\"text\";s:7:\"#ffffff\";s:6:\"accent\";s:7:\"#f2c9d1\";s:10:\"background\";s:7:\"#005ca8\";s:7:\"borders\";s:7:\"#0073d1\";s:9:\"secondary\";s:7:\"#d4e2f0\";}}s:20:\"enable_header_search\";b:0;s:18:\"nav_menu_locations\";a:2:{s:7:\"primary\";i:2;s:8:\"expanded\";i:0;}s:15:\"show_author_bio\";b:0;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1596783726;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("123","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.4.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.2\";s:7:\"version\";s:5:\"5.4.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.4.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.4.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.4.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.4.2\";s:7:\"version\";s:5:\"5.4.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1596790256;s:15:\"version_checked\";s:5:\"5.3.4\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("126","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:19:\"skyloft@example.com\";s:7:\"version\";s:5:\"5.3.4\";s:9:\"timestamp\";i:1596780591;}","no");
INSERT INTO `wp_options` VALUES("127","_site_transient_timeout_browser_72f533ef66d493b897f3cfc643e15448","1597385392","no");
INSERT INTO `wp_options` VALUES("128","_site_transient_browser_72f533ef66d493b897f3cfc643e15448","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"84.0.4147.105\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("129","_site_transient_timeout_php_check_413a4f2c91fec3a4996c65b3565c8cb8","1597385392","no");
INSERT INTO `wp_options` VALUES("130","_site_transient_php_check_413a4f2c91fec3a4996c65b3565c8cb8","a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("131","can_compress_scripts","1","no");
INSERT INTO `wp_options` VALUES("132","_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e","1596830479","no");
INSERT INTO `wp_options` VALUES("133","_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e","a:3:{s:9:\"sandboxed\";b:0;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:5:{i:0;a:8:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:50:\"Laten we het hebben over backups - WPmeetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrybclbrb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2020-08-13 18:45:00\";s:8:\"end_date\";s:19:\"2020-08-13 20:55:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:1;a:8:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrybcmbnb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2020-09-10 18:45:00\";s:8:\"end_date\";s:19:\"2020-09-10 20:55:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:2;a:8:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrybcnblb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2020-10-08 18:45:00\";s:8:\"end_date\";s:19:\"2020-10-08 20:55:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:3;a:8:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrybcpbqb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2020-11-12 18:45:00\";s:8:\"end_date\";s:19:\"2020-11-12 20:55:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}i:4;a:8:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:23:\"WordPress Meetup Zwolle\";s:3:\"url\";s:68:\"https://www.meetup.com/Zwolle-WordPress-Meetup/events/nsmmmrybcqbnb/\";s:6:\"meetup\";s:23:\"WordPress Meetup Zwolle\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Zwolle-WordPress-Meetup/\";s:4:\"date\";s:19:\"2020-12-10 18:45:00\";s:8:\"end_date\";s:19:\"2020-12-10 20:55:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Zwolle, Netherlands\";s:7:\"country\";s:2:\"nl\";s:8:\"latitude\";d:52.508583068848;s:9:\"longitude\";d:6.0933017730713;}}}}","no");
INSERT INTO `wp_options` VALUES("134","_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3","1596823794","no");
INSERT INTO `wp_options` VALUES("135","_transient_feed_9bbd59226dc36b9b26cd43f15694c5c3","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Aug 2020 13:07:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.6-alpha-48742\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WordPress 5.5 Release Candidate 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2020/08/wordpress-5-5-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2020 19:12:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8764\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:420:\"The second release candidate for WordPress 5.5 is here! WordPress 5.5 is slated for release&#160;on&#160;August 11, 2020, but we need&#160;your&#160;help to get there—if you haven’t tried 5.5 yet,&#160;now is the time! You can test the WordPress 5.5 release candidate in two ways: Try the&#160;WordPress Beta Tester&#160;plugin (choose the “bleeding edge nightlies” option) Or&#160;download the release [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2503:\"
<p>The second release candidate for WordPress 5.5 is here!</p>



<p>WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;now is the time!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC2.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>For a more detailed breakdown of the changes included in WordPress 5.5, check out the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">WordPress 5.5 beta 1 post</a>. The&nbsp;<a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">WordPress 5.5 Field Guide</a>&nbsp;is also out! It’s your source for details on all the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the&nbsp;<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8764\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: July 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2020/08/the-month-in-wordpress-july-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Aug 2020 13:54:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8755\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:340:\"July was an action-packed month for the WordPress project. The month saw a lot of updates on one of the most anticipated releases &#8211; WordPress 5.5! WordCamp US 2020 was canceled and the WordPress community team started experimenting with different formats for engaging online events, in July. Read on to catch up with all the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:11539:\"
<p>July was an action-packed month for the WordPress project. The month saw a lot of updates on one of the most anticipated releases &#8211; WordPress 5.5! WordCamp US 2020 was canceled and the WordPress community team started experimenting with different formats for engaging online events, in July. Read on to catch up with all the updates from the WordPress world.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5 Updates</h2>



<p>July was full of WordPress 5.5 updates! The WordPress 5.5 <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1\">Beta 1</a> came out on July 7, followed by <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">Beta 2</a> on July 14, <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">Beta 3</a> on July 21, and <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\">Beta 4</a> on July 27. Subsequently, the team also published the first <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\">release candidate</a> of WordPress 5.5 on July 28.&nbsp;</p>



<p>WordPress 5.5, which is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11, 2020</a>, is a major update with features like <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic updates for plugins and themes</a>, a <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">block directory</a>, <a href=\"https://make.wordpress.org/core/2020/06/10/merge-announcement-extensible-core-sitemaps/\">XML sitemaps</a>, <a href=\"https://make.wordpress.org/core/2020/07/16/block-patterns-in-wordpress-5-5/\">block patterns</a>, and <a href=\"https://make.wordpress.org/core/2020/07/14/lazy-loading-images-in-5-5/\">lazy-loading images</a>, among others. To learn more about the release, check out its <a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">field guide post</a>.</p>



<p>Want to get involved in building WordPress Core? Follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 8.5 and 8.6</h2>



<p>The core team launched Gutenberg <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>. Version 8.5 &#8211; the last plugin release will be included entirely (without experimental features) in WordPress 5.5, introduced improvements to block drag-and-drop and accessibility, easier updates for external images, and support for the block directory. Version 8.6 comes with features like Cover block video position controls and block pattern updates. For full details on the latest versions on these Gutenberg releases, visit these posts about <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Reimagining Online WordPress Events</h2>



<p>The Community team made the difficult decision <a href=\"https://make.wordpress.org/community/2020/07/27/in-person-events-in-rest-of-year-2020/\">to suspend in-person WordPress events for the rest of 2020</a> in light of the COVID-19 pandemic. The team has also started working on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/\">reimagining online events</a>. Based on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/#comment-28505\">feedback from the community members</a>, the team decided to <a href=\"https://make.wordpress.org/community/2020/07/23/moving-forward-with-online-events/\">make changes to the current online WordCamp format</a>. Key changes include wrapping up financial support for A/V vendors, ending event swag support for newer online WordCamps, and suspending the Global Community Sponsorship program for 2020. The team encourages upcoming online WordCamps to experiment with their events to facilitate an effective learning experience for attendees while avoiding online event fatigue. The team is currently working on a proposal to organize community-supported <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">recorded workshops and synchronous discussion groups</a> to help community members learn WordPress.<br><br>Want to get involved with the Community team? <a href=\"https://make.wordpress.org/community/\">Follow the Community blog here</a>, or join them in the #community-events channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. To organize a Meetup or WordCamp, <a href=\"https://make.wordpress.org/community/handbook/virtual-events/welcome/applying-for-a-virtual-event/\">visit the handbook page</a>.&nbsp;</p>



<h2>WordCamp US 2020 is canceled</h2>



<p>The organizers of WordCamp US 2020 have <a href=\"https://2020.us.wordcamp.org/2020/07/30/wcus-2020-an-update/\">canceled the event</a> in light of the continued pandemic and online event fatigue. The flagship event, which was originally scheduled for October 27-29 as an in-person event, had already planned to transition to an online event. Several WCUS Organizers will be working with the WordPress Community team to focus on other formats and ideas for online events, including a 24-hour contributor day, and contributing to the workshops initiative <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">currently being discussed</a>. Matt Mullenweg’s State of the Word (which typically accompanies WordCamp US) is likely to take place in a different format later in 2020.</p>



<h2>Plugin and theme updates are now available over zip files</h2>



<p>After eleven years, WordPress now allows users to update plugins and themes by <a href=\"https://core.trac.wordpress.org/changeset/48390\">uploading a ZIP file, in WordPress 5.5</a>.&nbsp; The feature, which was merged on July 7, has been one of the most requested features in WordPress. Now, when a user tries to upload a plugin or theme zip file from the WordPress dashboard by clicking the “Install Now” button, WordPress will direct users to a new screen that compares the currently-installed extension with the uploaded versions. Users can then choose between continuing with the installation or canceling. WordPress 5.5 will also offer <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic plugin and theme updates</a>.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">Block directory</a> is coming to WordPress with the 5.5 release. Plugin authors can now <a href=\"https://make.wordpress.org/plugins/2020/07/11/you-can-now-add-your-own-plugins-to-the-block-directory/\">submit their Block plugins to the directory</a>.</li><li>The Core team has opened up the <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">call for features</a> in the WordPress 5.6 release. You can <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">comment on the post</a> with features that you’d like to be included, current UX pain points, or maintenance tickets that need to be addressed. August 20 is the deadline for feature requests. </li><li>Editor features such as the new Navigation block, the navigation screen, and the widget screen that were originally <a href=\"https://make.wordpress.org/updates/2020/03/06/update-progress-on-goals/\">planned to be merged with WordPress 5.5</a> have been <a href=\"https://make.wordpress.org/core/2020/07/02/editor-features-for-wordpress-5-5-update/\">pushed for the next release</a>. </li><li>The Theme team is inviting proposals on whether to allow themes to <a href=\"https://make.wordpress.org/themes/2020/07/13/proposal-allow-themes-to-add-a-top-level-admin-menu/\">place an additional top-level menu link</a> in the admin.</li><li><a href=\"https://buddypress.org/2020/07/buddypress-6-2-0-beta/\">BuddyPress 6.2 beta </a>is out in the wild, and the team will soon release the stable version. The update includes changes that will make BuddyPress fully compatible with WordPress 5.5.</li><li>WordCamp EU 2021, which was being planned as an in-person event in Porto, Portugal, <a href=\"https://europe.wordcamp.org/2021/wordcamp-europe-2021-will-be-online/\">is moving online</a>. The team is considering an in-person WordCamp EU in 2022. </li><li>The Polyglots team has prepared and finalized a <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">Translation Editor &amp; Locale Manager Vetting Criteria</a> to provide more clarity on how global mentors assign PTE/GTE/Locale Managers and to help locale teams set their own guidelines. The document, which was finalized <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">after a lot of discussion</a>, is now available in the <a href=\"https://make.wordpress.org/polyglots/handbook/translating/expectations/translation-editor-locale-manager-vetting-criteria/\">Polyglots handbook</a>.</li><li>Members of the Community team <a href=\"https://make.wordpress.org/community/2020/07/03/proposal-recognition-for-event-volunteers-and-attendees-in-wordpress-org-profile/\">are discussing</a> whether WordCamp volunteers, WordCamp attendees, or Meetup attendees should be awarded a WordPress.org profile badge. The ongoing discussion will be open for comments until August 13.</li><li>The <a href=\"https://make.wordpress.org/core/tag/feature-notifications/\">WP Notify project</a>, which aims to create a better way to manage and deliver notifications to the relevant audience, is on to its next steps. The team has finalized the initial requirements, and is <a href=\"https://make.wordpress.org/core/2020/07/09/wp-notify-next-steps/\">kicking off the project build</a>.</li><li>The WordPress documentation team is <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\" target=\"_blank\">considering a ban on links to commercial websites</a> in a revision to its external linking policy. The policy change does not remove external links to commercial sites from WordPress.org and only applies to documentation sites. The idea is to protect documentation from being abused, and to prevent the WordPress project from being biased. Discussion on this post is still ongoing, and a decision has not yet been made. Feel free to<a href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\"> comment on the discussion posts</a>, if you would like to share your thoughts on the topic. </li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8755\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 5.5 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2020 19:08:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8732\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:370:\"The first release candidate for WordPress 5.5 is now available! This is an important milestone in the community&#8217;s progress toward the final release of WordPress 5.5. “Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.5 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2970:\"
<p>The first release candidate for WordPress 5.5 is now available!</p>



<p>This is an important milestone in the community&#8217;s progress toward the final release of WordPress 5.5. </p>



<p>“Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;<strong>now is the time</strong>!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC1.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>What’s in WordPress 5.5?</h2>



<p>WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developer notes</a>&nbsp;tag for updates on those and other changes that could affect your products.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>The&nbsp;WordPress 5.5 Field Guide, due very shortly, will give you a more detailed dive into the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the <a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8732\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 20:56:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8719\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:313:\"WordPress 5.5 Beta 4 is now available! This software is still in development, so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 Beta 4 in two ways: Try the WordPress Beta Tester plugin (choose the [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Baumwald\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3812:\"
<p>WordPress 5.5 Beta 4 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong> so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 4 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta4.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">beta 3</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-3/\">beta 3</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F22%2F2020..07%2F28%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 4:</p>



<ul><li>Add <code>\"loading\"</code> as an allowed kses image attribute (see <a href=\"https://core.trac.wordpress.org/ticket/50731\">#50731</a>).</li><li>Add filter for the plugin/theme auto-update message in the Info tab of Site health (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50663\">#50663</a>).</li><li><code>$_SERVER[\'SERVER_NAME\']</code> not a reliable when generating email host names (see <a href=\"https://core.trac.wordpress.org/ticket/25239\">#25239</a>)</li><li>Several backported fixes from Gutenberg are included in WordPress 5.5 Beta 4 (<a href=\"https://github.com/WordPress/gutenberg/pull/24218\">See PR #24218</a>)</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2020 17:51:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:324:\"WordPress 5.5 Beta 3 is now available! This software is still in development,so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 Beta 3 in two ways: Try the WordPress Beta Tester plugin (choose the “bleeding [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3876:\"
<p>WordPress 5.5 Beta 3 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 3 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta3.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">beta 2</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-2/\">beta 2</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F15%2F2020..07%2F21%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 3:</p>



<ul><li>Plugin and theme versions are now shared in the emails when automatically updated (see <a href=\"https://core.trac.wordpress.org/ticket/50350\">#50350</a>).</li><li>REST API routes without a <code>permission_callback</code> now trigger a <code>_doing_it_wrong()</code> warning (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50075\">#50075</a>).</li><li>Over 23 Gutenberg changes and updates (see <a href=\"https://github.com/WordPress/gutenberg/pull/24068\">#24068</a> and <a href=\"https://core.trac.wordpress.org/ticket/50712\">#50712</a>).</li><li>A bug with the new import and export database Dashicons has been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8706\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2020 17:24:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8681\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:358:\"WordPress 5.5 Beta 2 is now available! This software is still in development,&#160;so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test WordPress 5.5 beta 2 in two ways: Try the&#160;WordPress Beta Tester&#160;plugin (choose the “bleeding edge nightlies” [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4552:\"
<p id=\"block-000046ff-d8e6-40a8-9869-2dd39e50f270\"><br>WordPress 5.5 Beta 2 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong><strong>This software is still in development,</strong>&nbsp;</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 beta 2 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-beta2.zip\">download the beta here</a>&nbsp;(zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on&nbsp;<a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors that tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">beta 1</a> development release and provided feedback. Testing for bugs is an important part of polishing each release and a great way to contribute to WordPress. Here are some of the changes since beta 1 to pay close attention to while testing.</p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-1/\">beta 1</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=07%2F08%2F2020..07%2F14%2F2020&amp;milestone=5.5&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">48 bugs</a> have been fixed. Here is a summary of a few changes included in beta 2:</p>



<ul><li>19 additional bugs have been fixed in the block editor (see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>).</li><li>The Dashicons icon font has been updated (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li><li>Broken widgets stemming from changes in Beta 1 have been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/50609\">#50609</a>).</li><li>Query handling when counting revisions has been improved (see <a href=\"https://core.trac.wordpress.org/ticket/34560\">#34560</a>).</li><li>An alternate, expanded view was added for <code>wp_list_table</code> (see <a href=\"https://core.trac.wordpress.org/ticket/49715\">#49715</a>).</li><li>Some adjustments were made to the handling of default terms for custom taxonomies (see <a href=\"https://core.trac.wordpress.org/ticket/43517\">#43517</a>)</li></ul>



<p>Several updates have been made to the block editor. For details, see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>.</p>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a>&nbsp;for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help us translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>,&nbsp;where you can also find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8681\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.5 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jul 2020 21:49:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8624\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:358:\"WordPress 5.5 Beta 1 is now available for testing! This software is still in development,&#160;so it&#8217;s not recommended to run this version on a production site. Consider setting up a test site to play with the new version. You can test the WordPress 5.5 beta in two ways: Try the&#160;WordPress Beta Tester&#160;plugin (choose the “bleeding [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9697:\"
<p>WordPress 5.5 Beta 1 is now available for testing!</p>



<p><strong>This software is still in development,</strong>&nbsp;so it&#8217;s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p>You can test the WordPress 5.5 beta in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-beta1.zip\">download the beta here&nbsp;(zip)</a>.</li></ul>



<p>The current target for final release is August 11, 2020. This is only <strong>five weeks away</strong>. Your help is needed to ensure this release is tested properly.</p>



<p>Testing for bugs is an important part of polishing the release during the beta stage and a great way to contribute. Here are some of the big changes and features to pay close attention to while testing.</p>



<h2><strong>Block editor: features and improvements</strong></h2>



<p>WordPress 5.5 will include eleven releases of the Gutenberg plugin, bringing with it a long list of exciting new features. Here are just a few:</p>



<ul><li><strong>Inline image editing &#8211; </strong>Crop, rotate, and zoom photos inline right from image blocks.</li><li><strong>Block patterns</strong> &#8211; Building elaborate pages can be a breeze with new block patterns. Several are included by default.</li><li><strong>Device previews</strong> &#8211; See how your content will look to users on many different screen sizes. </li><li><strong>End block overwhelm</strong>. The new block inserter panel displays streamlined categories and collections. As a bonus, it supports patterns and integrates with the new block directory right out of the box.</li><li><strong>Discover, install, and insert third-party blocks</strong> from your editor using the new block directory.</li><li>A better, <strong>smoother editing experience </strong>with:&nbsp;<ul><li>Refined drag-and-drop</li><li>Block movers that you can see and grab</li><li>Parent block selection</li><li>Contextual focus highlights</li><li>Multi-select formatting lets you change a bunch of blocks at once&nbsp;</li><li>Ability to copy and relocate blocks easily</li><li>And, better performance</li></ul></li><li><strong>An expanded design toolset for themes.</strong></li><li>Now <strong>add backgrounds and gradients</strong> to more kinds of blocks, like groups, columns, media &amp; text</li><li>And <strong>support for more types of measurements</strong> &#8212; not just pixels. Choose ems, rems, percentages, vh, vw, and more! Plus, adjust line heights while typing, turning writing and typesetting into the seamless act.</li></ul>



<p>In all, WordPress 5.5 brings more than 1,500 useful improvements to the block editor experience.&nbsp;</p>



<p>To see all of the features for each release in detail check out the release posts: <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v7.5.0\">7.5</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v7.6.0\">7.6</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v7.7.0\">7.7</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v7.8.0\">7.8</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v7.9.0\">7.9</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.0.0\">8.0</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.1.0\">8.1</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.2.0\">8.2</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.3.0\">8.3</a>, <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.4.0\">8.4</a>, and <a href=\"https://github.com/WordPress/gutenberg/releases/tag/v8.5.0\">8.5</a>.</p>



<h2><strong>Wait! There’s more!</strong></h2>



<h3><strong>XML sitemaps</strong></h3>



<p><a href=\"https://make.wordpress.org/core/2020/06/10/merge-announcement-extensible-core-sitemaps/\">XML Sitemaps are now included in WordPress</a> and enabled by default. Sitemaps are essential to search engines discovering the content on your website. Your site&#8217;s home page, posts, pages, custom post types, and more will be included to improve your site&#8217;s visibility.</p>



<h3><strong>Auto-updates for plugins and themes</strong></h3>



<p><a href=\"https://make.wordpress.org/core/tag/core-auto-updates/\">WordPress 5.5 also brings auto-updates for plugins and themes</a>. Easily control which plugins and themes keep themselves up to date on their own. It&#8217;s always recommended that you run the latest versions of all plugins and themes. The addition of this feature makes that easier than ever!</p>



<h3><strong>Lazy-loading images</strong></h3>



<p><a href=\"https://make.wordpress.org/core/2020/04/08/lazy-loading-of-images-is-in-core/\">WordPress 5.5 will include native support for lazy-loaded images</a> utilizing new browser standards. With lazy-loading, images will not be sent to users until they approach the viewport. This saves bandwidth for everyone (users, hosts, ISPs), makes it easier for those with slower internet speeds to browse the web, saves electricity, and more.</p>



<h3><strong>Better accessibility</strong></h3>



<p>With every release, WordPress works hard to improve accessibility. Version 5.5 is no different and packs a parcel of accessibility fixes and enhancements. Take a look:</p>



<ul><li>List tables now come with extensive, alternate view modes.</li><li>Link-list widgets can now be converted to HTML5 navigation blocks.</li><li>Copying links in media screens and modal dialogs can now be done with a simple click of a button.</li><li>Disabled buttons now actually look disabled.</li><li>Meta boxes can now be moved with the keyboard.</li><li>A custom logo on the front page no longer links to the front page.</li><li>Assistive devices can now see status messages in the Image Editor.</li><li>The shake animation indicating a login failure now respects the user&#8217;s choices in the <code>prefers-reduced-motion</code> media query.</li><li>Redundant <code>Error:</code> prefixes have been removed from error notices.</li></ul>



<h2><strong>Miscellaneous Changes</strong></h2>



<ul><li>Plugins and themes can now be updated by uploading a ZIP file.</li><li><a href=\"https://make.wordpress.org/core/2020/06/26/wordpress-5-5-better-fine-grained-control-of-redirect_guess_404_permalink/\">More finely grained control of redirect_guess_404_permalink()</a>.</li><li><a href=\"https://make.wordpress.org/core/2020/07/01/external-library-updates-in-wordpress-5-5-call-for-testing/\">Several packaged external libraries have been updated</a>, including PHPMailer, SimplePie, Twemoji, Masonry, and more!</li></ul>



<p>Keep your eyes on the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">5.5-related developer notes</a> in the coming weeks, breaking down these and other changes in greater detail.</p>



<p>So far, contributors have fixed more than <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.5&amp;group=component&amp;max=500&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">360 tickets in WordPress 5.5</a>, including <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;status=reopened&amp;type=enhancement&amp;milestone=5.5&amp;or&amp;status=closed&amp;status=reopened&amp;type=feature+request&amp;milestone=5.5&amp;col=id&amp;col=summary&amp;col=type&amp;col=status&amp;col=milestone&amp;col=owner&amp;col=priority&amp;col=changetime&amp;col=keywords&amp;order=changetime\">157 new features and enhancements</a>, and more bug fixes are on the way.</p>



<h2><strong>How You Can Help</strong></h2>



<p>Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p>If you think you’ve found a bug, please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We would love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>. That’s also where you can find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>



<p class=\"has-small-font-size\"><em>Props to <a href=\'https://profiles.wordpress.org/webcommsat/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>webcommsat</a>, <a href=\'https://profiles.wordpress.org/yvettesonneveld/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>yvettesonneveld</a>, <a href=\'https://profiles.wordpress.org/estelaris/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>estelaris</a>, and <a href=\'https://profiles.wordpress.org/marybaum/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>marybaum</a> for compiling/writing this post, <a href=\'https://profiles.wordpress.org/davidbaumwald/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>davidbaumwald</a> for editing/proof reading, and <a href=\'https://profiles.wordpress.org/cbringmann/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>cbringmann</a>, <a href=\'https://profiles.wordpress.org/desrosj/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>desrosj</a>, and <a href=\'https://profiles.wordpress.org/andreamiddleton/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>andreamiddleton</a> for final review.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8624\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:57:\"
		
		
		
		
		
				
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: June 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2020/07/the-month-in-wordpress-june-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2020 05:52:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8614\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:353:\"June was an exciting month for WordPress! Major changes are coming to the Gutenberg plugin, and WordCamp Europe brought the WordPress community closer together. Read on to learn more and to get all the latest updates.&#160; WordPress 5.4.2 released We said hello to WordPress 5.4.2 on June 10. This security and maintenance release features 17 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7872:\"
<p>June was an exciting month for WordPress! Major changes are coming to the Gutenberg plugin, and WordCamp Europe brought the WordPress community closer together. Read on to learn more and to get all the latest updates.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.4.2 released</h2>



<p>We said hello to WordPress 5.4.2 on June 10. This security and maintenance release features 17 fixes and 4 enhancements, so we recommend that you update your sites immediately. To download WordPress 5.4.2, visit your Dashboard, click on <strong>Updates</strong>, then <strong>Update Now</strong>, or download the latest version directly from WordPress.org. For more information, visit <a href=\"https://wordpress.org/news/2020/06/wordpress-5-4-2-security-and-maintenance-release/\">this post</a>, review the <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.4.2&amp;order=priority\">full list of changes on Trac</a>, or check out the <a href=\"https://wordpress.org/support/wordpress-version/version-5-4-2/\">HelpHub documentation page</a> for <a href=\"https://wordpress.org/support/wordpress-version/version-5-4-2/\">version 5.4.2</a>. WordPress 5.4.2 is a short-cycle maintenance release. The next major release will be <a href=\"https://make.wordpress.org/core/5-5/\">version 5.5</a>, <a href=\"https://wordpress.org/about/roadmap/\">planned for August 2020</a>. <br><br>Want to get involved in building WordPress Core? Follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 8.3 and 8.4</h2>



<p>The core team launched Gutenberg <a href=\"https://make.wordpress.org/core/2020/06/11/whats-new-in-gutenberg-11-june/\">8.3</a> and <a href=\"https://make.wordpress.org/core/2020/06/24/whats-new-in-gutenberg-24-june/\">8.4</a> this month, paving the way for some exciting block editor features. Version 8.3 introduced enhancements like a reorganized, more intuitive set of block categories, a parent block selector, an experimental spacing control, and user-controlled link color options. Version 8.4 comes with new image-editing tools and the ability to edit options for multiple blocks.  The block directory search feature that was previously available as an experimental feature, is now enabled for all Gutenberg installations. For full details on the latest versions on these Gutenberg releases, visit these posts about <a href=\"https://make.wordpress.org/core/2020/06/11/whats-new-in-gutenberg-11-june/\">8.3</a> and <a href=\"https://make.wordpress.org/core/2020/06/24/whats-new-in-gutenberg-24-june/\">8.4</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>WordPress Bumps Minimum Recommended PHP Version to 7.2</h2>



<p>In a major update, WordPress <a href=\"https://meta.trac.wordpress.org/changeset/9959\">has bumped</a> the minimum PHP recommendation to 7.2. The ServeHappy API has been updated to set the minimum acceptable PHP version to 7.2, while the WordPress downloads page recommends 7.3 or newer. Previously, the ServeHappy dashboard widget was showing the upgrade notice to users of PHP 5.6 or lower. This decision comes <a href=\"https://meta.trac.wordpress.org/ticket/5257\">after discussions with the core Site Health team and the Hosting team</a>, both of which recommended that the upgrade notice be shown to users of PHP &lt;=7.1.</p>



<h2>WordCamp Europe 2020 Moved Online</h2>



<p>Following the success of a remote WordCamp Spain, <a href=\"https://2020.europe.wordcamp.org/\">WordCamp Europe</a> was held fully online from June 4 to 6. The event drew a record 8,600 signups from people based in 138 countries, along with 2,500 signups for contributor day. WCEU Online also showcased 33 speakers and 40 sponsors, in addition to a Q&amp;A with Matt Mullenweg. You can find the videos of the event in WordPress.tv by <a href=\"https://wordpress.tv/event/wordcamp-europe-2020/\">following this link</a>, or you can catch the<a href=\"https://www.youtube.com/channel/UCaYQGYDpXpU4A17kxN-AgJQ\"> live stream recording of the entire event from the WP Europe YouTube Channel</a>.</p>



<p>Want to get involved with the Community team? <a href=\"https://make.wordpress.org/community/\">Follow the Community blog here</a>, or join them in the #community-events channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. To organize a Meetup or WordCamp, <a href=\"https://make.wordpress.org/community/handbook/virtual-events/welcome/applying-for-a-virtual-event/\">visit the handbook page</a>.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>Josepha Haden (<a href=\'https://profiles.wordpress.org/chanthaboune/\' class=\'mention\'><span class=\'mentions-prefix\'>@</span>chanthaboune</a>), the executive director of the WordPress project, <a href=\"https://wordpress.org/news/2020/06/equity-and-the-power-of-community/\">published a post </a>that highlights resources on how the global WordPress community can focus on equity to help dismantle racial, societal, and systemic injustice.&nbsp;</li><li>PHP, the primary programming language in which WordPress is written, celebrated its <a href=\"https://wptavern.com/php-marks-25-years\">25th anniversary</a> this month!</li><li>The Community team is<a href=\"https://make.wordpress.org/community/2020/06/18/pending-update-for-the-code-of-conduct/#comment-28294\"> updating the WordCamp code of conduct</a> to address discrimination based on age, caste, social class, and other identifying characteristics.</li><li>The WordPress Core team is promoting more inclusive language by <a href=\"https://make.wordpress.org/core/2020/06/18/proposal-update-all-git-repositories-to-use-main-instead-of-master/\">updating all git repositories to use `trunk` instead of `master`</a>. Additionally, the team proposes to <a href=\"https://make.wordpress.org/core/2020/06/24/proposal-rename-invalid-worksforme-and-wontfix-ticket-resolutions/\">rename&nbsp; “invalid,” “worksforme,” and “wontfix” ticket resolutions </a>to “not-applicable,” “not-reproducible” or “cannot-reproduce,” and “not-implemented,” respectively.&nbsp;</li><li>The Documentation team is working on an external linking policy and has <a href=\"https://make.wordpress.org/docs/2020/06/15/external-linking-policy-trusted-sources/\">started a discussion</a> on how to allow linking to trusted sources to benefit users.&nbsp;</li><li>The Core team has put up a proposal to <a href=\"https://make.wordpress.org/core/2020/06/10/merge-announcement-extensible-core-sitemaps/\">merge extensible core sitemaps to WordPress core</a> in the 5.5 release. The feature is currently available as a <a href=\"https://wordpress.org/plugins/core-sitemaps/\">feature plugin</a>.</li><li><a href=\"https://2020.denver.wordcamp.org/\">WordCamp Denver</a> was held online May 26–27. The event sold over 2,400 tickets and featured 27 speakers and 20 sponsors. You can catch the recorded live stream on the <a href=\"https://2020.denver.wordcamp.org/watch-now/\">event site</a>.</li><li>The Core team is working on <a href=\"https://make.wordpress.org/core/2020/06/29/updating-jquery-version-shipped-with-wordpress/\">updating the version of jQuery</a> used in WordPress core.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8614\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:76:\"
		
		
					
		
		
		
				
		
		

					
										
					
					
			
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:6:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 5.4.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2020/06/wordpress-5-4-2-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wordpress.org/news/2020/06/wordpress-5-4-2-security-and-maintenance-release/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jun 2020 19:19:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8592\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:360:\"WordPress 5.4.2 is now available! This security and maintenance release features 23 fixes and enhancements. Plus, it adds a number of security fixes—see the list below. These bugs affect WordPress versions 5.4.1 and earlier; version 5.4.2 fixes them, so you’ll want to upgrade. If you haven’t yet updated to 5.4, there are also updated versions [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6827:\"
<p>WordPress 5.4.2 is now available!</p>



<p>This security and maintenance release features 23 fixes and enhancements. Plus, it adds a number of security fixes—see the list below.</p>



<p>These bugs affect WordPress versions 5.4.1 and earlier; version 5.4.2 fixes them, so you’ll want to upgrade.</p>



<p>If you haven’t yet updated to 5.4, there are also updated versions of 5.3 and earlier that fix the bugs for you.</p>



<h3><strong>Security Updates</strong></h3>



<p>WordPress versions 5.4 and earlier are affected by the following bugs, which are fixed in version 5.4.2. If you haven’t yet updated to 5.4, there are also updated versions of 5.3 and earlier that fix the security issues.</p>



<ul><li>Props to Sam Thomas (jazzy2fives) for finding an XSS issue where authenticated users with low privileges are able to add JavaScript to posts in the block editor.</li><li>Props to Luigi &#8211; (<a href=\"https://www.gubello.me/\">gubello.me</a>) for discovering an XSS issue where authenticated users with upload permissions are able to add JavaScript to media files.</li><li>Props to Ben Bidner of the WordPress Security Team for finding an open redirect issue in <em>wp_validate_redirect()</em>.</li><li>Props to <a href=\"http://apapedulimu.click\">Nrimo Ing Pandum</a> for finding an authenticated XSS issue via theme uploads.</li><li>Props to <a href=\"https://blog.ripstech.com/authors/simon-scannell\">Simon Scannell of RIPS Technologies</a> for finding an issue where <em>set-screen-option</em> can be misused by plugins leading to privilege escalation.</li><li>Props to <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a> for discovering an issue where comments from password-protected posts and pages could be displayed under certain conditions.</li></ul>



<p>Thank you to all of the reporters for&nbsp;<a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">privately disclosing the vulnerabilities</a>. This gave the security team time to fix the vulnerabilities before WordPress sites could be attacked.</p>



<p>One maintenance update was also deployed to versions 5.1, 5.2 and 5.3. See the <a href=\"https://make.wordpress.org/core/2020/06/09/wordpress-5-4-2-prevent-unmoderated-comments-from-search-engine-indexation/\">related developer note</a> for more information.</p>



<p>You can browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.4.2&amp;order=priority\">full list of changes on Trac</a>.</p>



<p>For more info, browse the full list of changes on Trac or check out the Version&nbsp;<a href=\"https://wordpress.org/support/wordpress-version/version-5-4-2/\">5.4.2 documentation page</a>.</p>



<p>WordPress 5.4.2 is a short-cycle maintenance release. The next major release will be&nbsp;<a href=\"https://make.wordpress.org/core/5-5/\">version 5.5</a>.</p>



<p>You can download WordPress 5.4.2 from the button at the top of this page, or visit your<strong>&nbsp;Dashboard → Updates</strong>&nbsp;and click&nbsp;<strong>Update Now</strong>.</p>



<p>If you have sites that support automatic background updates, they’ve already started the update process.</p>



<h3>Thanks and props!</h3>



<p>In addition to the security researchers mentioned above, thank you to everyone who helped make WordPress 5.4.2 happen:</p>



<p><a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/argentite\">argentite</a>, <a href=\"https://profiles.wordpress.org/asif2bd\">M Asif Rahman</a>, <a href=\"https://profiles.wordpress.org/audrasjb\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/bdcstr\">bdcstr</a>, <a href=\"https://profiles.wordpress.org/delowardev\">Delowar Hossain</a>, <a href=\"https://profiles.wordpress.org/dhrrob\">Rob Migchels</a>, <a href=\"https://profiles.wordpress.org/donmhico\">donmhico</a>, <a href=\"https://profiles.wordpress.org/ehtis/\">Ehtisham Siddiqui</a>, <a href=\"https://profiles.wordpress.org/emlebrun\">Emilie LEBRUN</a>, <a href=\"https://profiles.wordpress.org/finomeno\">finomeno</a>, <a href=\"https://profiles.wordpress.org/garethgillman\">garethgillman</a>, <a href=\"https://profiles.wordpress.org/giorgio25b\">Giorgio25b</a>, <a href=\"https://profiles.wordpress.org/gma992\">Gabriel Maldonado</a>, <a href=\"https://profiles.wordpress.org/h71\">Hector F</a>, <a href=\"https://profiles.wordpress.org/ianbelanger\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/imath\">Mathieu Viet</a>, <a href=\"https://profiles.wordpress.org/javiercasares\">Javier Casares</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/jonkolbert\">jonkolbert</a>, <a href=\"https://profiles.wordpress.org/jonoaldersonwp\">Jono Alderson</a>, <a href=\"https://profiles.wordpress.org/joyously\">Joy</a>, <a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/kjellr\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/kthmd\">KT</a>, <a href=\"https://profiles.wordpress.org/markusthiel\">markusthiel</a>, <a href=\"https://profiles.wordpress.org/mayankmajeji\">Mayank Majeji</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce-Dwan</a>, <a href=\"https://profiles.wordpress.org/mislavjuric\">mislavjuric</a>, <a href=\"https://profiles.wordpress.org/mukesh27\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/nikhilbhansi\">Nikhil Bhansi</a>, <a href=\"https://profiles.wordpress.org/oakesjosh\">oakesjosh</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/passoniate\">Arslan Ahmed</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/poena\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/sabernhardt\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/samful\">Sam Fullalove</a>, <a href=\"https://profiles.wordpress.org/schlessera\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/skarabeq\">skarabeq</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/skithund\">Toni Viemerö</a>, <a href=\"https://profiles.wordpress.org/suzylah\">suzylah</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/utz119\">TeBenachi</a>, <a href=\"https://profiles.wordpress.org/whyisjake\">Jake Spurlock</a> and <a href=\"https://profiles.wordpress.org/yuhin\">yuhin</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://wordpress.org/news/2020/06/wordpress-5-4-2-security-and-maintenance-release/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8592\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:60:\"
		
		
		
		
		
				
		
		

					
										
					
		
		
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Equity and the Power of Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2020/06/equity-and-the-power-of-community/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 06 Jun 2020 17:59:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"General\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8590\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:350:\"Over the past week, I’ve been thinking a lot about George Floyd, Breonna Taylor, and Ahmaud Arbery. I have been thinking about white supremacy, the injustice that Black women and men are standing up against across the world, and all the injustices I can’t know, and don’t see.&#160; The WordPress mission is to democratize publishing, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2535:\"
<p>Over the past week, I’ve been thinking a lot about George Floyd, Breonna Taylor, and Ahmaud Arbery. I have been thinking about white supremacy, the injustice that Black women and men are standing up against across the world, and all the injustices I can’t know, and don’t see.&nbsp;</p>



<p>The WordPress mission is to democratize publishing, and to me, that has always meant more than the freedom to express yourself. Democratizing publishing means giving voices to the voiceless and amplifying those speaking out against injustice. It means learning things that we otherwise wouldn’t. To me, it means that every voice has the ability to be heard, regardless of race, wealth, power, and opportunity. WordPress is a portal to commerce; it is a canvas for identity, and a catalyst for change.</p>



<p>While WordPress as an open source project may not be capable of refactoring unjust judicial systems or overwriting structural inequality, this does not mean that we, the WordPress community, are powerless. WordPress can&#8217;t dismantle white supremacy, but the WordPress community can invest in underrepresented groups (whose experiences cannot be substituted for) and hire them equitably. WordPress can&#8217;t eradicate prejudice, but the WordPress community can hold space for marginalized voices in our community.</p>



<p>There is a lot of racial, societal, and systemic injustice to fight. At times, change may seem impossible, and certainly, it’s been too slow. But I know in my heart that the WordPress community is capable of changing the world. </p>



<p>If you would like to learn more about how to make a difference in your own community, here are a few resources I’ve gathered from WordPressers just like you.</p>



<ul><li><a href=\"https://href.li/?http://www.socialjusticetoolbox.com/\">Social Justice Toolbox</a></li><li><a href=\"http://antiracismforbeginners.com/\">Anti-racism resource list</a></li><li>An open source <a href=\"https://guidetoallyship.com/\">Guide to Allyship</a></li><li><a href=\"https://allienimmons.com/how-to-be-a-wordpress-ally/\">How to be a WordPress Ally</a></li><li><a href=\"https://www.highsnobiety.com/p/black-lives-matter-europe/\">Supporting Black Lives Matter in Europe</a></li><li><a href=\"https://feminisminindia.com/2019/06/03/colourism-fairness-india/\">Cost of Colourism in India</a> </li><li><a href=\"https://www.ted.com/talks/verna_myers_how_to_overcome_our_biases_walk_boldly_toward_them?language=en\">Overcoming Biases by Walking Toward Them</a> </li></ul>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"8590\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 07 Aug 2020 06:09:55 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Thu, 06 Aug 2020 13:07:02 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("136","_transient_timeout_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1596823794","no");
INSERT INTO `wp_options` VALUES("137","_transient_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1596780594","no");
INSERT INTO `wp_options` VALUES("139","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1596823795","no");
INSERT INTO `wp_options` VALUES("140","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Automattic Relaunches P2, Self-Hosted Version on the Roadmap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102891\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:183:\"https://wptavern.com/automattic-relaunches-p2-self-hosted-version-on-the-roadmap?utm_source=rss&utm_medium=rss&utm_campaign=automattic-relaunches-p2-self-hosted-version-on-the-roadmap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4890:\"<p>Automattic&rsquo;s relaunch of P2 is <a href=\"https://wordpress.com/p2/\">now in Beta</a>. This is the long-awaited update to the company&rsquo;s internal collaboration software that is also used on WordPress.org and other self-hosted sites via a theme. For years, Automattic, which now counts more than 1,200 employees in 77 countries, has had P2 at the core of its written communication tools. It is used as a complement to Slack and video conferencing, providing a public collaboration space for conversations which might otherwise be hidden away in emails. </p>



<p>The older version of P2 functioned as a dependable workhorse with few changes over the years, but the beta introduces some marked improvements that make it more versatile than before. It is now seamlessly integrated with the block editor and includes a streamlined invitation system for onboarding new team members.</p>



<img />



<p>P2 has a fresh design that has come a long way since its roots as an <a href=\"https://ma.tt/2009/05/how-p2-changed-automattic/\">evolution of the Prologue microblogging theme.</a> Many things about WordPress have changed since P2&rsquo;s first launch 11 years ago but threaded conversations have endured as a useful collaboration format. Mobile support is one of the things that has improved significantly. Users can get notifications via the web, email, and the WordPress mobile apps.</p>



<img />



<p>&ldquo;It works on the WordPress apps perfectly but it&rsquo;s handled as a normal WordPress site, without any P2 specific functionality,&rdquo; Automattic&rsquo;s P2 launch lead Jon Burke said. &ldquo;P2 specific functionality and improvements are on the mobile app product roadmap. The browser version on the other hand has all the particularities that P2 has.&rdquo;</p>



<p>The beta version of P2 is free and each instance comes with 3GB of storage space for images and files. Users can create as many as they like. The product is built on top of WordPress.com&rsquo;s infrastructure but functions as a scaled back version of a blog &ndash; essentially a WordPress for teams. </p>



<p>Pricing for the commercial upgrade has not yet been determined, according to Burke, but the roadmap includes a hefty list of features.</p>



<p>&ldquo;We&rsquo;ll have integrations with third party services, project management features, more storage space, custom URLs, more customization options, etc,&rdquo; Burke said. &ldquo;We plan to introduce multi-site functionality, too, so an organization can create multiple P2s while sharing the same user base, have cross-posting, a common glossary, and other advanced features.&rdquo;</p>



<p>With the diverse myriad of blocks pouring into the WordPress ecosystem, every P2 has the opportunity to be unique, depending on which features it introduces through the editor. Burke said Automattic plans to allow admins to extend their P2 instances with plugins in the enterprise version.</p>



<h2>P2 Set to Roll Out on WordPress.com, Self-Hosted Version Coming &ldquo;Eventually&rdquo; </h2>



<p>P2 is just now entering beta but many fans are already eagerly awaiting a self-hosted version. Burke said it is coming &ldquo;eventually,&rdquo; but the team hasn&rsquo;t yet worked out how it will be structured. The project is not currently available on GitHub.</p>



<p>&ldquo;With this launch version behind us the P2 team will turn to this but don&rsquo;t yet have a time-line,&rdquo; Burke said. &ldquo;The team will need to now define how the backend admin will look.&rdquo; The updated P2 is also coming to power conversations on WordPress.org further down the road.</p>



<p>&ldquo;We don&rsquo;t yet have a target date but it is on the product roadmap,&rdquo; he said. &ldquo;This P2 version has been more than a theme or plugin update &ndash; it&rsquo;s really a product concept- so we can&rsquo;t simply update the WordPress.org P2 theme; it requires additional progress.&rdquo;</p>



<p>P2 seems like it would be a good fit for Automattic&rsquo;s <a href=\"https://happy.tools/\">Happy Tools</a> suite of products for distributed teams. A version of P2 with more features may roll out under this brand once the beta concludes.</p>



<p>&ldquo;Given the sudden global shift to remote work we really wanted to get out a stable product as soon as we could,&rdquo; Burke said. &ldquo;That really made WordPress.com the most expedient pathway to get P2 into peoples&rsquo; hands.</p>



<p>&ldquo;Now that we have launched this version, we will make decisions around where the next releases will live. P2 has been envisioned as being part of the Happy Tools suite. But we are going to learn from the early users on WordPress.com and prioritize the next steps. We know that some users will need a premium version on WordPress.com in order to secure a custom domain and other features so we will update that shortly.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Aug 2020 22:10:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"WPTavern: Plugin Rank Provides Insight Into WordPress Search Results, Competitive Analysis, and Email Reports for Developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102835\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:289:\"https://wptavern.com/plugin-rank-provides-insight-into-wordpress-search-results-competitive-analysis-and-email-reports-for-developers?utm_source=rss&utm_medium=rss&utm_campaign=plugin-rank-provides-insight-into-wordpress-search-results-competitive-analysis-and-email-reports-for-developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6181:\"<p class=\"has-drop-cap\">Iain Poulson announced that <a href=\"https://pluginrank.com/\">Plugin Rank</a> is open to the public yesterday. It is a new service that allows plugin authors to track their rankings by keyword on the official WordPress plugin directory. The service is geared toward plugin authors with freemium offerings.</p>



<p>The tools were already in place for Poulson to build the service.  He just needed to build his service on top of them.  &ldquo;Plugin Rank leverages the WordPress.org API to retrieve a set of plugins for a search term,&rdquo; he said. &ldquo;It&rsquo;s the same API that WordPress uses when a user searches for a plugin inside their WordPress dashboard or when searching on the plugin directory.&rdquo;</p>



<p>Poulson described how a user might search for a membership plugin by typing &ldquo;membership&rdquo; in the search box. The WordPress API returns a set of plugins that best match that term, based on an internal ranking algorithm. The Plugin Rank service uses this same, underlying technology.</p>



<p>&ldquo;Plugin Rank will check the API daily to find the latest positions of the plugins for the keywords being tracked by Plugin Rank customers,&rdquo; he said. &ldquo;This data is then used to show position movement and charted to show an overall picture of how the plugins are ranking.&rdquo;</p>



<img />Plugin dashboard screen.



<p>The idea for the service was born from work he and others were doing at <a href=\"https://deliciousbrains.com/\">Delicious Brains</a>, a WordPress development company, a few months ago. &ldquo;We&rsquo;d started to work on improving the copy in the <a href=\"https://wordpress.org/plugins/wp-migrate-db/\">WP Migrate DB</a> plugin readme.txt files to rank higher in search results,&rdquo; he said. &ldquo;Brad Touesnard set up a Google sheet with all the keywords we wanted to rank for, a link to search the keyword on wordpress.org, and columns for each month. He started to record the position the plugin appears for each keyword every month. Or that was the idea, when we remembered!&rdquo;</p>



<p>Poulson began using the same system for <a href=\"https://wpusermanager.com/\">WP User Manager</a> and <a href=\"https://intagrate.io/\">Intagrate</a>, two freemium plugins he had in the plugin directory. However, it did not take long to realize the futility of that system.</p>



<p>&ldquo;The sheer manual nature of the task of setting up the sheet, monthly checking, and trying to remember to do it made me think there must be a better way,&rdquo; he said. &ldquo;So I started to work on an app to do it for me.&rdquo;</p>



<p>Besides simply providing a particular plugin&rsquo;s rank, Poulson said the service provides information that can help plugin developers raise their rankings in the search results.</p>



<img />Competitive analysis against other plugins.



<p>&ldquo;The competitor analysis in Plugin Rank gives you an insight into the top 50 plugins that rank for the keywords you care about,&rdquo; said Poulson. &ldquo;It gives you insights into what those plugins are doing that make them rank higher than you. Do they have a high amount of the keyword in their readme? Do they have it in their title or tags? Do they answer the bulk of their support requests? Do they have a large number of five-star ratings?&rdquo;</p>



<h2>A Premium Service with a Premium Price</h2>



<p class=\"has-drop-cap\">Plugin Rank is the first service of its kind in the WordPress industry. Therefore, Poulson had to look outside of traditional WordPress channels to get a sense of how to <a href=\"https://pluginrank.com/pricing/\">price the new service.</a></p>



<p>&ldquo;I looked at similar SEO tools for traditional search engines, like <a href=\"https://ahrefs.com/\">Ahrefs</a> and <a href=\"https://www.semrush.com/\">SEMrush</a>, and tried to base my pricing on how valuable it can be in relation to other marketing channels,&rdquo; he said.</p>



<p>Only time and feedback will decide whether he found the sweet spot between offering a valuable service and what plugin developers are willing to fork over. The Starter tier allows plugin authors to track up to five keywords for a single plugin. It also includes email reports and competitor analysis. The $9 per month price tag is low enough for developers to dip their toes in and decide whether it is worth upgrading for tracking more keywords and plugins.</p>



<p>The $49 Plus plan allows up to five plugins and 50 keywords. It also includes tracking for multiple languages. The $119 Pro plan bumps the plugin count to 20 and keyword number to 500.</p>



<p>Right now, Plugin Rank is offering a 21-day free trial, which is a no-brainer for any freemium plugin author who might even be remotely interested in the service. <em>I have no doubt I would sign up if I was still in the freemium plugin game.</em></p>



<p>&ldquo;Most developers and companies will invest heavily and get good results from content marketing and SEO improvements, and their WordPress.org plugin listing will receive little attention,&rdquo; said Poulson. &ldquo;But for freemium plugins, it can be a huge channel for getting people using their plugin and buying the up-sells. So it&rsquo;s priced with that in mind.&rdquo;</p>



<h2>The Future of the Service</h2>



<p class=\"has-drop-cap\">The <em>knowledge</em> of where a plugin stands in the rankings and having the data readily available will undoubtedly help many plugin authors. However, knowledge is merely the beginning of ranking higher. For developers who are not well-versed in marketing and SEO, they will need to develop new skills to make full use of what they learn from the service.</p>



<p>Poulson seems interested in expanding the service beyond its initial goal of providing ranking data. Tutorials, videos, and other resources would be a nice value-add for those who buy into the service now.</p>



<p>&ldquo;Plugin Rank&rsquo;s primary functionality at the moment is monitoring and getting access to data,&rdquo; he said, &ldquo;but I&rsquo;ve got features planned that focus on how to make improvements, as well as tutorial-style content on the Resources page.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Aug 2020 21:14:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"BuddyPress: BuddyPress 6.2.0 Maintenance release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=313261\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://buddypress.org/2020/08/buddypress-6-2-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1123:\"<p>Immediately available is&nbsp;<a href=\"https://downloads.wordpress.org/plugin/buddypress.6.2.0.zip\">BuddyPress 6.2.0</a>. This maintenance release:</p>



<ul><li>fixes 1 bug related to the 6.0.0 release, </li><li>is preparing BuddyPress for WordPress 5.5.0,</li><li>is a recommended upgrade for all BuddyPress installations.</li></ul>



<p>For details on the changes, please read the&nbsp;<a href=\"https://codex.buddypress.org/releases/version-6-2-0/\">6.2.0 release notes</a>.</p>



<p>Update to BuddyPress 6.2.0 today in your WordPress Dashboard, or by&nbsp;<a href=\"https://wordpress.org/plugins/buddypress/\">downloading from the WordPress.org plugin repository</a>.</p>



<h2>Many thanks to 6.2.0 contributors&nbsp;<span class=\"dashicons dashicons-heart\"></span></h2>



<p><a href=\"https://profiles.wordpress.org/hareesh-pillai/\">hareesh-pillai</a>, <a href=\"https://profiles.wordpress.org/man4toman\">man4toman</a>, <a href=\"https://profiles.wordpress.org/dcavins/\">dcavins</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">boonebgorges</a>, <a href=\"https://profiles.wordpress.org/imath/\">imath</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Aug 2020 19:40:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"Post Status: Creating healthy virtual work environments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=79424\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://poststatus.com/creating-healthy-virtual-work-environments/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:738:\"<p>We\'re seeing the strain of isolation and 100% remote work without meetups, conferences, or other in-person opportunities to collaborate. In this episode of Post Status Draft, Cory and Brian discuss how to create healthy virtual work environments, including some tips for establishing better work days.</p>







<p>Or watch this episode on YouTube:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<h3>Sponsor: Pagely</h3>



<p><a href=\"https://pagely.com/\">Pagely</a> offers best-in-class managed WordPress hosting, powered by Amazon\'s Cloud, the Internet’s most reliable infrastructure. Pagely helps big brands scale WordPress.Thank you to <a href=\"https://pagely.com/\">Pagely</a> for being a Post Status partner!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Aug 2020 23:10:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: WordPress Cancels All In-Person Flagship Events Until 2022\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102777\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:181:\"https://wptavern.com/wordpress-cancels-all-in-person-flagship-events-until-2022?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-cancels-all-in-person-flagship-events-until-2022\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3357:\"<p>As the world scrambles to invent and manufacture therapeutics and vaccines for COVID-19, the World Health Organization has <a href=\"https://www.who.int/news-room/detail/01-08-2020-covid-19-emergency-committee-highlights-need-for-response-efforts-over-long-term\">declared</a> the pandemic &ldquo;a once-in-a-century health crisis, the effects of which will be felt for decades to come.&rdquo; Outbreaks vary in severity across the globe, making it impossible to host international conferences safely for many months (and possibly years) to come.</p>



<p>In consideration for the time and efforts of hundreds of volunteers who would be involved in planning in-person events, WordPress <a href=\"https://make.wordpress.org/community/2020/08/04/announcement-flagship-events-in-2021\">announced</a> it will no longer accept any applications for flagship events in 2021:</p>



<blockquote class=\"wp-block-quote\"><p>Flagship events (i.e. large, regional WordCamps that attract an international audience) bring together people from all corners of the world, so until infection rates are effectively mitigated and/or a vaccine is widely available, these large scale events that typically host more than 1,000 individuals could become &ldquo;super-spreader&rdquo; events if a single infected person attends.&nbsp;</p><p>Applications for new flagship events (or regional events that cover multiple regions or countries) will not be accepted for all of 2021.</p></blockquote>



<p>The announcement comes on the heels of <a href=\"https://wptavern.com/wordcamp-us-2020-canceled-due-to-pandemic-stress-and-online-event-fatigue\">WordCamp US canceling its virtual event</a> due to overextended organizers and online event fatigue for attendees. Up until this point, organizing teams from the large regional camps have been making their own determinations regarding the suitability of hosting an event online. The change announced this week prevents new events from applying and then inevitably having to transition to a virtual format.</p>



<p>Existing flagship events that were already in the pipeline will be allowed to continue as online events. These include WordCamps Europe, US, Asia, and  Centroam&eacute;rica. Of these, WCEU has already <a href=\"https://wptavern.com/wordcamp-europe-goes-virtual-for-2021-in-person-conference-to-resume-2022\">announced</a> an online event.</p>



<p>&ldquo;As&nbsp;<a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">online events continue to evolve</a>&nbsp;to reflect community needs, the Community Team strongly encourages these flagship organizing teams to be creative in their approach,&rdquo; Hugh Lashbrooke said in the announcement. This challenge forces organizers to proceed only if they can  knock it out of the park in terms of creativity. Otherwise, it&rsquo;s simply hosting another online conference in the same tired format for the sake of tradition. </p>



<p>WordPress is at an interesting point in its history where it can no longer rely on in-person events to drive enthusiasm, education, and growth for the community. Flagship WordCamps are a necessary casualty in the fight to slow the spread of the virus, but this early decision provides a welcome peg of certainty for those who normally invest a significant amount of time in making these events a reality.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Aug 2020 21:57:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Disable Comments Plugin Looking for New Owner, Highest Bid Goes to Charity\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102771\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/disable-comments-plugin-looking-for-new-owner-highest-bid-goes-to-charity?utm_source=rss&utm_medium=rss&utm_campaign=disable-comments-plugin-looking-for-new-owner-highest-bid-goes-to-charity\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4743:\"<p class=\"has-drop-cap\">Samir Shah is ready to part ways with his popular <a href=\"https://wordpress.org/plugins/disable-comments/\">Disable Comments</a> plugin. The WordPress extension has garnered over a million users and a solid 220 five-star reviews out of 229, but its owner no longer has the time to maintain it. Rather than simply give it away or sell it for profit, he plans to auction it for charity.  The highest bidder will donate to Effective Altruism Funds (EAF), a charitable organization, for ownership.</p>



<p>Shah asks that those who are interested in bidding on the plugin contact him via his <a href=\"http://twitter.com/solaris_smoke/\">Twitter account</a>. He is also open to feedback on how to approach this at the moment.</p>



<p>He first released the Disable Comments plugin in 2011. This was during a time that he was working professionally with WordPress. His primary use case was with corporate clients who did not need any sort of commenting functionality on the site.</p>



<p>&ldquo;After repeating this implementation on several projects I ported it to a plugin,&rdquo; he said. &ldquo;The plugin became popular very quickly so it turns out this was a common use case.&rdquo;</p>



<p>Shah used PHP and WordPress primarily between 2009 and 2015. However, the work his company has been doing has shifted his focus to other languages and platforms. He has not used WordPress professionally since 2016 but has continued maintaining this plugin for the community in his free time.</p>



<p>&ldquo;In the last year or two I&rsquo;ve found it hard to keep up with the maintenance of the plugin,&rdquo; he said. &ldquo;I&rsquo;m increasingly unfamiliar with both the WordPress core (major changes like Gutenberg, for example) and with newer versions of PHP. It is time to find a new owner who is actively using WordPress.&rdquo;</p>



<p>Disable Comments allows administrators to disable the comment functionality across the entire site. Users can also control it based on a specific post type or even disable comments across the network when used on a multisite installation.</p>



<p>The primary use case is for disabling all commenting-related functionality. When this mode is enabled, the plugin hides comment links from all menus, removes comment widgets, hides the discussion settings screen, disables outgoing pingbacks, and more. Of course, it disables commenting on the front end too.</p>



<p>Shah also has a <a href=\"https://github.com/solarissmoke/disable-comments-mu\">&ldquo;must use&rdquo; version</a> of the plugin available on GitHub. This comes in handy for professional work where the developer does not want the client to accidentally deactivate the plugin.</p>



<p>&ldquo;I never intended to make any money off this plugin, which is completely free to use,&rdquo; said Shah. &ldquo;I have however received a number of financial offers for it over the years (presumably because people value the large user base), and so the idea I had was to auction it. The highest bidder would pay their bid to my preferred charitable organization, and send me a receipt as proof of donation in exchange for ownership of the plugin.&rdquo;</p>



<p>He is hoping that someone in the community will value a free plugin that does not generate revenue. With over a million active installs, there is a possibility that a company could directly or indirectly profit from ownership. Even if not, this would be a good opportunity for someone with the resources to give back to the WordPress community. There is an obvious need for this type of plugin.</p>



<p>While Shah says he does not spend much time on charitable work, he does try to donate a percentage of his annual income to charity and believes this is another avenue to do some good.</p>



<p>&ldquo;I&rsquo;m in the privileged position at the moment of having sufficient income to meet my basic needs,&rdquo; he said. &ldquo;Selling the plugin for profit isn&rsquo;t going to alter my standard of living, and I&rsquo;m not interested in profit for its own sake. If I can extract some value from this plugin and give it to EAF then it will go some way to improving the lives of others.&rdquo;</p>



<p>He said he chose EAF because it uses an evidence-based approach to distributing funds by focusing on empirical measures of impact. &ldquo;This felt to me like a better strategy than just picking a cause that I was personally attached to. There are particular areas of their work &mdash; e.g., the long-term future fund &mdash; that I think are especially important today.&rdquo;</p>



<p>It will be interesting to see how this type of <em>sale</em> works out. What do you think of trading ownership of a plugin for a charitable contribution?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Aug 2020 18:45:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WordPress.org blog: WordPress 5.5 Release Candidate 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8764\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/news/2020/08/wordpress-5-5-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2501:\"<p>The second release candidate for WordPress 5.5 is here!</p>



<p>WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;now is the time!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC2.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>For a more detailed breakdown of the changes included in WordPress 5.5, check out the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">WordPress 5.5 beta 1 post</a>. The&nbsp;<a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">WordPress 5.5 Field Guide</a>&nbsp;is also out! It’s your source for details on all the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the&nbsp;<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2020 19:12:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Redux Framework Relaunches, Focuses Efforts on Gutenberg Templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=98604\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/redux-framework-relaunches-focuses-efforts-on-gutenberg-templates?utm_source=rss&utm_medium=rss&utm_campaign=redux-framework-relaunches-focuses-efforts-on-gutenberg-templates\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13983:\"<p class=\"has-drop-cap\">D&#333;vy Paukstys was rushing out another update with bug fixes yesterday morning as we chatted about the future of his popular <a href=\"https://redux.io/\">Redux Framework</a>. It was not the first update of the day. The Virginia-based developer is just over a week into what he has called the <em>soft launch</em> of Redux 4.x. It is a major reconstruction of a plugin that has been powering over 900,000 websites and has a strong developer audience.</p>



<p>The changes over the past week might seem risky to some. He has built a massive user base by providing one of the most <a href=\"https://wordpress.org/plugins/redux-framework/\">powerful theme and plugin options frameworks</a> in WordPress history. The plugin&rsquo;s new focus leans heavily toward the block editor, which is still one of the most controversial features of WordPress, even after nearly two years as part of the core platform.</p>



<p>Paukstys needed to make a change. The developer-only approach was not generating the return on investment that he needed. The $7,000 in donations and subscriptions received in 2019 was not sustainable, especially when products on the Envato marketplace had generated at least $56 million on the back of Redux, according to data he had gathered. He was leaving far too much money on the table. Redux was a successful product on the surface, but developers were either unwilling to pony up the cash or the business plan was not working. It was time for something new.</p>



<p>It was not merely time for a change because the business was essentially going nowhere. The game was and is still changing. Theme options, the bread and butter of Redux, will likely be a thing of the past in the next year or two. Themes will become far less reliant on options panels. Developers will need to build their offerings around the block system and plugins like Redux need to keep up.</p>



<p>The writing was on the wall. The best time to profit from a theme options framework was the past decade. Whether it is the <a href=\"https://wptavern.com/will-page-builders-remain-competitive-in-the-block-era\">block editor or a page-building plugin</a> like Elementor, design options are on the individual page level now, or at least not buckled into old-school concepts like theme options panels or the customizer.</p>



<p><em>The times they are a-changin&rsquo;</em>, and Redux is changing with them.</p>



<p>Paukstys is no stranger to moving with the flow. It has allowed his framework&rsquo;s user numbers to continue growing over the years. In 2015, he shifted gears and focused on making sure his framework <a href=\"https://wptavern.com/redux-and-kirki-frameworks-join-forces-to-provide-better-support-for-the-wordpress-customizer\">supported the customizer</a>. This came after a controversial decision from the Themes Team to <a href=\"https://wptavern.com/wordpress-org-now-requires-theme-authors-to-use-the-customizer-to-build-theme-options\">require the use of the customizer</a> instead of custom theme options screens. Paukstys was a vocal opponent of the decision and still believes the customizer never panned out. In hindsight, he may have been right; the customizer has felt like an abandoned project over the past couple of years. Still, he made the necessary moves to keep his options framework relevant when necessary.</p>



<p>Today, he is propelling Redux into a new era in which blocks reign supreme.</p>



<p>&ldquo;If Redux didn&rsquo;t go into the world of blocks it would eventually be a thing of yesterday,&rdquo; he said. &ldquo;The future is blocks and that&rsquo;s where we are putting our focus. We&rsquo;re excited to once again be on the cutting edge and we hope our product can really help users, freelancers, and agencies build and improve their sites in ways they never have before.&rdquo;</p>



<p>What he and the Redux team has done is tack an entirely new set of user-focused features onto what was once a developer platform. Even the marketing has changed. Redux is now in the business of providing and upselling features to end-users. It is no longer taking a backseat to the theme and plugin authors who have profited in the millions upon its developer API. The team is taking the steering wheel and driving toward its own future.</p>



<h2>What Does the New Redux Do?</h2>



<img />Ice Cream shop template kit.



<p class=\"has-drop-cap\">Redux still does all the things it has always done. Developers can build custom settings screens and offer whatever options they want to their own end-users. The most glaring addition is the new <a href=\"https://templates.redux.io/\">Redux Templates</a> feature, which directly integrates with the block editor.</p>



<p>&ldquo;Redux Templates acts as a block discovery library if you will,&rdquo; said Paukstys. &ldquo;We bring all templates provided by third-party plugins into a single library. You can essentially see and preview what&rsquo;s possible, click, and import.&rdquo;</p>



<p>Redux also has a built-in block dependency installer. When importing third-party templates or blocks, it will check if the plugin is installed and active. If not, it will take care of that for users.</p>



<p>The end goal is to ease the trouble of finding advanced block templates. Currently, most of the block templating plugins are dispersed, projects wondering around the wild. Users cannot find what they need if they do not know where to look. Redux changes all of that. Currently, it supports 18 different block plugins. It serves to give more exposure to existing block plugins and helps users discover solutions they might not have otherwise found.</p>



<p>On the post-editing screen, the plugin adds a new &ldquo;Templates&rdquo; button to the top toolbar. Once clicked, it opens a popup with its library of sections, templates, and template kits.</p>



<img />Viewing templates from the Redux library.



<p>One of the nicer features of the plugin is its previewer. By clicking the preview button, users can see what a section or template looks like before importing anything. On the left side of the previewer, the plugin displays tabs that show what blocks are used and what required plugins would need to be installed and activated.</p>



<p>Redux leaves little to the imagination. Any necessary information about what is being installed is directly available. Plus, it provides links to any plugins that might be installed.</p>



<img />Previewing a contact template.



<p>The great thing is that the Templates feature does not lock the user down to the Redux plugin. If a user wants to deactivate Redux in the future, nothing will change with their blocks. It is primarily serving as a bridge between end-users and the massive world of block projects.</p>



<p>&ldquo;We see the future of options being diminished in the long run by blocks, so we found a way to move into that space to keep Redux always on the cutting edge,&rdquo; said Paukstys. His team completely rewrote the underlying framework and brought everything up to the WordPress coding standards.</p>



<p>The move to support blocks is more of a repositioning of a project whose days were numbered.</p>



<p>Paukstys stressed that Redux has every feature that it had before and even more. The team added CSS variables for developers if they prefer using them over a compiler. He feels like the core framework has improved drastically, which means old users can continue enjoying the features they have become accustomed to.</p>



<h2>A New Business Plan</h2>



<img />



<p class=\"has-drop-cap\">Make no mistake. Paukstys is looking to grow the revenue of his business and create a sustainable future for Redux. The <a href=\"https://redux.io/pricing/\">pricing plan</a> is clear and follows a model that has been successful for many commercial plugins over the years. The plans are tiered and range from $49 per year to $249, depending on the number sites the user wants automatic updates and support for.</p>



<p>The commercial plans offer new features for developers like automated Google Font updates, custom fonts integrated into all panels, unlimited widget areas, and dynamic search.</p>



<p>However, the big upsell is landing directly on the doorstep of end-users. Each of the commercial plans offers full access to over 1,000 sections and full-page templates. The breadth of options can almost be overwhelming, but the average user will be able to find nearly any type of template needed for their site. From restaurants to corporate offices to fitness studios, there is a little something for everyone.</p>



<p>&ldquo;I was all too altruistic,&rdquo; said Paukstys of the previous years. &ldquo;I believed that if I helped people make money, they&rsquo;d give back. Unfortunately, that is not how it works. I&rsquo;ve worked for years with various pricing models, each doomed to fail.&rdquo; He had seen others rise to business success, quite often on the work that he had put in. It is not all about money, and he believes he has something of value to offer in return.</p>



<p>Development skill is not enough to breed financial success. Sound financial principles must back it up.</p>



<p>One of the catalysts for recent changes to his business plan was joining <a href=\"https://poststatus.com/\">Post Status</a>, which has a strong community of business leaders in the WordPress ecosystem. He credits Alex Denning, Kimberly Lipari, Haris Zulfiqar, Rich Tabor, and others as inspiration, helping him to shift his thinking around the business side of the project.</p>



<p>Some of the lessons he has learned thus far are:</p>



<ul><li>Developers are already starved. Focus on users.</li><li>Add-ons can be a bad model. A single pro/premium product is much easier to sell and manage.</li><li>The need for a revenue model. Don&rsquo;t expect people to just hand over money.</li><li>Use the audience you have. Don&rsquo;t cannibalize yourself.</li></ul>



<p>&ldquo;Where we&rsquo;ve ended up is a <em>much</em> cheaper plan for developers and a powerful toolkit for users,&rdquo; he said. &ldquo;Hopefully, we&rsquo;re pushing Gutenberg into a greater place of value.&rdquo;</p>



<h2>Moving Forward</h2>



<p class=\"has-drop-cap\">Naturally, not every user will be happy with the overhaul of the plugin. For years, Redux was geared specifically toward developers. It was an options framework.</p>



<p>&ldquo;Redux was for a completely different purpose which is for developers to create Options framework,&rdquo; wrote a user named James <a href=\"https://wordpress.org/support/topic/dishonest-and-bad-performance/\">in a review</a>. &ldquo;They have changed the plugin suddenly to a page builder something like that. It doesn&rsquo;t make sense and they are using the previous plugin&rsquo;s reputation.&rdquo;</p>



<p>It is a fair criticism. And, it was expected. The plugin has switched much of its focus to end-users. However, it has not removed the existing API and features that made it successful with developers in the past.</p>



<p>Paukstys is clear that he is building on top of the reputation that Redux has earned and launching new features for end-users. He is unapologetic about trying something new to bring in a reasonable return on his years-long investment of time and resources. Launching a completely new and separate project would carry far more risk. It makes sense to build atop the mountain he had already built.</p>



<p>It won&rsquo;t make everyone happy. However, he said that the feedback has been &ldquo;shockingly positive&rdquo; in the week since the Redux 4 soft launch.</p>



<p>&ldquo;I&rsquo;ve never realized how much users appreciated Redux,&rdquo; he said. &ldquo;Some of the changes to the framework broke sites, and everyone I have reached out to help has been so extremely gracious. It&rsquo;s so refreshing and honestly helps me to see why the WordPress community is such a great place to be. I fear developers are too harsh to one another. Users on the other hand, if provided kind support, are in turn incredibly kind.&rdquo;</p>



<p>If most of the feedback thus far is any indication of the plugin&rsquo;s future, do not expect to see pitchforks and torches.</p>



<p>He might have to take a few lumps with a few disgruntled users over the change. It comes with the territory. However, feedback will likely directly correlate with how well he serves users through the Redux support channels.</p>



<p>The project will also benefit from a potentially new user base in the coming months and years. The plugin is dipping its toes into a new market while maintaining the features that got it to where it is today. It will be a bit of a balancing act, but the plugin must move with the times.</p>



<h2>The Future of Redux</h2>



<p class=\"has-drop-cap\">This is a new era for Redux. In the immediate future, Paukstys and team will need to focus on ironing out all of the bugs and the transition to a new market. It is a time for reflection, careful listening, and attentiveness before diving headlong into new features.</p>



<p>&ldquo;In the past, we were 100% developer-centric,&rdquo; said Paukstys. &ldquo;That being said, we always had our eye on the user and wanted to fulfill their needs. Now we&rsquo;re expanding to support the users directly, as well as developers.&rdquo;</p>



<p>With the newfound focus on end-users, there is potential for growth in other areas. Paukstys says the focus is 100% on the block editor at present. Branching out to support other major page builders like Elementor is not out of the question. However, Redux should be able to continue finding success by extending the core experience.</p>



<p>&ldquo;When we started this adventure into the blocks space, we worried, given the limited number of blocks out there,&rdquo; he said. &ldquo;But honestly, there&rsquo;s some amazing innovation out there, and it&rsquo;s been pretty great what we can build with Gutenberg.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2020 14:21:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Automattic Updates Press Page to Clarify Distinction between WordPress.org and WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102612\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:249:\"https://wptavern.com/automattic-updates-press-page-to-clarify-distinction-between-wordpress-org-and-wordpress-com?utm_source=rss&utm_medium=rss&utm_campaign=automattic-updates-press-page-to-clarify-distinction-between-wordpress-org-and-wordpress-com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6031:\"<p>Last week, Automattic&rsquo;s marketing team made a positive step towards curbing the perennial branding confusion between WordPress.org and WordPress.com. The company&rsquo;s <a href=\"https://automattic.com/press/\">press page</a> was updated with a notice to journalists who are writing about Automattic:</p>



<blockquote class=\"wp-block-quote\"><p>Automattic owns and operates&nbsp;<a href=\"https://wordpress.com/\">WordPress.com</a>, which is a hosted version of the open source WordPress software with added features for security, speed and support. Please append &ldquo;.com&rdquo; when referencing our product name.</p><p><a href=\"http://wordpress.org/\">WordPress</a>&nbsp;is open source software, which is written, maintained, and supported by thousands of independent contributors worldwide. Automattic is a major contributor to the WordPress open source project. If you would like to contribute to the WordPress open source project, learn more at&nbsp;<a href=\"https://make.wordpress.org/\">make.wordpress.org</a>.</p></blockquote>



<p>This update was prompted by a recent <a href=\"https://www.linkedin.com/posts/caspar-hubinger_wordpress-activity-6688334765575176192-0-Eh\">conversation on LinkedIn</a> between Caspar H&uuml;binger, who works as a digital marketer at Human Made, and WordPress.com CMO Monica Ohara. H&uuml;binger had posted regarding an inaccuracy in a recent New York Times <a href=\"https://www.nytimes.com/2020/07/12/business/matt-mullenweg-automattic-corner-office.html\">article</a> featuring Matt Mullenweg as an evangelist for remote work at Automattic. The article, which has since been corrected, misattributed Automattic as the company that &ldquo;runs the digital publishing platform WordPress.&rdquo; </p>



<p>These kinds of mistakes are quite frequent, yet understandable, in publications that are not as familiar with the WordPress ecosystem. Yet, these errors often evoke a strong reaction from the project&rsquo;s community whenever they pop up in the media. </p>



<p>Ohara commented on H&uuml;binger&rsquo;s post and exchanged direct messages where he made a case for clarifying the branding on Automattic&rsquo;s website. Ohara was amenable and the notice appeared shortly after the exchange.</p>



<p>Several years ago H&uuml;binger created a <a href=\"https://wpisnotwp.com/\">website</a> to clarify the confusion between WordPress, the open source project, and WordPress.com. Post Status also has a <a href=\"https://poststatus.com/resources/wordpress-versus-automattic/\">resource page</a> that explains the difference between WordPress.org and Automattic&rsquo;s products, but these kinds of external resources never seemed to make much of a difference. </p>



<p>In 2018, H&uuml;binger prevailed upon the author of a TechCrunch article who referenced&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://wordpress.com/\">WordPress.com</a>&nbsp;as &ldquo;WordPress&rdquo; and worked with her on getting the difference documented in TechCrunch&rsquo;s internal editorial guidelines. After he had explained the problem, she replied: &ldquo;We had no policy on this. We&rsquo;re going to change it to .com (or make references to Automattic as needed), and note in our style guide.&rdquo;</p>



<p>When asked why he finds himself a champion of this particular cause, he said he often found himself angry when the name of the open source project he has dedicated most of his digital career to was confused with a commercial service built on top of it.</p>



<p>&ldquo;It&rsquo;s a distortion of reality and I always felt sort of betrayed when it happened,&rdquo; H&uuml;binger said.</p>



<p>&ldquo;I know that many of my community peers feel hurt to this day, even if some of them would probably shrug it off when asked. The word for it is resignation, and to me, it is poison to the human soul. From my perspective, Automattic&rsquo;s passiveness actively fed the narrative that they were profiting from the naming confusion, and that narrative &ndash; true or not &ndash; it keeps poisoning WordPress&rsquo; open source community.&rdquo;</p>



<p>Although many times articles with errors confusing WordPress and .com were corrected afterwards, it can take a few days after the initial rush of traffic hits. </p>



<p>&ldquo;So the message that &lsquo;Automattic runs/owns WordPress&rsquo; keeps being established for the public,&rdquo; H&uuml;binger contended when making his case to Ohara. &ldquo;Worse, the burden of flagging miscommunication when it happens and having it corrected in many cases is left to those who are harmed by it, i.e. open source contributors.&rdquo;</p>



<p>For years people have speculated whether Automattic might rename WordPress.com to avoid the longstanding confusion. Many believe it will never happen, since the company undoubtedly benefits from tightly coupling its products to WordPress&rsquo; name recognition. Ohara declined to comment on whether any major branding changes are on the horizon.</p>



<p>&ldquo;I will say that we&rsquo;re not trying to compete with the WordPress ecosystem,&rdquo; Ohara said. &ldquo;We want to help the overall ecosystem grow and I look forward to working closely with the community.&rdquo;</p>



<p>This small yet important change to Automattic&rsquo;s press page is the direct result of H&uuml;binger&rsquo;s persistent advocacy effort. It may not eliminate all future media errors, but it is a positive development that demonstrates someone is listening.</p>



<p>&ldquo;While a dedicated press page will not be able to prevent future confusion of WordPress and WordPress.com altogether (because it simply isn&rsquo;t possible), my hope is that it will be seen as a first practical step to help heal the relationship between Automattic and parts of WordPress&rsquo; open source community, which so many Automatticians have made such incredible amounts of contributions to ever since the company existed, and that is another thing that is too easy to forget,&rdquo; H&uuml;binger said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Aug 2020 17:35:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WordPress.org blog: The Month in WordPress: July 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8755\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2020/08/the-month-in-wordpress-july-2020/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11541:\"<p>July was an action-packed month for the WordPress project. The month saw a lot of updates on one of the most anticipated releases &#8211; WordPress 5.5! WordCamp US 2020 was canceled and the WordPress community team started experimenting with different formats for engaging online events, in July. Read on to catch up with all the updates from the WordPress world.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 5.5 Updates</h2>



<p>July was full of WordPress 5.5 updates! The WordPress 5.5 <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1\">Beta 1</a> came out on July 7, followed by <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">Beta 2</a> on July 14, <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">Beta 3</a> on July 21, and <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\">Beta 4</a> on July 27. Subsequently, the team also published the first <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\">release candidate</a> of WordPress 5.5 on July 28.&nbsp;</p>



<p>WordPress 5.5, which is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11, 2020</a>, is a major update with features like <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic updates for plugins and themes</a>, a <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">block directory</a>, <a href=\"https://make.wordpress.org/core/2020/06/10/merge-announcement-extensible-core-sitemaps/\">XML sitemaps</a>, <a href=\"https://make.wordpress.org/core/2020/07/16/block-patterns-in-wordpress-5-5/\">block patterns</a>, and <a href=\"https://make.wordpress.org/core/2020/07/14/lazy-loading-images-in-5-5/\">lazy-loading images</a>, among others. To learn more about the release, check out its <a href=\"https://make.wordpress.org/core/2020/07/30/wordpress-5-5-field-guide/\">field guide post</a>.</p>



<p>Want to get involved in building WordPress Core? Follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Gutenberg 8.5 and 8.6</h2>



<p>The core team launched Gutenberg <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>. Version 8.5 &#8211; the last plugin release will be included entirely (without experimental features) in WordPress 5.5, introduced improvements to block drag-and-drop and accessibility, easier updates for external images, and support for the block directory. Version 8.6 comes with features like Cover block video position controls and block pattern updates. For full details on the latest versions on these Gutenberg releases, visit these posts about <a href=\"https://make.wordpress.org/core/2020/07/08/whats-new-in-gutenberg-8-july/\">8.5</a> and <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">8.6</a>.</p>



<p>Want to get involved in building Gutenberg? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, contribute to <a href=\"https://github.com/WordPress/gutenberg/\">Gutenberg on GitHub</a>, and join the #core-editor channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Reimagining Online WordPress Events</h2>



<p>The Community team made the difficult decision <a href=\"https://make.wordpress.org/community/2020/07/27/in-person-events-in-rest-of-year-2020/\">to suspend in-person WordPress events for the rest of 2020</a> in light of the COVID-19 pandemic. The team has also started working on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/\">reimagining online events</a>. Based on <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/#comment-28505\">feedback from the community members</a>, the team decided to <a href=\"https://make.wordpress.org/community/2020/07/23/moving-forward-with-online-events/\">make changes to the current online WordCamp format</a>. Key changes include wrapping up financial support for A/V vendors, ending event swag support for newer online WordCamps, and suspending the Global Community Sponsorship program for 2020. The team encourages upcoming online WordCamps to experiment with their events to facilitate an effective learning experience for attendees while avoiding online event fatigue. The team is currently working on a proposal to organize community-supported <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">recorded workshops and synchronous discussion groups</a> to help community members learn WordPress.<br /><br />Want to get involved with the Community team? <a href=\"https://make.wordpress.org/community/\">Follow the Community blog here</a>, or join them in the #community-events channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. To organize a Meetup or WordCamp, <a href=\"https://make.wordpress.org/community/handbook/virtual-events/welcome/applying-for-a-virtual-event/\">visit the handbook page</a>.&nbsp;</p>



<h2>WordCamp US 2020 is canceled</h2>



<p>The organizers of WordCamp US 2020 have <a href=\"https://2020.us.wordcamp.org/2020/07/30/wcus-2020-an-update/\">canceled the event</a> in light of the continued pandemic and online event fatigue. The flagship event, which was originally scheduled for October 27-29 as an in-person event, had already planned to transition to an online event. Several WCUS Organizers will be working with the WordPress Community team to focus on other formats and ideas for online events, including a 24-hour contributor day, and contributing to the workshops initiative <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">currently being discussed</a>. Matt Mullenweg’s State of the Word (which typically accompanies WordCamp US) is likely to take place in a different format later in 2020.</p>



<h2>Plugin and theme updates are now available over zip files</h2>



<p>After eleven years, WordPress now allows users to update plugins and themes by <a href=\"https://core.trac.wordpress.org/changeset/48390\">uploading a ZIP file, in WordPress 5.5</a>.&nbsp; The feature, which was merged on July 7, has been one of the most requested features in WordPress. Now, when a user tries to upload a plugin or theme zip file from the WordPress dashboard by clicking the “Install Now” button, WordPress will direct users to a new screen that compares the currently-installed extension with the uploaded versions. Users can then choose between continuing with the installation or canceling. WordPress 5.5 will also offer <a href=\"https://make.wordpress.org/core/tag/feature-autoupdates/\">automatic plugin and theme updates</a>.&nbsp;</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">Block directory</a> is coming to WordPress with the 5.5 release. Plugin authors can now <a href=\"https://make.wordpress.org/plugins/2020/07/11/you-can-now-add-your-own-plugins-to-the-block-directory/\">submit their Block plugins to the directory</a>.</li><li>The Core team has opened up the <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">call for features</a> in the WordPress 5.6 release. You can <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">comment on the post</a> with features that you’d like to be included, current UX pain points, or maintenance tickets that need to be addressed. August 20 is the deadline for feature requests. </li><li>Editor features such as the new Navigation block, the navigation screen, and the widget screen that were originally <a href=\"https://make.wordpress.org/updates/2020/03/06/update-progress-on-goals/\">planned to be merged with WordPress 5.5</a> have been <a href=\"https://make.wordpress.org/core/2020/07/02/editor-features-for-wordpress-5-5-update/\">pushed for the next release</a>. </li><li>The Theme team is inviting proposals on whether to allow themes to <a href=\"https://make.wordpress.org/themes/2020/07/13/proposal-allow-themes-to-add-a-top-level-admin-menu/\">place an additional top-level menu link</a> in the admin.</li><li><a href=\"https://buddypress.org/2020/07/buddypress-6-2-0-beta/\">BuddyPress 6.2 beta </a>is out in the wild, and the team will soon release the stable version. The update includes changes that will make BuddyPress fully compatible with WordPress 5.5.</li><li>WordCamp EU 2021, which was being planned as an in-person event in Porto, Portugal, <a href=\"https://europe.wordcamp.org/2021/wordcamp-europe-2021-will-be-online/\">is moving online</a>. The team is considering an in-person WordCamp EU in 2022. </li><li>The Polyglots team has prepared and finalized a <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">Translation Editor &amp; Locale Manager Vetting Criteria</a> to provide more clarity on how global mentors assign PTE/GTE/Locale Managers and to help locale teams set their own guidelines. The document, which was finalized <a href=\"https://make.wordpress.org/polyglots/2020/07/09/translation-editor-locale-manager-vetting-criteria-page-draft/\">after a lot of discussion</a>, is now available in the <a href=\"https://make.wordpress.org/polyglots/handbook/translating/expectations/translation-editor-locale-manager-vetting-criteria/\">Polyglots handbook</a>.</li><li>Members of the Community team <a href=\"https://make.wordpress.org/community/2020/07/03/proposal-recognition-for-event-volunteers-and-attendees-in-wordpress-org-profile/\">are discussing</a> whether WordCamp volunteers, WordCamp attendees, or Meetup attendees should be awarded a WordPress.org profile badge. The ongoing discussion will be open for comments until August 13.</li><li>The <a href=\"https://make.wordpress.org/core/tag/feature-notifications/\">WP Notify project</a>, which aims to create a better way to manage and deliver notifications to the relevant audience, is on to its next steps. The team has finalized the initial requirements, and is <a href=\"https://make.wordpress.org/core/2020/07/09/wp-notify-next-steps/\">kicking off the project build</a>.</li><li>The WordPress documentation team is <a rel=\"noreferrer noopener\" href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\" target=\"_blank\">considering a ban on links to commercial websites</a> in a revision to its external linking policy. The policy change does not remove external links to commercial sites from WordPress.org and only applies to documentation sites. The idea is to protect documentation from being abused, and to prevent the WordPress project from being biased. Discussion on this post is still ongoing, and a decision has not yet been made. Feel free to<a href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\"> comment on the discussion posts</a>, if you would like to share your thoughts on the topic. </li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 03 Aug 2020 13:54:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Hari Shanker R\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Big Orange Heart Opens 2020 Remote Work Wellbeing and Mental Health Survey\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102631\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:213:\"https://wptavern.com/big-orange-heart-opens-2020-remote-work-wellbeing-and-mental-health-survey?utm_source=rss&utm_medium=rss&utm_campaign=big-orange-heart-opens-2020-remote-work-wellbeing-and-mental-health-survey\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3039:\"<p>A Big Orange Heart, formerly known as WP&amp;UP, has opened its 2020 <a href=\"https://www.bigorangeheart.org/survey-2020.html\">Remote Work Wellbeing and Mental Health Survey</a>. The charity organization focuses on supporting remote working communities with education and resources for mental and physical health. It is also home to a community of more than 4,700 members who support each other in growing their businesses and building new skills.</p>



<p>The survey asks fairly broad questions about your mental health and the mental health support in your work environment. It takes approximately three minutes and is completely anonymous.</p>



<img />



<p>Results from the 2019 survey showed that the majority of people in the WordPress community work alone and a significant percentage are dealing with anxiety and suicidal thoughts:</p>



<ul><li>8% of the WordPress community have had suicidal thoughts in the last 12 months</li><li>47% stated their workplace makes them feel anxious</li><li>56% of the WordPress community works alone</li></ul>



<p>Big Orange Heart founder Dan Maby believes these results are helping his team save lives. The charity is actively creating and maintaining services and a peer support network that encourage people to stay connected to their community, in order to reduce the isolation they experience. </p>



<p>&ldquo;Our 2019 results identified that almost 8% of all respondents had been dealing with sustained periods of feeling suicidal over the previous 12-months, twice the national US average,&rdquo; Maby said.&nbsp;&ldquo;This finding led to more training being provided in suicide prevention and support for our team, which enabled us to support multiple individuals that have contacted us requiring suicidal support, all of whom are still with us today.&rdquo;&nbsp;&nbsp;</p>



<p>There are more people working alone remotely now than ever before due to the pandemic. Spend a short time on any social media network and you will likely hear several people say they are not doing okay. This survey helps the team at Big Orange Heart understand the extent of mental health related issues within the remote working community and informs various initiatives the organization plans throughout the year. </p>



<p>&ldquo;As a charity, like so many others at this time, we have been heavily impacted by the COVID-19 global crisis,&rdquo; Maby said. &ldquo;Now more than ever we need to ensure our limited resources are used in the most effective way possible. Your anonymous data will allow us to best understand how we can help improve the lives of others within our community.&rdquo;</p>



<p>The <a href=\"https://www.bigorangeheart.org/survey-2020.html\">Remote Work Wellbeing and Mental Health Survey</a> runs for one month and will close on August 31st. Take the survey and check out Big Orange Heart&rsquo;s <a href=\"https://www.bigorangeheart.org/blog/\">blog</a> for several helpful posts on how to maintain your mental health while working during this crisis.</p>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 01 Aug 2020 03:04:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WordPress 5.6 Wish List: Homepage Post Type Selection and Block Management\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102615\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/wordpress-5-6-wish-list-homepage-post-type-selection-and-block-management?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-6-wish-list-homepage-post-type-selection-and-block-management\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4584:\"<p class=\"has-drop-cap\">With the WordPress 5.5 development cycle coming to a close, it is time to begin mapping out what features should land in WordPress 5.6 later this year. Earlier today, Chloe Bringmann <a href=\"https://make.wordpress.org/core/2020/07/31/wordpress-5-6-whats-on-your-wishlist/\">asked the community to chime in</a> with its wish list on the Make Core blog.</p>



<p>As usual, I have a few thoughts. I tend to lean toward addressing some of the long-standing developer-friendly tickets because these features allow plugin authors to build better products for end-users in the long run.</p>



<p>A complete <a href=\"https://wptavern.com/open-call-for-wordpress-5-5-tickets-whats-on-your-wish-list\">custom post status API</a> tops my usual list of most-wanted features. I have already opined over this for my WordPress 5.5 wish list. It may be time for more realistic dreams. Maybe we will revisit it another year or two down the road. However, if any core leads want to give the feature a green light, I will gladly be the evangelist and get others excited about it.</p>



<h2>Homepage Post Type Selection</h2>



<p class=\"has-drop-cap\">For this release, I want to call out one of my other years-long wishes. WordPress should allow end-users to select any custom post type for display on the homepage.</p>



<p>Imagine a WordPress where users can head to their Reading Settings screen in the admin and select something other than their normal posts list or a page to appear on the homepage. <em>Have a forum plugin installed?</em> Maybe users want to list their latest topics or forums list. <em>Running an eCommerce plugin?</em> Users should be able to display their products. <em>Setting up a web design portfolio?</em> Display the most recent projects by simply selecting this choice in the admin.</p>



<p>This is an area where the software has always catered to bloggers and has avoided throwing a little love to other types of sites.</p>



<p>Currently, plugin authors must perform some crazy hacks to make this work. The WooCommerce <a href=\"https://github.com/woocommerce/woocommerce/blob/master/includes/class-wc-query.php\">custom query class</a> is enough to make any developer give up. Not all of the code in that file is for the front page, but it has a frustrating amount to make something work that should be far simpler for plugin authors.</p>



<p>The reason this needs to be in core WordPress is so that each and every plugin does not need to roll a custom solution. Plugins should be able to flag their post types during registration as &ldquo;allowed on homepage&rdquo; &mdash; not all post types are meant for this type of display. Then, WordPress should handle all the dirty work behind the scenes if a particular post type is selected by the end-user. The addition to the API for plugin authors would be simple, and plugins that are already hacking this feature together can drop a lot of unnecessary code.</p>



<p>There is an existing <a href=\"https://core.trac.wordpress.org/ticket/19958\">8-year-old ticket</a> for the feature. It has a few old and likely outdated patches and has not seen any real activity in the past four years. Nevertheless, it would be nice to see this feature in core WordPress and finally close the ticket.</p>



<h2>Block System Wish List</h2>



<p class=\"has-drop-cap\">Like most releases, the block system will be getting the most attention. The things that will land in WordPress 5.6 are mostly already set in stone, assuming a particular feature does not fall behind in development like widgets and nav menus did for the 5.5 release.</p>



<p>On the whole, I like the general direction the block system has been headed. If anything, I have been impatient with some things, such as awaiting the integrated <a href=\"https://wptavern.com/version-1-prototype-of-the-wordpress-admin-block-directory-announced\">block management screen</a> in the admin. For other features, such as full-site editing, I am still wondering whether they are realistic goals for the WordPress 5.6 release.</p>



<p>I would take a release and focus on tightening up and polishing the existing system. Take stock of the pain points &mdash; and there are many &mdash; that users are mentioning. Spend time working on smoothing out the editing experience before tacking on new features.</p>



<p>That is not going to happen. New features are what get developers up in the morning and excited about the project. Therefore, my fallback request is to bring on the block management screen.</p>



<p>What&rsquo;s on your wish list?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 31 Jul 2020 21:15:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: WordCamp US 2020 Canceled Due to Pandemic Stress and Online Event Fatigue\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102579\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/wordcamp-us-2020-canceled-due-to-pandemic-stress-and-online-event-fatigue?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-us-2020-canceled-due-to-pandemic-stress-and-online-event-fatigue\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7146:\"<p><a href=\"https://2020.us.wordcamp.org/\">WordCamp US 2020</a>, which was originally scheduled for October 27-29, was officially canceled today. In April, organizers <a href=\"https://wptavern.com/wordcamp-us-2020-goes-online-cancels-in-person-event\">transitioned to planning for it to be held as a virtual event</a>, but the tenuous situation with the pandemic in the United States and the stress on the event&rsquo;s large crew of volunteers has precipitated a full cancellation. The decision was announced on the WCUS website:</p>



<blockquote class=\"wp-block-quote\"><p>It is with heavy hearts that we have made the decision to cancel this year&rsquo;s WordCamp US event. In light of the continued pandemic, online event fatigue for attendees, organizers, and volunteers, and the desire for WordCamp experiences to be&nbsp;<em>traditional</em>&nbsp;WordCamp experiences, we have made the difficult decision to stop this year&rsquo;s planning, and cancel WordCamp US 2020.</p></blockquote>



<p>After the pandemic started forcing WordCamps and meetups to go online, many community team members seemed to put on a brave face about adapting WordCamps to virtual events, but WCUS organizers are publicly recognizing the reality of online event fatigue. </p>



<p>Angela Jin, one of the lead organizers, said her team discussed how recent online WordCamps have struggled to meet traditional goals of connecting people and encouraging contribution. In light of attendees&rsquo; increasing online conference fatigue, WCUS organizers considered the cost of volunteers&rsquo; time.</p>



<p>&ldquo;The Lead Organizers also took into consideration how many volunteers we have on this team, and how much time we were asking them to invest in an event that didn&rsquo;t seem to be able to offer the same level of joy or satisfaction that an in-person WordCamp would,<strong>&ldquo;</strong> Jin said.</p>



<p>&ldquo;As you might imagine, this was a very upsetting realization, but the whole team spent time discussing together, and we believe that we made the right decision.&rdquo;&nbsp;</p>



<p>The U.S. passed more than 150,000 Coronavirus deaths this week and outbreaks are worsening right as schools are supposed to be opening. As COVID-19 cases continue to rise sharply in many states, renewed lockdowns and political tensions have put people on edge. Every day brings a fresh injection of bad news and the country is deeply mired in division ahead of one of the most contentious presidential elections in history. Late October is not an ideal time to try to host WordPress&rsquo; flagship WordCamp online. </p>



<p>One WCUS organizer, who requested to remain anonymous, said he was angry that he invested more than 100 hours across various organizing teams and wished it had come sooner. He described how multiple personal stressors were impacting daily life and draining the team&rsquo;s energy.</p>



<p>&ldquo;I feel everyone is tired and worn out,&rdquo; he said. &ldquo;They are stressed &ndash; we are all losing friends [to COVID-19]. Everyone is fighting about politics and the work suffered.&rdquo; </p>



<p>He reported that many organizers were not doing their parts and all tasks were delayed. Although he experienced a high level of frustration with how it was handled, he was relieved when the decision was announced. Many of the event&rsquo;s 50 organizers are also involved in coordinating local meetups and leading other WordCamps, and their energies are spread thin.</p>



<p>&ldquo;This will pave the way for something new and better,&rdquo; he said. &ldquo;We have to evolve as a community and one more zoom meeting is not it.&rdquo;</p>



<p>Not all organizers considered the time invested as a loss. Cate DeRosia, who has also helped organize WordCamp Grand Rapids in the past, said the lead WCUS organizers consulted with the entire team through a multi-step process and gave opportunities for their opinions to be heard.</p>



<p>&ldquo;It&rsquo;s easy to imagine that as an organizer I&rsquo;d be disappointed by this decision, but that couldn&rsquo;t be further from the truth,&rdquo; Cate DeRosia said. &ldquo;None of this is what I&rsquo;d hoped for, but the time I&rsquo;ve invested in WCUS has helped me grow relationships and learn new skills that ultimately help me further my career goals and make me a better volunteer in the future. </p>



<p>&ldquo;COVID-19 has been unpredictable and made everything about life harder. By making this difficult decision now, we all get back a little of our time to invest in other areas instead of using up more energy and risking volunteer burnout for an event that ran the risk of getting lost amid other online events.&rdquo; </p>



<h2>State of the Word May be Hosted as a Separate, Focused Event</h2>



<p>WCUS is encouraging speakers to apply again next year. Although all regular sessions on the program were canceled, some organizers will be shifting their focus to hosting a 24-hour contributor day along with producing some workshops and youth programming content.</p>



<p>Matt Mullenweg&rsquo;s annual State of the Word address is also expected to happen but will likely take a different format this year.</p>



<p>&ldquo;Discussions about the State of the Word are still active; our understanding is that it will still happen, but possibly not in association with any other event,&rdquo; Jin said. </p>



<p>&ldquo;I&rsquo;m really excited about the potential for lots of smaller, focused, and educational ways for the community to connect online this year,&rdquo; Matt Mullenweg said. &ldquo;For the State of the Word I don&rsquo;t have a plan yet, I think there&rsquo;s less value to us watching the same thing at the same time if we can&rsquo;t hang out afterward, but it still would be fun to celebrate the great progress we&rsquo;ve been making with some sort of video. Stay tuned November-ish.&rdquo;</p>



<p>Cancellation costs for WCUS are still being finalized. Prior to making it a virtual event, the original budget was close to $1 million, with the largest costs being the venue and catering. Jin said the team will publish a full accounting of expenses on the Community Team blog or the event site after the last round of discussions with vendors are complete.</p>



<p>It&rsquo;s too soon to know if the WordCamp will be an in-person event in 2021. When asked if they will be hosting in St. Louis again, Jin said that any decisions regarding WCUS 2021 are paused for now.</p>



<p>&ldquo;The WCUS team did invest a lot of time and energy into this event, but in a year when it is incredibly hard to plan anything, we did the best we could and adapted quickly,&rdquo; she said. &ldquo;I&rsquo;m sad, of course, as I miss seeing everyone at WordCamps, but even if it was time and energy invested in something that didn&rsquo;t happen, I spent time doing it with brilliant people who care just as much about WordPress as I do. It&rsquo;s been an immensely challenging year, and I&rsquo;m humbled to have been a part of this team, which has consistently supported each other and grown together in the face of adversity.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 31 Jul 2020 01:04:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Post a Lot of Code? Try the Code Syntax Block Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102574\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/post-a-lot-of-code-try-the-code-syntax-block-plugin-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=post-a-lot-of-code-try-the-code-syntax-block-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2934:\"<p class=\"has-drop-cap\">I am always on the lookout for interesting syntax-highlighting plugins, particularly for those occasions when I write tutorials or other articles that lean heavily on code. Far too many plugins use shortcodes, custom blocks, or other odd solutions. However, there is one option that I intentionally overlooked when it was released over a year ago: <a href=\"https://wordpress.org/plugins/code-syntax-block/\">Code Syntax Block</a> by Marcus Kazmierczak.</p>



<p>Based on the name, I assumed it was yet another standalone block. However, I have since given it another look and realized that this was note the case. It integrates directly with the core WordPress block. There are times when a new block is necessary, but this is not one of those times. Sometimes it is better to extend the existing blocks in core.</p>



<p>Code Syntax Block uses the <a href=\"https://prismjs.com/\">Prism JavaScript library</a> to add syntax highlighting on the front end of the site. The plugin is designed well. It loads its scripts and styles only when the code block is in use.</p>



<img />Front end PHP code example.



<p>The plugin does not load Prism in the editor, so the code output will use the default editor or theme styling. This may not appeal to those who want a one-to-one match between the back and front end.  I am comfortable with  the non-highlighted version in the admin while having the <em>pretty</em> output on the front end.  However, it would be nice to see an option or filter to enable highlighting in the editor.</p>



<p>Out of the box, the plugin uses the <a href=\"https://github.com/AGMStudio/prism-theme-one-dark\">One Dark</a> theme, which was created for the Atom editor and ported to Prism. Developers can overwrite the theme with either a custom <code>assets/prism/prism.css</code> file in their theme or by filtering the path or URL that gets loaded.  The Prism project has a <a href=\"https://github.com/PrismJS/prism-themes\">variety of themes</a> available that are plug-and-play.  Other themes exist outside of the official list too.</p>



<p>On the admin side, the plugin creates a new &ldquo;Settings&rdquo; tab for the code block and adds a few options that users can choose from:</p>



<ul><li>Language</li><li>Show line numbers</li><li>Title for code block</li></ul>



<img />Editor view of Code Syntax Highlighter



<p>By default, the plugin does not support the full list of over 200 languages. Instead, it lists just over 40 of the most popular. The list is filterable, so anyone can add or remove languages with a few lines of code. There is also a filter hook for setting the default languages, which would be particularly useful for those who routinely post code snippets in the same coding language.</p>



<p>After a few days of testing, I can safely say that Code Syntax Block is being added to my WordPress toolbox. I wish I had only given it a shot much sooner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Jul 2020 17:30:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Bing Launches URL Submissions Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102450\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:165:\"https://wptavern.com/bing-launches-url-submissions-plugin-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=bing-launches-url-submissions-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5150:\"<p>Bing has <a href=\"https://blogs.bing.com/webmaster/july-2020/Get-your-WordPress-content-indexed-immediately-using-Bing-Webmaster-Tools-plugin\">launched</a> its first official <a href=\"https://wordpress.org/plugins/bing-webmaster-tools/\">plugin</a> for WordPress aimed at helping site owners get their content indexed immediately. Instead of waiting for a bingbot to crawl the site, the plugin notifies Bing of any new or updated content automatically using its <a href=\"https://www.bing.com/webmasters/url-submission-api\">Submit URL API</a>.</p>



<p>&ldquo;Bing&nbsp;believes that the future for search engines is less about crawling to discover content and more about sharing new and updated content across the web, a fundamental shift in the way that search engines handle web sites,&rdquo; Bing Product Manager Fabrice Canel said. &ldquo;Instead of monitoring RSS, sitemaps and HTML pages to check for new pages, discover content changes and/or new outbound links, websites will notify search engines directly about relevant URLs changing on their website.&rdquo;</p>



<p>Search engines can take anywhere from several hours to a few weeks to <a href=\"https://support.google.com/webmasters/answer/6065812?hl=en\">crawl a website</a>. Bing&rsquo;s API allows site owners to get content indexed immediately, while eventually reducing the crawling frequency for sites where there are no changes. Users will need to <a href=\"https://docs.microsoft.com/en-us/bingwebmaster/getting-access#using-api-key\">generate an API key</a> in order to configure the plugin for access to the Bing Webmaster Tools API.</p>



<img />



<p><br />The new plugin also introduces a few other options for managing URL submissions:</p>



<ul><li>Toggle the automatic submission feature</li><li>Manually submit a URL to Bing Index</li><li>View list of recent URL submissions from the plugin</li><li>Retry any failed submissions from the recent submissions list</li><li>Download recent URL submissions for analysis</li></ul>



<p>Canel said the Bing Webmaster Team recommends using the new URL Submissions plugin as a complement to existing plugins that connect sites to Bing, such as <a href=\"https://jetpack.com/support/site-verification-tools/\">Jetpack&rsquo;s site verification tool</a>, and <a href=\"https://wordpress.org/plugins/search/SEO/\">SEO plugins</a> that add XML sitemaps. Bing&rsquo;s plugin is different in that it focuses on enabling Bing to discover immediate changes on WordPress sites.</p>



<p>&ldquo;Sitemaps are a great complementary solution to our plugin to discover all URLs on WordPress sites, but we cannot monitor each sitemap all the time,&rdquo; Canel said. &ldquo;Only a small percentage of WordPress sites are publishing content every day. Most are nearly static and this is preferable to be notified instead of pulling content every so often for them. Same for sites publishing often, it helps to get the content quickly indexed instead of having to wait a long time.&rdquo;</p>



<p>Bing doesn&rsquo;t usually get as much airtime as Google and its supporting tools, since Google continues to dominate the search market. Bing&rsquo;s market share is currently <a href=\"https://gs.statcounter.com/search-engine-market-share/\">hovering at 2.75%</a> of searches globally on all platforms as of June 2020. </p>



<div id=\"all-search_engine-ww-monthly-201906-202006\" width=\"600\" height=\"400\"></div><!-- You may change the values of width and height above to resize the chart --><p>Source: <a href=\"https://gs.statcounter.com/search-engine-market-share\">StatCounter Global Stats &ndash; Search Engine Market Share</a></p>



<p>The search engine has seen slow but steady growth in certain regions and platforms. Bing performs higher globally across desktop searches (6.08%).  In the United Sates, Bing&rsquo;s market share is sitting at 6.99% and is even higher on US desktop searches (13.35%):</p>



<table><tbody><tr><th>Google</th><td>87.71%</td></tr><tr><th>bing</th><td>6.99%</td></tr><tr><th>Yahoo!</th><td>3.44%</td></tr></tbody></table><a href=\"https://gs.statcounter.com/search-engine-market-share/\">Search Engine Market Share in US &ndash; June 2020</a>



<p>Bing may not boast a big slice of the search market pie, but the search engine served close to <a href=\"https://www.statista.com/statistics/752270/range-of-bingcom-based-on-unique-visitors/\">936.5 million</a> unique global visitors during the month of May 2020. More than half of Bing users have a bachelor&rsquo;s or post graduate degree and <a href=\"https://www.statista.com/statistics/742834/usa-bing-audience-share-by-income/\">38% of Bing users</a> have an income of $100,000 USD or higher. Depending on the demographic you are targeting, being found by Bing users may be one small factor in your site&rsquo;s overall success. </p>



<p>The search engine recently updated its <a href=\"https://www.bing.com/webmaster/help/webmaster-guidelines-30fba23a\">webmaster guidelines</a> for the first time since 2012. If you&rsquo;re looking to optimize for Bing&rsquo;s audience, this document contains a detailed break down of how the search engine ranks content. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2020 23:49:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Upcoming in WordPress 5.5: Features and Changes Theme Authors Should Know About\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102535\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:221:\"https://wptavern.com/upcoming-in-wordpress-5-5-features-and-changes-theme-authors-should-know-about?utm_source=rss&utm_medium=rss&utm_campaign=upcoming-in-wordpress-5-5-features-and-changes-theme-authors-should-know-about\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8147:\"<p class=\"has-drop-cap\">August 11, the target release date for WordPress 5.5, is just shy of two weeks away. For developers who have not been completely on top of the upcoming release, now is a good time to start looking at how changes might affect their projects. Theme authors in particular can expect several new features and some breaking changes.</p>



<p>For the most part, WordPress 5.5 will introduce new features that theme developers can begin to add to their themes. However, the two biggest changes that could negatively impact their themes will be automatic updates and direct HTML changes to the custom logo output.</p>



<p>Outside of the new features and changes, theme authors should catch up on our <a href=\"https://wptavern.com/tag/gutenberg\">coverage of the Gutenberg plugin</a> and test against its updates that are being merged into core WordPress.</p>



<h2>Auto Updates</h2>



<p class=\"has-drop-cap\">WordPress 5.5 will finally introduce <a href=\"https://wptavern.com/automatic-theme-and-plugin-updates-slated-for-wordpress-5-5\">automatic updates for plugins and themes.</a> It is a long-awaited feature and should be a good thing in terms of keeping end-users updated and running what is usually the most secure version of their extensions. However, the big downside to automatic updates is that most themes and plugins will not have the same level of quality control as core WordPress receives. Even the best development companies might have only a few people looking over the code.</p>



<p>On the flip-side, the automatic updates feature means that theme authors can push fixes out to end-users much more quickly.</p>



<p>The big thing is that theme developers need to be aware that users will be enabling automatic updates. For some, this might not mean changing anything with their release cycles. For others, it might mean tacking on some extra time to ensure that extra quality control is in place. The success of automatic updates lies directly on the shoulders of the plugin and theme authors. It is a huge responsibility that should not be taken lightly. WordPress is placing a lot of trust in its development community to get this right.</p>



<h2>HTML Change for Custom Logos</h2>



<p class=\"has-drop-cap\">As part of an <a href=\"https://core.trac.wordpress.org/ticket/37011\">accessibility-related ticket</a> for WordPress 5.5, the core <code>get_custom_logo()</code> and <code>the_custom_logo()</code> functions will no longer <a href=\"https://make.wordpress.org/core/2020/07/28/themes-changes-related-to-get_custom_logo-in-wordpress-5-5/\">output a link around the logo image</a> when viewing the site homepage. This change was made because the link itself points to the homepage by default and is unnecessary in that context.</p>



<p>Right now, there are 183 themes in the official theme directory that target the link in their CSS. This does not necessarily mean that all 183 themes will be broken upon update. However, it likely means that some of them will need a tweak or two.</p>



<p>Theme authors are encouraged to target the <code>.custom-logo-link</code> class instead of any particular HTML element. The new change will add a <code>&lt;span&gt;</code> element rather than an <code>&lt;a&gt;</code> element on the homepage. Both will use the same class.</p>



<h2>Block Patterns Have Arrived</h2>



<p class=\"has-drop-cap\">It is no secret that I am <a href=\"https://wptavern.com/block-patterns-will-change-everything\">downright giddy</a> about the prospect of theme designers being loosed upon the world, allowing their talents to shine via block patterns.  Patterns have been one of the missing features since the initial launch of the Gutenberg project. For theme authors, they represent that missing link between designing unique &ldquo;templates&rdquo; or &ldquo;sections&rdquo; and providing end-users a means to add them to their sites.</p>



<p>Block patterns are essentially groups of pre-configured blocks that users can insert into their posts or pages at the click of a button. The beauty of the system is that theme authors can design whatever patterns their hearts desire and make them easily available to their users. No need for complicated theme settings. No lengthy tutorials explaining how to recreate the demo. Design something in the block editor. Register it as a pattern. Let users insert it into a post and rejoice.</p>



<p>This is an opportunity that theme authors have never had before. It is an opportunity to create beautiful designs without having to worry about overcomplicating it for the average user. It is a pivotal moment in WordPress theme design history. Theme authors have the chance to push the system and see what WordPress and its block editor are truly capable of.</p>



<p><em>Building a restaurant theme?</em> Provide users with multiple food menu patterns. <em>Creating something for novelists or other book authors?</em> Give users some layout options for showcasing their books.</p>



<p>The <a href=\"https://developer.wordpress.org/block-editor/developers/block-api/block-patterns/\">block patterns API</a> removes many prior limits to what theme authors could realistically do. Now, it&rsquo;s time for those theme authors to take charge.</p>



<h2>Line Heights and Custom Units</h2>



<p class=\"has-drop-cap\">The block editor has two new tools for end-users to take advantage of: <a href=\"https://make.wordpress.org/core/2020/07/27/new-block-tools-on-wordpress-5-5/\">custom line-heights and custom units</a>. Theme authors can opt into allowing users to edit the line-height of paragraphs and headings with the <code>custom-line-heights</code> theme support flag. They can also allow users to switch between various units, such as when defining the Cover block&rsquo;s height, with the <code>custom-units</code> flag. In addition to pixels, themes can define which units are supported.</p>



<p>Allowing users to customize the line-height value for text can be tricky business. There are some situations where it is warranted. However, for theme authors who prefer to maintain a strict vertical rhythm, this could lead to disaster. This will likely come down to a personal choice for developers based on what type of theme they are building.</p>



<h2>Accessible Widgets Navigation</h2>



<p class=\"has-drop-cap\">Starting with WordPress 5.5, theme authors will be able to opt into outputting more <a href=\"https://make.wordpress.org/core/2020/07/09/accessibility-improvements-to-widgets-outputting-lists-of-links-in-5-5/\">accessible widgets</a>. By default, widgets that display unordered lists do so without any context. This can make it difficult for those using assistive technologies to navigate the site.</p>



<p>Theme authors can now add <code>navigation-widgets</code> to the HTML5 theme supports array to add the new markup. WordPress will then wrap all core widgets with a <code>&lt;nav&gt;</code> element and an <code>aria-label</code> based on the widget title.</p>



<p>This will not affect widgets from third-party plugins. Plugin authors should reevaluate their widgets to determine if they want to support this feature.</p>



<h2>Template Functions Updates</h2>



<p class=\"has-drop-cap\">WordPress is tacking on some nice features for its templating functions in the upcoming release. The first major change is that theme authors can pass data to template files. We have <a href=\"https://wptavern.com/theme-authors-can-pass-data-to-template-files-in-wordpress-5-5\">previously covered</a> this story on the Tavern. This feature, while years late, should still be useful for more complex theming setups and allow developers to bypass odd workarounds or in-house solutions.</p>



<p>Template-loading functions, such as <code>get_template_part()</code> and others, will also <a href=\"https://core.trac.wordpress.org/ticket/40969\">return a value</a> in WordPress 5.5. If the template is not found, the function will return a <code>false</code> value. Otherwise, it will return <code>void</code>. This will be helpful in situations where theme authors need to run a conditional to check if a template exists.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2020 22:05:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"WPTavern: Gutenberg 8.6 Adds Cover Block Video Positioning and Updates Block Patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102512\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://wptavern.com/gutenberg-8-6-adds-cover-block-video-positioning-and-updates-block-patterns?utm_source=rss&utm_medium=rss&utm_campaign=gutenberg-8-6-adds-cover-block-video-positioning-and-updates-block-patterns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4671:\"<p class=\"has-drop-cap\">Gutenberg 8.6 <a href=\"https://make.wordpress.org/core/2020/07/22/whats-new-in-gutenberg-july-22/\">landed quietly last week</a>. Much of the focus right now is ironing out the remaining bugs for WordPress 5.5 during its beta cycle. However, that does not mean the Gutenberg project has come to a complete halt in terms of new features. The team is marching forward with extra goodies for those who use the plugin.</p>



<p>The latest update of the plugin did not cover as much ground as normal, but it does include an enhancement for the Cover block when using a video background and several updates to block patterns.</p>



<p>The primary focus for version 8.6 was squashing bugs. The development team addressed over three dozen of them while correcting a handful of performance issues. While new features and enhancements from 8.6 onward are not expected in the upcoming WordPress 5.5, most bug fixes should be included.</p>



<h2>Focal Point Selector for Video Covers</h2>



<img />Selecting a focal point for a video background.



<p class=\"has-drop-cap\">The Cover block has long allowed users to pick a focal point for background images. However, this feature was missing when users added a background video to the block. As of version 8.6, that is no longer the case. Both image and video backgrounds should work in much the same way.</p>



<p>Gutenberg now has a new &ldquo;<a href=\"https://github.com/WordPress/gutenberg/pull/22531\">Focal point picker</a>&rdquo; option located under the &ldquo;Media settings&rdquo; tab when adding a video background. Users can select the focal point by dragging the circle icon in the video box or hardcode left and top percentage values in the input fields below it.</p>



<p>This is not a particularly exciting development for most Gutenberg users.  Self-hosting video is not cheap and remains unused for most. However, for those who do use video backgrounds, it is one of those nice-to-have features that is there when needed.</p>



<h2>Updated Block Patterns</h2>



<img />Inserting the updated quote block pattern.



<p class=\"has-drop-cap\">The Gutenberg team updated several of the existing block patterns. For the most part, the pattern updates were minor cosmetic changes, tweaks that improve the overall design. The button-related patterns received simple changes, such as new <a href=\"https://github.com/WordPress/gutenberg/pull/23848\">text labels</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23849\">colors</a>. The developers also changed the colors and text of the large header patterns.</p>



<p>The team moved the header above the columns in the <a href=\"https://github.com/WordPress/gutenberg/pull/23853\">two columns text pattern</a> and changed the text to make the columns appear equal height by default. It is a poor use of textual columns, which would ideally be handled with CSS instead so that it works appropriately across screen sizes. Perhaps it would be better to have a &ldquo;Text Columns&rdquo; block in the long run.</p>



<p>The nicest block pattern update was for the <a href=\"https://github.com/WordPress/gutenberg/pull/23881\">quote pattern</a>. It now has an image at the top and a separator at the bottom. It is akin to a single testimonial, which is more of a <em>pattern</em> than a basic quote.</p>



<p>Theme authors can also <a href=\"https://github.com/WordPress/gutenberg/pull/24042\">remove support</a> for the core block patterns with a single line of code: <code>remove_theme_support( \'core-block-patterns\' )</code>. This does not drop support for patterns altogether. For example, patterns added by plugins or the theme will still appear in the inserter.</p>



<h2>Site Icon Used in Fullscreen Mode</h2>



<img />Site icon appears in top left in fullscreen mode.



<p class=\"has-drop-cap\">When writing in fullscreen mode, the &ldquo;back to posts&rdquo; link has utilized the WordPress logo in the past. In version 8.6, the user&rsquo;s custom <a href=\"https://github.com/WordPress/gutenberg/pull/22952\">site icon will take its place</a>. However, this will only happen if the user has uploaded an icon via the customizer.</p>



<p>I am unsure how I feel about this change. In practice, it almost feels like clicking the icon should take me to the front end of the site instead of the post management screen. At least with the WordPress icon, it felt like it was pointing toward an admin-side screen instead. For my workflow, I would rather see this link/icon replaced with a button that toggles between fullscreen and normal mode, popping the admin menu back into place rather than departing the editing screen altogether.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2020 20:59:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"WordPress.org blog: WordPress 5.5 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8732\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2020/07/wordpress-5-5-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2968:\"<p>The first release candidate for WordPress 5.5 is now available!</p>



<p>This is an important milestone in the community&#8217;s progress toward the final release of WordPress 5.5. </p>



<p>“Release Candidate” means that the new version is ready for release, but with millions of users and thousands of plugins and themes, it’s possible something was missed. WordPress 5.5 is slated for release&nbsp;on&nbsp;<strong>August 11, 2020</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.5 yet,&nbsp;<strong>now is the time</strong>!</p>



<p>You can test the WordPress 5.5 release candidate in two ways:</p>



<ul><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-RC1.zip\">download the release candidate here (zip)</a>.</li></ul>



<p>Thank you to all of the contributors who tested the&nbsp;Beta releases and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress.</p>



<h2>What’s in WordPress 5.5?</h2>



<p>WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developer notes</a>&nbsp;tag for updates on those and other changes that could affect your products.</p>



<h2>Plugin and Theme Developers</h2>



<p>Please test your plugins and themes against WordPress 5.5 and update the&nbsp;<em>Tested up to</em>&nbsp;version in the readme file to 5.5. If you find compatibility problems, please be sure to post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">support forums</a>,&nbsp;so those can be figured out before the final release.</p>



<p>The&nbsp;WordPress 5.5 Field Guide, due very shortly, will give you a more detailed dive into the major changes.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev\">Help us translate WordPress into more than 100 languages!</a>&nbsp;This release also marks the <a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">hard string freeze</a>&nbsp;point of the 5.5 release schedule.</p>



<p><em><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">fill one on WordPress Trac</a>, where you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2020 19:08:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: WordPress to Stick with Online-Only Meetups and WordCamps for Remainder of 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102462\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:223:\"https://wptavern.com/wordpress-to-stick-with-online-only-meetups-and-wordcamps-for-remainder-of-2020?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-to-stick-with-online-only-meetups-and-wordcamps-for-remainder-of-2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6256:\"<img />photo credit: <a href=\"https://stocksnap.io/photo/macbook-computer-JPZDGEMDH3\">Burst</a>



<p>The WordPress Community Team has officially updated its guidelines for WordCamps to be online-only events for the remainder of 2020. The six WordCamps on the <a href=\"https://central.wordcamp.org/schedule/\">schedule</a> through the end of the year were already planning on using an online format but the guidelines also include local <a href=\"https://make.wordpress.org/community/events/online/\">meetups</a>. </p>



<p>&ldquo;The team acknowledges that this is not easy for the community that has been heavily based on in-person events and encounters,&rdquo; Timi Wahalahti said in the <a href=\"https://make.wordpress.org/community/2020/07/27/in-person-events-in-rest-of-year-2020/\">announcement</a>. &ldquo;Unfortunately, the global coronavirus situation does not seem to be slowing down to a level that would allow us organizing in-person events safely at this time.&rdquo;</p>



<p>The guidelines will be re-evaluated in the first quarter of 2021, but some organizers are already planning for online events next year. WordCamp Europe 2021 is the first WordPress event to <a href=\"https://wptavern.com/wordcamp-europe-goes-virtual-for-2021-in-person-conference-to-resume-2022\">go virtual for the coming year</a>, with the in-person event resuming in 2022.</p>



<p>Moving what was once a vibrant in-person gathering to a two-dimensional online format is a challenging endeavor, especially when the world is suddenly awash in online events competing for attention. Making virtual events stand out from the crowd is a new marketing challenge. </p>



<p>There is something about the magic of WordCamps that gives momentum to ideas and collaboration. While you cannot replicate the chance meetings in the hallway and the priceless conversations over long dinners, online events have the benefit of being more geographically inclusive. The constraints of the pandemic are also challenging our assumptions about how online gatherings are supposed to work.</p>



<h2>WordPress Community Team to Explore New Event Formats, Redefine Relationships with Sponsors, Temporarily Cancel Swag Spending</h2>



<p>The necessity for virtual events has inspired discussion around some new event formats, including a new <a href=\"https://make.wordpress.org/community/2020/07/23/building-community-beyond-events/\">proposal</a> that decouples online events from geography. WordPress Community manager Hugh Lashbrooke described how events might explore combining synchronous discussions with previously recorded workshops:</p>



<blockquote class=\"wp-block-quote\"><p>What if we blended those two elements into a program that provides the flexibility of online content, with the value and sense of community that comes with learning together?</p><p>We could publish workshops in a central location (on&nbsp;<code>wordpress.org</code>, for better visibility and reach) and then invite learners to join live discussion groups that cater to different timezones. This &ldquo;<a href=\"https://en.wikipedia.org/wiki/Flipped_classroom\">flipped classroom</a>&rdquo; model allows people to learn at their convenience, and then come together for additional development.&nbsp;</p></blockquote>



<p>Lashbrooke suggested the workshops could be designed by people who would otherwise be speaking WordCamps and could possibly source content from WordPress.tv or talks that have been given at online meetups.</p>



<p>&ldquo;There is also potential for longer courses, composed of multiple workshops, and a group that meets repeatedly over time,&rdquo; Lashbrooke said.</p>



<p>So far the suggestions in  the comments include introductory workshops for WordPress. These would be timely for newcomers who have recently lost work and are looking to improve their online resumes or portfolios, or start up a new business. Beginner workshops have strong outreach potential if promoted outside of the WordPress community.</p>



<p>During the first half of the year, the Community Team began transitioning to facilitating the needs of online events and have continued to work tirelessly to find ways for people to connect. In a recent <a href=\"https://make.wordpress.org/community/2020/07/23/moving-forward-with-online-events/\">update</a>, WordPress community organizer Andrea Middleton explained that changes are coming for future online events, which may adopt another name instead of using &ldquo;WordCamp.&rdquo;</p>



<p>Due to the<a href=\"https://make.wordpress.org/community/2020/05/11/financial-update-on-wordpress-community-programs/\"> financial position</a> of WordPress Community Support PBC (WPCS), the community team is ending programmatic support for online AV vendor expenses. WordCamps that are not yet on the schedule will be encouraged to get sponsorships if they require the use of a professional AV vendor.</p>



<p>&ldquo;Likewise, we have paused plans to spend money on sending swag, T-shirts, or other typical WordCamp collateral,&rdquo; Middleton said. &ldquo;It&rsquo;s important to change our frame of reference for what&rsquo;s necessary to make online events, away from the WordCamp model. Just because we did things a certain way for WordCamps, doesn&rsquo;t mean it&rsquo;s a high priority for online events.&rdquo;</p>



<p>Sponsorships are also being re-examined, as online events haven&rsquo;t quite been able to deliver the same value to sponsors that traditional events did.</p>



<p>&ldquo;The value proposition of online sponsor booths is shaky, and we&rsquo;ve always prided ourselves in partnering with our sponsors,&rdquo; Middleton said. &ldquo;Looking ahead, we must examine how much funding we&nbsp;<strong>need</strong>&nbsp;to create events that meet the goals of the team, and let that determine how to best coordinate with our community sponsors to deliver value and further our mission.&rdquo; </p>



<p>The potential for in-person events for the coming year is still uncertain at this point, in the absence of a vaccine ready for commercial distribution. WordPress&rsquo; global sponsorship program has been temporarily suspended and the Community Team plans to work with global sponsors later this year to make a plan for 2021.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2020 01:06:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Are Plugin Authors to Blame for the Poor Admin Notices Experience?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102405\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:195:\"https://wptavern.com/are-plugin-authors-to-blame-for-the-poor-admin-notices-experience?utm_source=rss&utm_medium=rss&utm_campaign=are-plugin-authors-to-blame-for-the-poor-admin-notices-experience\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6619:\"<p class=\"has-drop-cap\">Last Thursday, Vova Feldman published an article asking that we <a href=\"https://freemius.com/blog/wordpress-admin-notices/\">stop blaming plugin authors</a> for the plethora of admin notices that users are bombarded with each day. <em>The real culprit?</em> The lack of a notifications mechanism in WordPress core.</p>



<p>Feldman&rsquo;s post was prompted by a <a href=\"https://twitter.com/scottbolinger/status/1280567235006742528\">tweet</a> in which Scott Bolinger called out plugin authors for letting admin notices get out of control:</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Good lord WordPress plugin authors, this is out of control. <a href=\"https://t.co/0S42908C5T\">pic.twitter.com/0S42908C5T</a></p>&mdash; Scott Bolinger (@scottbolinger) <a href=\"https://twitter.com/scottbolinger/status/1280567235006742528?ref_src=twsrc%5Etfw\">July 7, 2020</a></blockquote>
</div>



<p>Feldman argues that laying the blame on plugin authors is the wrong way to look at the issue. While I agree that the underlying problem lies with WordPress, plugin authors have played their part in creating an atmosphere where they have become the scapegoat for everything wrong with the system.</p>



<p>I have developed plugins since a fateful day in April 2007 in which I released a plugin that simply listed the current page&rsquo;s subpages. I have worked on 100s of plugins for clients and public release since then. In that time, I have maybe added a custom admin notice two times and only when the plugin had a major change, such as a database update. I reserved such notices for the OMGBBQ-very-important-you-need-to-read-this type of stuff. I considered it my duty to create an experience in which the user did not have to dismiss a notice every time one of my plugins received an update.</p>



<p>This was not because I was cognizant of the growing issue of dozens of notices on some sites or how often users were being overwhelmed with them. For many years, I worked within a bubble where I simply focused on creating what I considered an ideal experience for my users. I always thought the admin notices system created an abysmal experience. It did not make sense to use it more than necessary.</p>



<p>On the other hand, there were likely a few times over the years where I should have added some sort of notices for changes. Instead, I avoided doing so altogether because WordPress lacked a notifications system. I missed some good opportunities for communication.</p>



<p>To a large extent, the issue stems from this lack of a proper notification system. However, plugin authors have perpetuated this broken system by continuing to use it when unnecessary. They have used it as a billboard to place their <a href=\"https://wptavern.com/black-friday-banner-gone-wrong-advertising-in-free-plugins\">holiday ads</a>. They have used it to upsell commercial versions of their products and services while prompting users for a five-star rating. There is plenty of blame to go around.</p>



<p>Instead of placing blame, we should start asking what tools would solve problems for developers.</p>



<h2>The Need for a Better System</h2>



<p class=\"has-drop-cap\">Technically, WordPress simply has a hook and a set of common classes that developers can use in their HTML to provide some different colors for notices. There is no API, and without an API, it is impossible for even third-party plugin developers to even try their hands at creating various solutions.</p>



<p>The closest thing WordPress has to an API is a little-known project from the Themes Team that provides a <a href=\"https://github.com/WPTT/admin-notices\">standardized method for theme authors</a> to add notices. However, the project covers only one aspect of admin notices, which is to create a consistent UI.</p>



<p>The admin notice issue cannot be properly addressed without identifying the problems that plugin authors have tried to solve within the system, which at least includes the following:</p>



<ul><li>User-oriented notifications, generally appearing after a user action.</li><li>Advertising commercial products and services.</li><li>Calls for plugin feedback or star ratings.</li></ul>



<p>One of the primary issues with the current notification system is that it was created for the first item in that list. The other two items are not necessarily bad things. They are just poor usages of the system in place. However, there is no other standard method to handle those scenarios.</p>



<p>Advertising is something we all must deal with in some form or fashion. I am unsure if there could or even should be a standard API for advertising. An outright ban of ads in the admin notice area could create a beast of its own, forcing plugin authors to come up with more obtrusive forms of advertising in other areas of the admin. I want to support advertising but not when that advertising wiggles its way to the top of every admin screen.</p>



<p>WordPress provides no easy way for end-users to rate or review plugins from their admin interfaces. Having an easy way to provide direct feedback would be immensely helpful for both users and developers. While I am certain many people would argue against such integration with the WordPress.org site (there are arguments against any external integration out of the box), ratings and reviews would require an explicit opt-in from end-users because they would need an account on WordPress.org.</p>



<p>Advertising and plugin feedback should not be a part of a discussion on admin notices. However, reality dictates that they are integral to the conversation.</p>



<p>The first order of business must be to create a new notification system from the ground up. It should provide a standard API for plugin authors while handing over full management capabilities to the site owners. Users should be able to disable notices altogether or even enable/disable notices on a per-plugin basis. <em>Notice that a particular plugin author provides useless notices?</em> Well, just disable notices from that plugin. The author lost their privileges.</p>



<p>From that point, we can let the progress drive the discussion on what to do about advertising and calls for feedback. A new system may shift them to a new screen &mdash; out of sight out of mind &mdash; but not make those problems disappear.</p>



<p>More than anything, it is time for a champion.  The project does not get done without someone who will pave the path forward and earn the green light for a new notifications system in WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 21:40:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.5 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3766:\"<p>WordPress 5.5 Beta 4 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong> so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 4 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta4.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">beta 3</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-3/\">beta 3</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=07%2F22%2F2020..07%2F28%2F2020&milestone=5.5&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 4:</p>



<ul><li>Add <code>\"loading\"</code> as an allowed kses image attribute (see <a href=\"https://core.trac.wordpress.org/ticket/50731\">#50731</a>).</li><li>Add filter for the plugin/theme auto-update message in the Info tab of Site health (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50663\">#50663</a>).</li><li><code>$_SERVER[\'SERVER_NAME\']</code> not a reliable when generating email host names (see <a href=\"https://core.trac.wordpress.org/ticket/25239\">#25239</a>)</li><li>Several backported fixes from Gutenberg are included in WordPress 5.5 Beta 4 (<a href=\"https://github.com/WordPress/gutenberg/pull/24218\">See PR #24218</a>)</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 20:56:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Baumwald\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Donncha: Crowdsignal Polls in your Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"https://odd.blog/?p=89503098\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://odd.blog/2020/07/27/crowdsignal-polls-in-your-block-editor/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2423:\"<div class=\"aligncenter crowdsignal-poll-wrapper\"></div>


<p>The <a href=\"https://crowdsignal.com/\">Crowdsignal</a> team at Automattic have been quietly working on a new <a href=\"https://wordpress.org/plugins/crowdsignal-forms/\">poll block</a> for the last few weeks. We finally made it public today on WordPress.org!</p>



<div class=\"wp-block-image\"><img /></div>



<p>We set out with the task of creating a block that would allow the writer to quickly insert a poll in their posts using the block editor. More than that, it had to be simple to use. It also needed to be themed to match the look and feel of the website it would appear on.</p>



<div class=\"wp-block-image size-large\"><img /></div>



<p>We&#8217;ve created a block that does that. It also records the votes collected on the Crowdsignal website where you can analyse the results using reports Crowdsignal users have always used.</p>



<div class=\"wp-block-image size-large\"><img /></div>



<p>Search for &#8220;Crowdsignal Forms&#8221; on your plugins page to install it in the usual way.</p>



<p>A free <a href=\"https://crowdsignal.com/\">Crowdsignal</a> account is required to use the block. We made it really easy to connect your site to your Crowdsignal account. If you don&#8217;t have one then creating a new account is simple too.</p>



<div class=\"wp-block-image\"><img /></div>



<p>The first 2,500 responses you collect are included in your free account, and further votes are recorded but free users are encouraged to upgrade if they want to do further analysis of all the data they collect.</p>

<p><strong>Related Posts</strong><ul><li> <a href=\"https://odd.blog/2004/01/29/htmlarea-the-free-customizable-online-editor/\" rel=\"bookmark\" title=\"Permanent Link: HTMLArea &#8212; the free, customizable online editor\">HTMLArea &#8212; the free, customizable online editor</a></li><li> <a href=\"https://odd.blog/2003/04/02/cross-browser-rich-text-editor/\" rel=\"bookmark\" title=\"Permanent Link: Cross-Browser Rich Text Editor\">Cross-Browser Rich Text Editor</a></li><li> <a href=\"https://odd.blog/2003/05/22/cross-browser-rich-text-editor-work-in-firebird/\" rel=\"bookmark\" title=\"Permanent Link: Cross-Browser Rich Text Editor &#8211; work in Firebird?\">Cross-Browser Rich Text Editor &#8211; work in Firebird?</a></li></ul></p>
<p><a href=\"https://odd.blog/2020/07/27/crowdsignal-polls-in-your-block-editor/\" rel=\"nofollow\">Source</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 19:17:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Donncha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"HeroPress: HeroPress Gets A Surprise\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=3242\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:117:\"https://heropress.com/heropress-gets-a-surprise/#utm_source=rss&utm_medium=rss&utm_campaign=heropress-gets-a-surprise\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1373:\"<img width=\"960\" height=\"540\" src=\"https://s20094.pcdn.co/wp-content/uploads/2020/07/heropress_cape_video_thumb-1024x576.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Topher wearing his cape.\" />
<p>A couple of months ago <a href=\"https://twitter.com/michelleames\">Michelle Frechette</a> approached me about being on a podcast for <a href=\"https://sentree.io\">Sentree.io</a>. I didn&#8217;t realize at the time I was going to be their inaugural guest! We had a great time, and things got back to normal.</p>



<p>Several weeks later Michelle said they sent me a thanks gift, which was very thoughtful, and that I should have someone video the unboxing. I never once imagined what they actually sent me.  Here&#8217;s the video.</p>



<div class=\"wp-block-embed__wrapper\">
<div class=\"jetpack-video-wrapper\"></div>
</div>



<p>My family already has all sorts of ideas about how to use it at WordCamps. I just hope it survives being worn ALL DAY EVERY DAY.</p>



<p>It&#8217;s super well made, I snooped a little and found the etsy shop it came from. Really great embroidery and seaming. Really classy.</p>



<p>Thanks Sentree, and thanks Michelle.  :)</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/heropress-gets-a-surprise/\">HeroPress Gets A Surprise</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2020 13:31:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Develop, Test, and Showcase Blocks in Isolation With BlockBook\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102310\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:185:\"https://wptavern.com/develop-test-and-showcase-blocks-in-isolation-with-blockbook?utm_source=rss&utm_medium=rss&utm_campaign=develop-test-and-showcase-blocks-in-isolation-with-blockbook\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4143:\"<p class=\"has-drop-cap\">Riad Benguella <a href=\"https://riad.blog/2020/07/22/introducing-blockbook-for-wordpress/\">released BlockBook</a>, a project that promises to overhaul how developers build blocks and more, on Tuesday. It is a development environment that allows creators to work with blocks in isolation, outside of WordPress. Developers can view individual block properties and test output from a defined block library.</p>



<p>BlockBook is available as an <a href=\"https://www.npmjs.com/package/blockbook-cli\">npm package</a>. Developers can also contribute to the project through its <a href=\"https://github.com/youknowriad/blockbook\">GitHub repository</a>.</p>



<p>Benguella got the idea from <a href=\"https://storybook.js.org/\">Storybook</a>, which is an open-source tool for developing UI components for React, Vue, Angular, and other JavaScript libraries in isolation. It is an environment that makes development and testing more efficient for individual components. It also allows end-users the opportunity to test those components before they are brought into a project. The goal for BlockBook is to bring a similar system to WordPress block development.</p>



<p>&ldquo;If we think about it a little bit, blocks are reusable units that can live on their own outside of any context, they can be edited visually, and they produce markup,&rdquo; wrote Benguella in the announcement post. &ldquo;They have in fact a lot in common with React Components. They are super-powered React Components.&rdquo;</p>



<p>He believes that BlockBook will be able to solve many of the issues around block development by taking the principles of the Storybook application and employing them into an environment specifically for building, testing, documenting, and sharing blocks.</p>



<p>Benguella has a full <a href=\"https://youknowriad.github.io/blockbook/\">demo available</a> as a GitHub page. Developers can do the same with their plugins or simply host it as a static site on their own server.</p>



<img />BlockBook example output of the Gallery block.



<p>In his post, he identified three major challenges that his project is meeting head-on. The first, and most obvious for anyone who has delved into block development, is creating blocks within the WordPress environment. It is a tedious and inefficient process to develop and test blocks in the WordPress admin. By isolating the block code, developers can bypass many of the routine tasks every time they make a code change to a block.</p>



<p>The second challenge was to figure out a way to make theme testing much easier. For theme authors with one or two themes, testing block styling is relatively easy. However, for businesses, agencies, and others who maintain many themes, there is no good way to quickly see how individual blocks behave for each of the themes. BlockBook allows theme authors to register any number of themes. Essentially, developers add a few lines of code and point to the appropriate stylesheet. Once set up, testing is as simple as switching themes via a dropdown select and moving between individual blocks. All of this happens almost instantly.</p>



<p>The third part of the equation involves end-users. Currently, users have no good way to test blocks without installing a block plugin, heading to their editor, and tinkering around with it. If they do not like the block, they must start the process all over again. With BlockBook, developers can make their blocks available for testing beforehand. They can even allow end-users to beta test blocks and provide feedback without installing a plugin at all.</p>



<p>However, that is still not quite as efficient as Benguella would like. It would rely on individual developers. For the long-term, he hopes the project becomes an official WordPress package. This creates the possibility of WordPress.org automatically building and hosting a BlockBook for plugins and themes, giving users a chance to test before installing.</p>



<p>This is something that could be revolutionary for users if the official WordPress project could take it on and create a solid user experience around it.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 24 Jul 2020 19:00:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Unsplash Responds to Image Licensing Concerns, Clarifies Reasons for Hotlinking and Tracking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102268\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:247:\"https://wptavern.com/unsplash-responds-to-image-licensing-concerns-clarifies-reasons-for-hotlinking-and-tracking?utm_source=rss&utm_medium=rss&utm_campaign=unsplash-responds-to-image-licensing-concerns-clarifies-reasons-for-hotlinking-and-tracking\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22930:\"<p>Concerns are mounting regarding Unsplash&rsquo;s terms and image licensing after the site <a href=\"https://wptavern.com/unsplash-launches-official-plugin-for-wordpress\">launched its official WordPress plugin</a> this week. Several people commented on the restrictions and lack of clarity in the license. </p>



<p>&ldquo;The irony here is that this goes against Unsplash&rsquo;s own licensing for images,&rdquo; Aris Stathopoulos commented. &ldquo;It&rsquo;s vague and restrictive to the point where one doesn&rsquo;t even know if they can actually use the images they import.&rdquo;</p>



<p>Matt Mullenweg responded to Stathopoulos&rsquo; comment, saying, &ldquo;I agree, not sure if this should be allowed in the directory.&rdquo;</p>



<p>The last time the site made a major splash in WordPress news was in 2017 after <a href=\"https://wptavern.com/unsplash-updates-its-license-raises-gpl-compatibility-concerns\">revising its license</a> to prohibit the compilation of photos for the creation of a similar or competing service. Its new branded license made the library&rsquo;s images incompatible with the GPL and unable to distributed with WordPress themes and plugins.</p>



<p>Unsplash co-founder Luke Chesser believes these comments are due to a misunderstanding about the license change.</p>



<p>&ldquo;As you know, themes have a requirement that themes and their content be GPL compatible,&rdquo; Chesser said. &ldquo;Outside of themes, WordPress&rsquo;s application of GPL doesn&rsquo;t apply to content in plugins. That&rsquo;s why you can have a YouTube plugin, a Getty Images plugin, a Giphy plugin, etc. &mdash; none of this content is licensed under GPL. In most cases plugins serve content that has a very narrow usage license, much, much more restrictive than the Unsplash License.&rdquo;</p>



<h2>Why Unsplash Abandoned Creative Commons Zero Licensing</h2>



<p>To understand the sensitivity to Unsplash&rsquo;s licensing change, one must dust off a bit of web history. When the site first started in 2013, the images were licensed under the very permissive&nbsp;<a rel=\"noreferrer noopener\" href=\"http://creativecommons.org/publicdomain/zero/1.0/\" target=\"_blank\">Creative Commons Zero</a>&nbsp;license. It quickly grew from a Tumblr-hosted photo blog that shared &ldquo;10 new photos every 10 days&rdquo; for free, to one of the most popular photo libraries on the web. </p>



<p>Chesser said the real life problems the Unsplash community encountered caused his team to change the licensing to protect photo authors. </p>



<p>&ldquo;People were downloading the images and reselling them on Getty and Shutterstock,&rdquo; he said. &ldquo;Even if the people doing this made no money, it was such a negative experience for Unsplash contributors that they would remove their images from Unsplash, removing content that was previously available to openly be created with.</p>



<p>&ldquo;Scraping of the site and the library had a similar effect as contributors would see their photos copied over to thousands of free image sites they never signed up for, or worse, their photos being made available to other sites with no attribution.&rdquo;</p>



<p>Unsplash contributors were likely not fully aware of the freedoms that the CC0 license affords. These problems may be undesirable applications of the license but they were not outright misuses. When Unsplash changed its license, approximately 200,000 images were no longer identified on the site as being part of the public domain. </p>



<p>Creative Commons got involved after the organization started receiving questions from users in the open content and free software movements. Ryan Merkley, CEO of Creative Commons at that time, penned an <a href=\"https://creativecommons.org/2017/06/22/unsplash/\">update</a> on Unsplash&rsquo;s licensing change to the CC community, expressing the organization&rsquo;s concerns.</p>



<p>&ldquo;Our intention is to ensure that CC community members understand what has happened to a service they have been using that incorporated CC tools, and to protect the content that was dedicated to the public domain,&rdquo; Merkley said.</p>



<p>Creative Commons called on Unsplash to properly differentiate the works that were previously shared under the irrevocable CC0 license so that they would not disappear from the public domain:</p>



<blockquote class=\"wp-block-quote\"><p>Following the switch to the new Unsplash-branded license, there is no marking of works that were previously shared in the public domain using CC0. The Unsplash API restricts/obscures the full CC0 collection, which we believe to be about 200,000 images, but it isn&rsquo;t possible to access the complete archive. In order to ensure that the commons is maintained, we hope that Unsplash will either a) properly mark all the works shared using CC0 and/or b) make available a full archive of the CC0 works so they can be shared on a platform that supports open licensing and public domain tools. Previous platforms that have gone under or abandoned open license tools have shared their CC archives for this purpose. We hope Unsplash will follow the same path.</p></blockquote>



<p>Unsplash declined to identify these images at that time. When I asked Chesser if the company is willing to update their API to differentiate these works, he said they discovered the images were never CC0 to begin with because of Unsplash&rsquo;s terms: </p>



<blockquote class=\"wp-block-quote\"><p>The 2017 license clarification I described was also brought about because the team from Creative Commons told us that the photos were not licensed under CC0 if there were additional terms stipulated on the terms page. Therefore, the photos were not actually under CC0, as they had been submitted with additional terms attached to them and we could not and can not distribute the&nbsp;photos under the CC0 license. As part of this, we renamed the license to the Unsplash License and clarified the main parts of the terms in the form of the Unsplash License.</p></blockquote>



<p>The controversy over the license change struck a nerve with those who <a href=\"https://www.designernews.co/stories/84910-unsplash-images-are-no-longer-in-the-public-domain\">perceived the move to be unfair</a> to the community of creators who had been convinced to put their works in the public domain. Unsplash had become a household name on the backs of Creative Commons Zero licensing, with the images fetching more than <a href=\"https://medium.com/unsplash/unsplash-best-of-2017-eb36ee81236\">29 billion views in 2017</a>, only to abandon the license when it was no longer expedient for the growth of their community. </p>



<p>That body of work that had been originally shared to the public domain was then deftly hidden away (and remains so) with no differentiation in the site&rsquo;s API to identify these images. This is what Mullenweg seemed to be referencing when he <a href=\"https://wptavern.com/unsplash-launches-official-plugin-for-wordpress#comment-335431\">commented</a> on the plugin launch. </p>



<p>&ldquo;Encouraging hotlinking is also pretty suspicious, especially after the previous bait and switch,&rdquo; Mullenweg said. &ldquo;Maybe if there was a way again to find just the CC0 licensed images, which the Creative Commons also requested, this could be okay to promote.&rdquo;</p>



<p>Chesser contends that the Unsplash community had no complaints with the decision and that the only people who were dissatisfied were those who were not contributors.</p>



<p>&ldquo;For anyone who feels that we somehow &lsquo;tricked&rsquo; our community, again, I&rsquo;d point back to the reaction from our actual contributor community &mdash; the people who generously submit their images to Unsplash for others to create with,&rdquo; Chesser said. &ldquo;We heard no complaints from this community when we clarified the License in 2017. Had there been an issue,&nbsp;had we somehow been taking&nbsp;advantage of their contributions, we would have certainly heard about it then, as our community are very passionate and vocal. </p>



<p>&ldquo;The only complaints we heard were from people from outside of the Unsplash community &mdash; including Matt &mdash; who have never submitted an image to Unsplash and aren&rsquo;t part of our community. On the internet, there will always be people who disagree with you &mdash; we focus on our community and expanding the number of people who have access to create with images.&rdquo;</p>



<p>This particular licensing conflict seems to have inspired a bit of lasting apprehension regarding Unsplash&rsquo;s willingness to change its license and terms in the future. Allowing a plugin to efficiently pump out thousands of images to WordPress sites could potentially make the platform&rsquo;s user base a vector for disseminating works that someday may not be available with the same freedoms. </p>



<p>&ldquo;Could the terms or licensing of that hotlinking change in the future, as the licensing did in 2017?&rdquo; Mullenweg asked in the comments.</p>



<p>&ldquo;I forsee no future scenario where our terms will ever meaningfully change,&rdquo; Chesser said. &ldquo;They will of course occasionally be refined, as all terms are&mdash;like when we added clarifications around GDPR compliance or when we add new features that require a legal definition. But our mission and goal are the same as they have always been: to enable anyone to create with visuals, and our terms will continue to reflect that.&rdquo;</p>



<p>After a few in the WordPress community expressed that the license was not clear in terms of what users can do with the images, Chesser said he would be open to making a separate clarification document to address any legitimate concerns.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">The actual license has been ruled as very clear by a lot of lawyers and we want to avoid complicating it\'s simplicity with more legalese, but we\'re open to making a separate clarification/side-letter/legal document which addresses any legitimate concerns</p>&mdash; Luke Chesser (@lukechesser) <a href=\"https://twitter.com/lukechesser/status/1286446954197770244?ref_src=twsrc%5Etfw\">July 23, 2020</a></blockquote>
</div>



<p>When the 2017 licensing controversy happened, Richard Best, a technology and public lawyer based in New Zealand, said the new Unsplash license <a href=\"http://wpandlegalstuff.com/unsplash-gpl-compatibility-concern-red-herring/\">could use some clarification</a> regarding freedoms for downstream recipients. He suggested changes that rephrase it as follows: &ldquo;Unsplash grants&nbsp;<span>you and every person&nbsp;who comes into possession of the photos</span>&nbsp;a nonexclusive copyright license to&hellip;&rdquo;</p>



<p>&ldquo;These changes are intended to ensure that downstream recipients of the photos receive the same licence from Unsplash,&rdquo; Best said. &ldquo;Both the GPL and the Creative Commons licences are structured in this way. Without these changes, distributors of products like website themes may be concerned&nbsp;that the end users of their products will not receive the rights they need to use the photos for their own purposes.&rdquo;</p>



<p>Chesser said the&nbsp;Unsplash License and terms were created by the same legal team that created the Creative Commons licenses. Any major differences regarding the freedoms for downstream recipients were likely considered and intentional. It may still be an important clarification, as the block editor continues to make it easier for users to create and share their own designs with images. </p>



<h2>Unsplash Clarifies the Purpose of Hotlinking to the CDN and Tracking Views</h2>



<p>The official Unsplash plugin is different from other plugins created to connect users to the free image library in that it hotlinks images to the Unsplash CDN, ostensibly to reduce the site&rsquo;s bandwidth usage and speed up delivery.</p>



<p>&ldquo;The plugin uses the Unsplash CDN to serve Unsplash images while the plugin is installed and enabled,&rdquo; Chesser said. &ldquo;At the same time, every image used in a post will also be copied over to the local server and stored there. We store a copy of every image on the local WordPress install so that if the plugin is disabled or removed by the site owner, their posts can continue to serve the local images and don&rsquo;t break, however they lose the features of the Unsplash CDN.&rdquo;</p>



<p>The CDN also supports dynamic resizing, compression, cropping, automatic file format conversion, and a number of performance improvements that Chesser said the service has implemented based on what the team as learned from serving tens of billions of images every month for 8+ years.</p>



<p>&ldquo;When we talked to publishers, these features were extremely important to them,&rdquo; he said. &ldquo;Rather than try to rebuild the wheel in WordPress, we wanted to offer these features to publishers as they aren&rsquo;t supported natively by WordPress and are table stakes for modern image serving.&rdquo;</p>



<p>The Unsplash CDN exists to serve the needs of Buzzfeed, Trello, Adobe, Dropbox, Notion, and 2,200+ official <a href=\"https://unsplash.com/developers\">API integrations</a>. It also gives Unsplash contributors a better idea of the real number of views of the content they post.</p>



<p>&ldquo;This outsized distribution of their images is one of the main reasons that photographers post on Unsplash,&rdquo; Chesser said. &ldquo;A quick <a href=\"https://twitter.com/search?q=unsplash%20views&src=typed_query\">search on twitter</a> gives you a good idea for how important this phenomenon is to our contributors.&rdquo;</p>



<p>One commenter <a href=\"https://wptavern.com/unsplash-launches-official-plugin-for-wordpress#comment-335442\">said</a> that she was put off by the official plugin&rsquo;s requirement to authenticate, since competing plugins don&rsquo;t add this extra layer.</p>



<p>&ldquo;They can now force user sign ups to inflate their user base even though other plugins just serve images without any sort of authentication,&rdquo; she said. &ldquo;What is the point in a user authenticating to only receive an API key? It&rsquo;s not like you can access Likes or your collection with only the API key.</p>



<p>&ldquo;Serving images from their CDN also allows them to track image views and URLs which helps inflate the download and view counts for their contributors. These other plugins like Instant Images downloads the file to your media library which would only count as a single download. I&rsquo;m going to stick with Instant Images as I don&rsquo;t feel like feeding the advertising machine.&rdquo;</p>



<p>Responses to the plugin&rsquo;s approach were mixed, but overall it seemed that most users were delighted to cut a few steps out of their workflow for posting images to WordPress. The plugin has more than 300 downloads in 48 hours.</p>



<h2>Is Unsplash in Violation of the WordPress Plugin Directory&rsquo;s Guidelines?</h2>



<p>After Matt Mullenweg raised concerns about the plugin&rsquo;s suitability for the directory, commenters called in similar concerns about the Pexels library, which Automattic uses in Jetpack.</p>



<p>Unsplash does not appear to be in violation of the official WordPress.org plugin directory guidelines. Earlier this year when asked about a different plugin that imports an Unsplash image, Plugin Team member Samuel Otto Wood <a href=\"https://wordpress.slack.com/archives/C1LBM36LC/p1581854898429000\">responded</a> using an Unsplash-specific example: </p>



<blockquote class=\"wp-block-quote\"><p>Let&rsquo;s simplify this right down to basics: Lets say you made a plugin that imports images from Unsplash into your site. That plugin is fine. It has no images in it, the purpose of it is to access a library of images and allow you to pull them into your site. You have to take actions to pull in those images. That is perfectly acceptable for being hosted on&nbsp;<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"http://w.org/\">w.org</a>. So, you can&rsquo;t use Unsplash images in your plugin hosted here. But if it pulls them from somewhere else via user action and intention, fine.</p></blockquote>



<p>Chesser sees the concerns regarding the clarity of Unsplash&rsquo;s licensing as unwarranted, given Automattic&rsquo;s use of the Pexels library.</p>



<p>&ldquo;Pexels made a clone of the Unsplash License with the exact same restrictions shortly after we updated it in 2017,&rdquo; Chesser said. &ldquo;At no point has WordPress expressed any skepticism that the Pexels License is legally vague. Given that they have instead created multiple official partnerships with Pexels, including adding it to Jetpack, then I would expect that they consider the license to be legally clear.&rdquo;</p>



<p>Both Pexels and Unsplash licenses share similar restrictions but Pexels has more restrictions on how images can be used. Chesser believes the renewed concerns are entirely founded on Unsplash&rsquo;s controversial 2017 licensing change.</p>



<p>&ldquo;Before 2017, we had a strong relationship with WordPress,&rdquo; Chesser said. &ldquo;Since then, WordPress has essentially cut off all ties with Unsplash and instead made partnerships with Pexels to integrate into WordPress features. What&rsquo;s strange though is that shortly after we clarified our license in 2017, Pexels did the same thing, adding the same restrictions&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.pexels.com/terms-of-service/#restrictions-on-use-of-the-service-and-content:~:text=to%20portray%20any%20person%20depicted%20in,engaging%20in%20immoral%20or%20criminal%20activities%3B\" target=\"_blank\">plus a few additional ones</a>.</p>



<p>&ldquo;Specifically, you can see that they have the same restriction around&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.pexels.com/license/#flash-container:~:text=Don\'t%20sell%20unaltered%20copies%20of%20a,physical%20product%20without%20modifying%20it%20first.\" target=\"_blank\">reselling of content</a>&nbsp;and the&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.pexels.com/license/#flash-container:~:text=Don\'t%20redistribute%20or%20sell%20the%20photos%20and%20videos%20on%20other%20stock%20photo%20or%20wallpaper%20platforms.\" target=\"_blank\">same restriction around recompiling and scraping of the site</a>. (Note: they use the word redistribute on the license page, but&nbsp;<a rel=\"noreferrer noopener\" href=\"https://www.pexels.com/terms-of-service/#intellectual-property:~:text=the%20right%20to%20compile%20any%20Pexels%20Content%20to%20replicate%20a%20similar%20or%20competing%20Service%3B\" target=\"_blank\">use the word compile in their terms</a>.)&rdquo;</p>



<p><a href=\"https://xwp.co/\">XWP</a>, the agency that Unsplash partnered with to build the plugin, said the license is &ldquo;significantly less restrictive than Pexels, Youtube, Getty, Spotify and many other examples you&rsquo;ll find throughout the plugin directory.&rdquo; If this plugin is in violation, then many others would be called into question along with it.</p>



<p>&ldquo;As rule 6 on the <a rel=\"noreferrer noopener\" href=\"http://wordpress.org/\" target=\"_blank\">WordPress.org</a> plugin guidelines clearly state: &lsquo;Plugins that act as an interface to some external third party service (e.g. a video hosting site) are allowed, even for paid services,&rdquo; XWP CTO Derek Herman said.</p>



<p>&ldquo;As their high quality images are available as an API, we built a community plugin up to WordPress VIP coding standards so that Unsplash would work on a variety of use cases, from WordPress versions 4.9 to 5.4. Integration with APIs has been key to WordPress&rsquo; growth over the past few years.&rdquo;</p>



<p>Herman also cited several prominent examples of content integrations with varying licenses and terms that govern the content:</p>



<ul><li>A leading enterprise publishing plugin is <a href=\"https://wordpress.org/plugins/getty-images/\" target=\"_blank\" rel=\"noreferrer noopener\">Getty Images</a>, which is a <a href=\"https://wpvip.com/plugins/getty-images/\" target=\"_blank\" rel=\"noreferrer noopener\">WordPress VIP partner plugin</a> and has long been used by larger organizations. It primarily sells &ldquo;restricted-usage&rdquo; images connected to a network of media sources like newspapers and freelancers.</li><li><a href=\"https://wordpress.org/support/article/embeds/\" target=\"_blank\" rel=\"noreferrer noopener\">WordPress core has extensive oembed support for third parties</a>, which takes third-party URLs and parses them in a way to link to the site. While Amazon Kindle, Spotify and Youtube&rsquo;s content licensing rules are quite restrictive, the goal of these integrations are to encourage content creators to tell stories with what they find across the internet.</li><li>In its most recent release <a href=\"https://jetpack.com/2020/07/07/87-easier-reach-customers/\" target=\"_blank\" rel=\"noreferrer noopener\">Jetpack included two exciting new media integrations</a>&mdash;Google Photos and Pexels&mdash;which are certainly relevant here. Pexels actually has a &ldquo;<a href=\"https://help.pexels.com/hc/en-us/articles/360043229813-Can-I-use-photos-and-videos-from-Pexels-in-a-political-campaign-\" target=\"_blank\" rel=\"noreferrer noopener\">political views</a>&rdquo; clause in their license. As they do not define what is a &ldquo;political policy or viewpoint&rdquo; it could be viewed as too restrictive as nearly any post could be construed as being political.</li><li>There are a few other plugins using Unsplash in the WordPress ecosystem, such as <a href=\"https://wordpress.org/plugins/instant-images/\" target=\"_blank\" rel=\"noreferrer noopener\">Instant Images</a> (which has been in the directory for over three years). In fact, WordPress Release lead Riad Benguella wrote a great prototype plugin called &ldquo;<a href=\"https://wptavern.com/drop-it-plugin-brings-gifs-and-unsplash-photos-to-gutenberg\" target=\"_blank\" rel=\"noreferrer noopener\">Drop It</a>,&rdquo; which integrates with both GIPHY and Unsplash, and served as inspiration for us on this project.&nbsp;</li></ul>



<p>At the moment, it seems Unsplash is within WordPress.org&rsquo;s plugin directory guidelines, but if its terms and licensing are deemed incompatible, many media integrations in the plugin ecosystem will also be called into question. Users who object to Unsplash&rsquo;s method of delivery can always opt to use a plugin with a different approach. Those who want to support libraries that serve images with GPL-compatible licensing can check out the Theme Team&rsquo;s list of <a href=\"https://make.wordpress.org/themes/handbook/review/resources/#recommended-websites-for-images\">recommended sources</a> and look for plugins that integrate those.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 24 Jul 2020 17:24:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: Revised Block Directory Guidelines Proposal Updates Wording but Changes Little Else\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102315\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:231:\"https://wptavern.com/revised-block-directory-guidelines-proposal-updates-wording-but-changes-little-else?utm_source=rss&utm_medium=rss&utm_campaign=revised-block-directory-guidelines-proposal-updates-wording-but-changes-little-else\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6513:\"<p class=\"has-drop-cap\">Yesterday, Alex Shiels <a href=\"https://make.wordpress.org/plugins/2020/07/22/proposed-block-directory-guidelines/\">posted an update</a> to the <a href=\"https://github.com/WordPress/wporg-plugin-guidelines/pull/70/files#diff-bcf4c6e86251a8d088c6bd5800c476ff\">proposed guidelines</a> for the WordPress block directory. The document adds eight rules for plugin authors to follow if they plan to add their one-off blocks to the directory. The guidelines are additional requirements on top of the existing plugin directory guidelines.</p>



<p>While the wording and organization of the block guidelines received a revamp in comparison to the <a href=\"https://github.com/WordPress/wporg-plugin-guidelines/blob/87a9a17eca6d4b39a6bb4b1f2c8dcf33aff26336/blocks.md\">original proposal</a>, the overall sentiment is unchanged. Shiels thanks community developers for the feedback on the original guidelines but does not go into detail about the things that changed as a result.</p>



<p>The primary guidelines are mostly expected, run-of-the-mill requirements for blocks. Developers need a <code>block.json</code> file. They should name stuff appropriately. Plugins should contain only a single block. Plugins should only touch the block editor. Blocks should work seamlessly once activated.</p>



<p>The remaining guidelines are certain to be a disappointment or point of contention for some developers.</p>



<h2>Monetization Still Not Allowed</h2>



<p class=\"has-drop-cap\">The largest <a href=\"https://wptavern.com/can-the-block-directory-and-business-interests-coexist\">feedback on the guidelines</a> we received here at the Tavern surrounded what is essentially a blanket ban on commercial interests for block developers. Blocks still cannot hook into a paid service or advertise within the admin. This limitation will obviously turn away many businesses that may have been looking forward to the block directory as a potential avenue for profit. Right now, one-off blocks will need to be built by those with altruistic interests, giving back to the community simply out of the kindness of their hearts.</p>



<p>While there is nothing inherently wrong with wanting to do that, it is not attractive to developers who are primarily focused on putting food on the table. Hobbyists and larger businesses with the resources to give back will be well-suited to add blocks to the directory. However, it will give a lot of developers pause because it is unlikely a good return on investment. Instead, those developers are more likely to submit their blocks to the normal plugin directory with their normal upsell methods. This will only serve to make block discoverability harder for end-users.</p>



<p>This is a missed opportunity to build a well-rounded system that is fair to both users and developers who need to make a living. Whether it is through the plugin tag system or specific guidelines on monetization, we could have built something that made everyone a little happy and a little mad, a compromise that merged a good user interface and experience.</p>



<p>It is not like there have been no proposals. In January, Luke Carbis wrote a detailed outline of <a href=\"https://carb.is/2020/01/block-business/\">how WordPress could provide a middle ground</a> between sustainability (business models) and accessibility (free options) with the upcoming block directory. His fear was that the block directory would be full of blocks without updates in a few years because the completely free model is unsustainable. His proposal was a badge-based system that let users know if a block contained ads, used a freemium model, or required a sign-in to a third-party service.</p>



<p>The current guideline is not set in stone. This is the first version of the block directory. It is not out of the question that the team could change things as the directory grows over time.</p>



<h2>No Love for Server-Side Blocks</h2>



<p class=\"has-drop-cap\">The block directory guidelines are still heavily geared toward static blocks. PHP must be kept at a minimum and primarily be used to load any necessary scripts and stylesheets. Server-side blocks are not getting much attention at the moment, which may be a limitation of the software.</p>



<p>It would be great to see a way for some server-side blocks to be included in the block directory. For example, a breadcrumbs block would need to rely heavily on PHP to render its output. It is a dynamic block rather than static. This particular block would not be useful until full-site editing lands in WordPress, which is still several months away. However, I am getting the itch to turn an old breadcrumbs plugin of mine into a block. It would be neat to see it listed in the block directory.</p>



<p>There are countless other scenarios. Post lists, product grids, and data pulled from external APIs are all good use cases for one-off blocks.</p>



<h2>Dependencies Are Not Allowed</h2>



<p class=\"has-drop-cap\">Given the way that WordPress works, it makes sense to ban dependencies on other plugins for any particular block to function. This is an old limitation that is rearing its head again. Every other modern framework uses some sort of dependency management to address this problem.</p>



<p>The block directory has the potential to exacerbate the problem even further. Because plugins coming from this directory will be single blocks, it will often mean that developers are using the same bits of code across multiple projects. For example, an end-user may activate multiple block plugins that rely on the same JavaScript library. Because there is no 100%, sure-fire way to make sure only one instance of this library is loaded, users may be running multiple instances of it on their sites. It is not a new problem, but smaller block plugins mean that users are more likely to install more plugins. It increases the probability of running into this issue.</p>



<p>If there was any sort of basic dependency management for plugin authors to use in WordPress, it would solve a world of problems. Over the years, developers have created methods to minimize the issues stemming from the lack of such a system. However, nothing is foolproof without a standard to follow.</p>



<p>This has also held developers back from building libraries, scripts, and tools that could benefit the entire development community as a whole. Everyone builds their own things in-house, and the block directory is making a promise for more of the same.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2020 20:38:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"BuddyPress: BuddyPress 6.2.0 beta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=312990\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://buddypress.org/2020/07/buddypress-6-2-0-beta/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2350:\"<p>Hi BuddyPress contributors!</p>



<p>We will soon publish a maintenance release (<strong>6.2.0</strong>) to prepare BuddyPress to some changes that will introduce WordPress next major release (5.5.0). WordPress 5.5.0 is slated for August 11, and we&#8217;d love you to help us use the coming days to make sure your favorite community engine is ready to fully enjoy this new version of WordPress.</p>



<p>BuddyPress 6.2.0 will make sure our BP Email feature is using the 6.0 version of PHPMailer when WordPress 5.5.0 is installed on your site and will carry on using its version 5.2 when your WordPress version is lower (4.8 to 5.4 for the supported versions of our 6.0 branch). For more information about it, please have a look to this <a href=\"https://buddypress.trac.wordpress.org/ticket/8322\">ticket</a>.</p>



<p>If you&#8217;re a plugin or a theme developer and are extending our BP Email feature, we strongly advise you to test your code with the latest pre-release of WordPress 5.5.0 (eg: <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\">5.5.0-beta3</a>) and BuddyPress <a href=\"https://downloads.wordpress.org/plugin/buddypress.6.2.0-beta1.zip\">6.2.0-beta1</a>.</p>



<p>WordPress 5.5.0 will also <a href=\"https://make.wordpress.org/core/2020/06/29/updating-jquery-version-shipped-with-wordpress/\">remove the jQuery Migrate library</a>, as BuddyPress uses a lot jQuery, we&#8217;ve been checking the impact of this removal. We haven&#8217;t found any issue so far, but if you do, please warn us about it commenting this <a href=\"https://buddypress.trac.wordpress.org/ticket/8333\">ticket</a>.</p>



<p>A detailed changelog will be part of our official release notes, but, until then, you can check out this&nbsp;<a href=\"https://buddypress.trac.wordpress.org/query?status=closed&group=resolution&milestone=6.2.0\">report on Trac</a>&nbsp;for the full list of fixes.</p>



<p>You can test the <a href=\"https://downloads.wordpress.org/plugin/buddypress.6.2.0-beta1.zip\">6.2.0-beta1</a> pre-release in 2 ways :</p>



<ul><li>Use the <a href=\"https://wordpress.org/plugins/bp-beta-tester/\">BP Beta Tester</a> plugin.</li><li><a href=\"https://downloads.wordpress.org/plugin/buddypress.6.2.0-beta1.zip\">Download the 6.2.0 beta release here (zip file)</a>.</li></ul>



<p>Thanks in advance for your contributions.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2020 00:45:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Google Delays Mobile-First Indexing Deadline to March 2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102262\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:181:\"https://wptavern.com/google-delays-mobile-first-indexing-deadline-to-march-2021?utm_source=rss&utm_medium=rss&utm_campaign=google-delays-mobile-first-indexing-deadline-to-march-2021\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3509:\"<p>Google had set September 2020 as the deadline for when it would begin to fully switch over to crawling and indexing sites using mobile-first indexing but announced today that site owners will have more time to prepare. The deadline has been <a href=\"https://webmasters.googleblog.com/2020/07/prepare-for-mobile-first-indexing-with.html\">extended to March 2021</a>. </p>



<p>Mobile-first indexing is a long-term plan that Google began rolling out in July 2019 by enabling it for new domains. The company cited &ldquo;these uncertain times&rdquo; as the reason for delaying the next phase of the rollout. The announcement also referenced further testing that showed a number of common issues sites are having in making the transition. Google urged site owners to pay close attention to several important issues:</p>



<ul><li>Robots meta tags on mobile version should match the desktop version or Google may fail to index or follow links on the page.</li><li>Do not lazy-load primary content based on user interactions (like swiping, clicking, or typing), because the Googlebot doesn&rsquo;t trigger these user interactions.</li><li>Avoid the bad practice of using smaller images on mobile to fit the smaller screen. Small and low quality image will not be favorably indexed.</li><li>Ensure content on the mobile version matches the desktop, since only the mobile version will be used for indexing and ranking in Search. </li><li>Include meaningful alt text for images.</li></ul>



<p>Google also outlined several other tips for image and video markup and placement. The announcement is essentially a tutorial for how to improve common mistakes that can negatively impact mobile ranking and indexing.</p>



<p>Since mobile-first indexing is already enabled for most currently crawled sites, some speculated that the delayed deadline was due to hastily migrated mobile subdomain sites. John Mueller, Webmaster Trends Analyst at Google, confirmed this is the case and advised site owners to avoid this dated approach and update at the nearest opportunity.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">That\'s basically the inverse of how it was before, when desktop URLs were sometimes shown in mobile serps. Ideally, you\'d redirect by device type. M-dot sites do make things harder; for new sites I\'d avoid them, for older sites, I\'d fix with the next bigger revamp.</p>&mdash; &#127820; John &#127820; (@JohnMu) <a href=\"https://twitter.com/JohnMu/status/1285877309862563840?ref_src=twsrc%5Etfw\">July 22, 2020</a></blockquote>
</div>



<p>Before the advent of responsive design, many WordPress site owners added plugins that would create a separate mobile site to provide a more mobile-friendly browsing experience. Website visitors soon expected the entire web to be available to them on the devices they carried around in their pockets. This is now the primary way that people interact with the web, and Google&rsquo;s mobile-first indexing is a reflection of this new reality.</p>



<p>If your WordPress site is still relying on a plugin to create a separate mobile site, or if you are using a plugin for lazy loading, make sure that the solution you have in place is following  Google&rsquo;s <a href=\"https://developers.google.com/search/mobile-sites/mobile-first-indexing\">mobile-first indexing best practices</a>. There are still 9 months remaining before Google makes mobile-first indexing and ranking the default for the entire web.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2020 23:20:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Zero BS CRM Rebrands and Relaunches as Jetpack CRM\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102138\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:165:\"https://wptavern.com/zero-bs-crm-rebrands-and-relaunches-as-jetpack-crm?utm_source=rss&utm_medium=rss&utm_campaign=zero-bs-crm-rebrands-and-relaunches-as-jetpack-crm\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5649:\"<img />Jetpack CRM welcome screen.



<p class=\"has-drop-cap\">Mike Stott, co-creator of Zero BS CRM, <a href=\"https://jetpack.com/2020/07/20/introducing-jetpack-crm/\">announced the launch of Jetpack CRM</a> on Monday. The news was the seemingly inevitable rebranding of the original plugin that he and Woody Hayday had built. Automattic, the owner of the Jetpack plugin, acquired the project almost a year ago. While <a href=\"https://wordpress.org/plugins/zero-bs-crm/\">Jetpack CRM</a> carries the &ldquo;Jetpack&rdquo; name, it is still a standalone project and has a <a href=\"https://jetpackcrm.com/\">dedicated website</a>.</p>



<p>CRM stands for &ldquo;customer relationship management.&rdquo; Such systems allow businesses to manage relationships through an interface but can vary extensively in user experience. The goal is to manage contacts, sales, and productivity through the software.</p>



<p>The duo of Stott and Hayday have had a bit of a journey in the past year. In August 2019, <a href=\"https://wptavern.com/automattic-acquires-zero-bs-crm-considers-rebranding-it-as-jetpack-crm\">Automattic acquired the project</a> and provided the resources for the team to continue working on Zero BS CRM. The <a href=\"https://wptavern.com/zero-bs-crm-3-0-improves-ui-changes-database-structure-and-becomes-more-extendable\">3.0 launch</a> in December 2019 was a massive undertaking that included a major database change and UI improvements. Since then, they have worked toward rebranding the project. Stott also did this with a newborn in his family.</p>



<p>When version 3.0 of Zero BS CRM launched, Stott said they were still discussing whether to rebrand and bring the plugin under the Jetpack umbrella. They were gathering user feedback at the time, but his primary focus was on developing features. The name was not the foremost thing on his mind. However, branding can make or break even a good project, and Jetpack is as close to a household name as any product coming out of the WordPress ecosystem. It made sense to lean on that branding.</p>



<p>&ldquo;Jetpack&rsquo;s mission is to help entrepreneurs and small businesses succeed by providing tools that keep their sites fast and secure,&rdquo; said Stott. &ldquo;We felt that from within the Automattic family, this was a great match. We created ZBS CRM with the same end goal in mind &mdash; helping you succeed through better customer relationships, so it just made sense.&rdquo;</p>



<p>After nearly a year beyond the acquisition, Stott feels like things are going great within the new environment at Automattic. &ldquo;We&rsquo;ve found the right product fit within Automattic,&rdquo; he said. &ldquo;In Jetpack, we&rsquo;re happy that we can really push the CRM, and it&rsquo;s exciting to be part of the bigger WordPress family and being able to integrate with WooCommerce, etc.&rdquo;</p>



<p>Version 4.0 of the plugin primarily changes the branding in the admin and lightens the UI background. The team has also continued to add small changes.</p>



<p>&ldquo;Looking ahead, we&rsquo;re excited to continue developing the CRM following user feedback,&rdquo; said Stott. &ldquo;We&rsquo;ll be working on our roadmap and, of course, how we can best integrate with the Jetpack family.&rdquo;</p>



<h2>Growing and the Future</h2>



<p class=\"has-drop-cap\">Jetpack CRM currently has 3,000+ active installs. This is up from 2,000 since the launch of version 3.0 last December. It has been a slow road thus far. However, there is room for growth. The leading CRM plugin, Hubspot, has 100,000+ active installs. There should be plenty of room for competing plugins in the CRM market.</p>



<p>&ldquo;There&rsquo;s a massive opportunity for CRM in the WordPress space,&rdquo; said Stott. &ldquo;A CRM is not like installing an SEO plugin on every website you own &mdash; generally you&rsquo;d only have a single CRM for your business &mdash; but it&rsquo;s the core of your business. The fact that 3,000+ users and counting are choosing WordPress to run their CRM is a great start.&rdquo;</p>



<p>The Jetpack brand should help spur some of the growth, particularly if Automattic pushes it as an add-on within the primary Jetpack plugin.</p>



<p>&ldquo;[Jetpack] has substantial reach among website owners who would benefit from a CRM but may not know what a CRM is,&rdquo; said Stott. &ldquo;While we&rsquo;re happy that the plugin is still growing organically, we are just about set up to really push Jetpack CRM with full force.&rdquo;</p>



<p>Stott believes the Hubspot comparison isn&rsquo;t apples-to-apples. Unlike Jetpack CRM, the Hubspot plugin pushes users to an app that is hosted off-site.</p>



<p>&ldquo;While this makes sense for some users, it doesn&rsquo;t really take advantage of the huge benefits that native WordPress plugins offer,&rdquo; he said. &ldquo;Jetpack CRM sits on the user&rsquo;s servers. Users manage and control their own data &mdash; a huge win under the GDPR whereas a site owner you&rsquo;re legally required to know where your data is held. Not to mention that the plugin is also extendable.&rdquo;</p>



<p>Stott said he has always loved the WordPress community&rsquo;s open-source approach and the freedoms that it provides to build something custom or extend what is already there. There should be ample opportunity for developers to extend Jetpack CRM&rsquo;s codebase.</p>



<p>&ldquo;To my mind, there has never been a more exciting time for plugins like Jetpack CRM, which we envision as the &lsquo;business layer&rsquo; for modern entrepreneurs, much like WooCommerce has democratized eCommerce,&rdquo; he said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2020 19:21:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Unsplash Launches Official Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:159:\"https://wptavern.com/unsplash-launches-official-plugin-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=unsplash-launches-official-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6658:\"<p><a href=\"https://unsplash.com/\">Unsplash</a> has released its own <a href=\"https://wordpress.org/plugins/unsplash/\">official plugin for WordPress</a>, co-developed with the team at <a href=\"https://xwp.co/\">XWP</a>. The plugin seamlessly connects Unsplash&rsquo;s 1 million+ free high-resolution image library with the WordPress editor.</p>



<div class=\"wp-block-embed__wrapper\">
<a href=\"https://cloudup.com/cUQ5pBCD6jD\"><img src=\"https://cldup.com/3UUPV-2ayL.gif\" alt=\"Post usage 1\" width=\"1100\" height=\"612\" /></a>
</div>



<p>Users can easily search Unsplash directly inside the custom block and insert images with attribution and alt description info automatically filled in. The selected images are download and added to the WordPress media library, saving users the trouble of having to leave their dashboards to search, download, and upload images. </p>



<p>Unsplash co-founder Luke Chesser described the project as &ldquo;bringing the internet&rsquo;s image library to the internet&rsquo;s publishing platform.&rdquo; Although the plugin is useful for any type of website &ndash; from small blogs to businesses, it was large publishing organizations that provided the impetus for Unsplash to develop an official integration for WordPress.</p>



<p>&ldquo;We&rsquo;ve been working with a lot of publishers as they integrate Unsplash into their publishing flows to replace legacy solutions,&rdquo; Chesser said. &ldquo;With so many publishers being powered by WordPress, we saw a repeated need for a high quality integration that could be shared by all of the publishers. In order to best serve them, we needed to offer something that we could ensure met their needs both now and in the future.&rdquo;</p>



<p><a href=\"https://wordpress.org/plugins/instant-images/\">Instant Images</a>, a plugin that boasts one-click Unsplash uploads, is currently the largest competitor to the adoption of the official plugin with more than 50,000 active installs. Many other plugins have also added some form of Unsplash integration in the past. Chesser said his team has loved seeing the variety of applications developers have created with their API and they were hesitant to create their own plugin.</p>



<p>&ldquo;We saw a gap between the things big and small publishers were telling us, and the way the existing plugins had been developed,&rdquo; he said. &ldquo;Most existing plugins reupload the image to the WordPress library and then treat it as a standard image, which breaks a handful of things:</p>



<ul><li>Image attribution to the original photographer is usually lost (or is no longer supported past the first usage)</li><li>The time it takes for the server to download the image and then reupload it can be slow</li><li>Out of the box, WordPress&rsquo;s current support for dynamic image URLs that adapt to the device connection and screen size is limited and by using the&nbsp;Unsplash&nbsp;CDN, we could ensure that the right size image is served to better optimize for performance.&rdquo;</li></ul>



<p>When developing the official plugin, Unsplash and XWP took feedback from publishers and aimed to improve on how existing plugins handled images. After testing it, I found the search feature was fast and setup was a breeze. The plugin handles everything for the user invisibly in the background and its integration with the block editor makes it feel like a natural part of WordPress.</p>



<h2>Unsplash Aims to Increase Its Audience by Enhancing the Publishing Workflow for WordPress Publishers</h2>



<p>As Unsplash looks to define a new economic model around photography, WordPress-powered sites are a major consideration, since the platform powers <a href=\"https://w3techs.com/technologies/details/cm-wordpress\">more than 37%</a> of Alexa&rsquo;s&nbsp;top 10 million&nbsp;websites.</p>



<p>Seven years after it started as a Tumblr blog, Unsplash is moving to directly monetize the site by working with brands to create photos that will appear in search results. &ldquo;Unsplash for Brands&rdquo; launched in December 2019 as an answer to the question of how Unsplash will make money. Companies pay to have their branded images show up prominently in search results alongside other organically ranking images that match users&rsquo; queries. </p>



<p>&ldquo;While they serve completely different purposes, I think a lot of brands are growing tired of the state of digital advertising today, with Facebook and Google having a host of problems around privacy, targeting, and negative consequences for culture,&rdquo; Chesser said. &ldquo;Unsplash&nbsp;allows brands to influence the visual mindshare of the internet while having an authentic and positive impact on their audience.&rdquo;&nbsp;</p>



<p>Launching an official WordPress plugin is a strategic move for Unsplash as it puts those branded images in front of a larger audience with users searching directly within the editor. Although the company continues to push out new features to the&nbsp;Unsplash&nbsp;API, many publishers did not have the resources to create their own integrations.</p>



<p>&ldquo;After so many conversations with publishers, both big and small, that want to integrate the&nbsp;Unsplash&nbsp;library but can&rsquo;t due to resources, we felt that we needed to offer something more ready to use than the raw API or SDKs,&rdquo; Chesser said.</p>



<p>&ldquo;We built the current version of the&nbsp;Unsplash&nbsp;for WordPress plugin so that it meets those needs of publishers now, but we know that we can push it a lot further in the future.&rdquo; </p>



<p>The first iteration of the plugin mirrors the flow and features that a user would have while navigating unsplash.com, while keeping the writer inside the editor. Now that Unsplash is integrated into the WordPress publishing flow, Chesser sees the opportunity to add more interesting features. Open sourcing the plugin also has the potential to increase Unsplash&rsquo;s audience as developers extend its core features for use in other plugins.</p>



<p>&ldquo;Using the context of the post, we can help suggest images or prefill a search using natural language processing,&rdquo; Chesser said. &ldquo;We can link together&nbsp;Unsplash&nbsp;images with other WordPress tools to help publishers edit and process images directly in their posts. And with a lot of the work from the plugin being focused on making&nbsp;Unsplash&nbsp;images work natively inside of the WordPress Media Library, we can even open-source the core in such a way that developers can extend and reuse the functionality, avoiding duplication across all of our third party WordPress plugins.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2020 23:33:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Why Accessibility Matters for WordPress Themes and Their Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102133\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/why-accessibility-matters-for-wordpress-themes-and-their-users?utm_source=rss&utm_medium=rss&utm_campaign=why-accessibility-matters-for-wordpress-themes-and-their-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13307:\"<p>&ldquo;Do you ever read the subtitles on a video so you didn&rsquo;t need to unmute it?&rdquo; asked William Patton, a representative from the WordPress Themes Team. &ldquo;Used the &lsquo;beep&rsquo; from a crosswalk to know when to cross the road? Found yourself reading the info panel at an airport? Those things are considered features, but in reality, they are aids for people with additional needs.&rdquo;</p>



<p>As I talked with Patton and other reps from the Themes Team, it was clear they believed accessibility was a vital piece of the theme-building puzzle. The team has made small moves in the last year to bring more themes up to standards. However, it has been a slow-going process.</p>



<p>Last July, the <a href=\"https://wptavern.com/wordpress-theme-review-team-initiates-new-long-term-plan-to-make-all-wordpress-org-themes-accessible\">team initiated a plan</a> to add a new guideline every two months or so that would address a single accessibility issue. It would become every theme author&rsquo;s responsibility to make sure they were meeting the new guidelines. It would be every reviewer&rsquo;s responsibility to understand how to test guidelines as they were implemented. Thus far, the team has required only that themes have a working skip-to-content link and keyboard-capable navigation menus.</p>



<p>Not every theme author was excited about the move. Some have still shown resistance a year later.</p>



<p>Last week, we covered the Astra theme&rsquo;s news of hitting 1 million active installs. A <a href=\"https://wptavern.com/astra-becomes-the-only-non-default-wordpress-theme-with-1-million-installs#comment-335038\">commenter made a point</a> that the data shows that end-users do not care about accessibility &mdash; the Astra theme makes no mention of being accessibility-ready. The conclusion was that the Themes Team should not be implementing such guidelines based on the success of one of the directory&rsquo;s most popular themes.</p>



<p>While there are several things we could do to pick apart the original comment and the limited view of the situation, we can instead use it as a catalyst to discuss why accessibility is something that should be at the forefront of every theme author&rsquo;s mind. Patton, along with Themes Team representatives Carolina Nymark and Denis &#381;oljom, had a lot to say on the subject.</p>



<p>The overarching theme was that awareness is vital and that theme developers play a crucial role in making the web more accessible.</p>



<h2>Awareness Is Key</h2>



<img />



<p>&#381;oljom likened the awareness of accessibility to that of a cisgender person looking at the world from the perspective of a transgender person. Once he became aware of larger issues, he made sure to address gender-specific pronouns in his code comments, such as replacing instances of &ldquo;he&rdquo; with &ldquo;they.&rdquo; He hopes such small changes spark similar changes from others.</p>



<p>He said the situation was the same with accessibility. &ldquo;It might not mean much to a person who doesn&rsquo;t have any disabilities, but putting yourself in somebody else&rsquo;s shoes changes one&rsquo;s perspective. This is why we started to include things like skip links, keyboard nav, etc.&rdquo;</p>



<p>The team does not hope theme authors will merely become technically proficient at addressing accessibility issues in their themes. While that would be a help from a review standpoint, it addresses only the symptoms rather than root causes of the issues. Instead, by making more developers aware, they will begin to look at development from multiple perspectives. They will ask how a screen-readers will handle their theme. They will ask whether their colors have enough contrast for low-vision users to read. They will wonder if non-mouse users can navigate their users&rsquo; sites.</p>



<p>The technical stuff is the easy part. Changing perspectives and becoming more empathetic toward those who are different is much more difficult. But not impossible.</p>



<p>&ldquo;A lot of us who build for the web are lacking some basic insights into what it is like to have additional needs beyond what is our own normal,&rdquo; said Patton. &ldquo;There is a saying: &lsquo;if you could see it through my eyes, you would see it differently.&rsquo; If you could see through the eyes of someone with color blindness or impaired vision, you quite literally would see things differently.&rdquo;</p>



<p>The trouble with humans, in general, is that it can sometimes be hard to see things through someone else&rsquo;s eyes. Of course, there are tools to simulate accessibility issues for developers, so that helps. However, these tools do not replicate what it is like to walk through life with a particular impairment or disability. Some of us can only partially glimpse the difficulties that others may have when navigating the web. This does not mean that we cannot address the downfalls of the software we build and become more inclusive to all people, especially if we are proactive when issues are raised.</p>



<p>Nymark identified a few areas where the community can improve awareness:</p>



<ul><li>Make sure that all contributors are aware of the WordPress accessibility requirements so that all new features are accessible.</li><li>Highlight accessibility improvements when WordPress is updated.</li><li>Feature more diverse use cases and highlight areas where the accessibility that is built into WordPress has helped people share and access important content.</li></ul>



<p>&ldquo;The themes team hopes that by making theme authors aware of accessibility issues, authors will learn that even small changes to their code and design can have a great positive impact,&rdquo; she said.</p>



<h2>Is Accessibility Important to End-Users?</h2>



<img />



<p>Certainly, accessibility is important for <em>some</em> users. It certainly mattered to Guillermo Robles, a blind man who sued pizza chain Domino&rsquo;s in 2016 for an inaccessible website. The court case was important enough that it moved through the system all the way to the U.S. Supreme Court. Ultimately, the <a href=\"https://wptavern.com/u-s-supreme-court-denies-dominos-appeal-to-determine-whether-websites-must-be-accessible\">higher court denied Domino&rsquo;s appeal</a> of an earlier ruling. The U.S. 9th Circuit court had previously ruled that business websites fall under Title III of the American with Disabilities Act (ADA) and must meet accessibility standards.</p>



<p>This was a landmark case in the U.S. for accessibility advocates last October. It is also worth remembering as we near the upcoming 30th anniversary of the ADA on July 26.</p>



<p>Domino&rsquo;s is a billion-dollar business. The company has enough money to fight such battles for years. They also have the money to hire world-class web developers to correct any accessibility issues.</p>



<p>However, for small business owners, hiring a single developer, much less an entire agency or team, is often a non-starter. Many small businesses are fortunate to break even. WordPress and its ecosystem of free or low-cost solutions have democratized eCommerce on a scale previously unwitnessed. It means that mom-and-pop stores can have an online presence. It means teens can begin selling their custom art and a multitude of others can make money online without the backing of wads of cash.</p>



<p>For these small business owners, many are unaware of accessibility concerns. They pick up a few plugins and find a theme that suitably matches their branding. The possibility of an impending accessibility-related lawsuit is the furthest thing from their mind. This is a major reason that WordPress needs to be a leader in meeting accessibility standards. Themes, which are the part of the site that visitors will interact with, are possibly the most important part of that equation.</p>



<p>Some would argue that small business owners should understand the laws of their jurisdiction. That is true. However, it is also partly the responsibility of the software creators, says the Theme Team representatives.</p>



<p>&ldquo;Yes, the technology should account for additional needs,&rdquo; said Patton. &ldquo;Yes, the tooling should enable people to make good choices with regards to this. Yes, it should be easy to meet a minimum level of accessibility in the things we create with ease. Yes, it should be a fair assumption that the choices available to pick from are accessible.&rdquo;</p>



<p>The web is inherently accessible out of the box. Raw HTML is read and output by web browsers in such a way that the content can be accessed by anyone. Patton says that it is the things that developers do from that point forward that makes that experience better or worse.</p>



<p>&ldquo;Trade-offs are made that are well-intentioned but not always helpful,&rdquo; he said. &ldquo;Design trade-offs are the easiest to point out. Taking text and embedding it into an image means that some of its value is lost in exchange for it looking pretty. Using closely matching colors for text and background might create an interesting effect to some people but for others, it makes it impossible to read. Sometimes it&rsquo;s about balancing those trade-offs with the needs of others, but it is those kinds of trade-offs that most people struggle to give up.&rdquo;</p>



<p>Nymark described some more technical issues that the average end-user should expect to simply be a non-issue. For example, it is reasonable to assume that a theme installed from the official WordPress directory would be free from HTML, PHP, and JavaScript errors. These are items that users should not have to worry about checking before activating the theme on their site. The errors should simply not exist.</p>



<p>It is that level of quality control that end-users should expect in terms of accessibility, an assurance that the theme does all the things it is supposed to do. It is not about whether end-users &ldquo;care&rdquo; about accessibility.</p>



<p>&ldquo;If a form on a shop checkout page is not working, this can lead to loss of income,&rdquo; she said. &ldquo;Users rely on the technical solution provided by plugins and themes and expect everyone to be able to use their shop. Whether or not the site owner recognizes this as an accessibility issue is irrelevant because their page just needs to work.&rdquo;</p>



<h2>Why Theme Authors Should Care</h2>



<img />



<p>&ldquo;If those who choose themes don&rsquo;t consider accessibility and the theme author did not consider it, then the [visitors] of the sites built with those themes are the ones that lose out,&rdquo; said Patton. &ldquo;It&rsquo;s not a huge leap to realize that low accessibility on your site directly equates to a reduction of potential users.&rdquo;</p>



<p>He said that end-users would naturally assume the themes they are picking from do not have accessibility issues. However, that assumption is typically far from accurate.</p>



<p>&ldquo;Theme authors should care about the accessibility of their creations so that the people picking their themes don&rsquo;t need to use it as a deciding factor,&rdquo; he said.</p>



<p>My go-to response is that developers should concern themselves with accessibility because it is for the collective good. Humans should care about making sure that all other humans have the same freedoms that they enjoy, which are often take for granted.</p>



<p>Even those who cannot view it from that perspective should be able to appreciate that it is a smart business decision. It makes little sense to leave money on the table, especially if you are a developer who is selling a theme or upselling additional features on top of a free theme. There is an entire segment of users that represents money lost.</p>



<p>Additionally, more and more countries are implementing laws around web accessibility. Over time, such laws will be commonplace, particularly in the business sector. Inaccessible themes will lose users as such laws are enforced. Now is a good time to get ahead of impending change.</p>



<h2>More Guidelines Ahead</h2>



<p>The WordPress Themes Team has been slow about adopting additional guidelines surrounding accessibility. However, more are expected to land at some point. Team reps want to work with authors and reviewers alike to make the transition as painless as possible.</p>



<p>&ldquo;We have not added anything else because theme authors are still not releasing themes with working implementations of skip links and usable keyboard navigation,&rdquo; said Patton. &ldquo;When those two things become habitual, it will be time to introduce another aspect as a requirement.&rdquo;</p>



<p>The next guideline in line is expected to be underlined links in the post content. This would be an easy win if the team can get past the current stage. Right now, the team reps are unsure when that will happen.</p>



<p>&ldquo;The fact that this has taken so long for authors to get this right probably indicates that we need to do better at guiding them to resources to learn how to do it and why it is important,&rdquo; said Patton. &ldquo;Perhaps that is a better avenue to pursue than looking to implement additional asks of them.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2020 19:48:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.5 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8706\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3830:\"<p>WordPress 5.5 Beta 3 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong>This software is still in development,</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 Beta 3 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.5-beta3.zip\">download the beta here</a> (zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on <a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors who tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\">beta 2</a> development release and gave feedback. Testing for bugs is a critical part of polishing every release and a great way to contribute to WordPress. </p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-2/\">beta 2</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=07%2F15%2F2020..07%2F21%2F2020&milestone=5.5&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">43 bugs</a> have been fixed. Here are a few changes in beta 3:</p>



<ul><li>Plugin and theme versions are now shared in the emails when automatically updated (see <a href=\"https://core.trac.wordpress.org/ticket/50350\">#50350</a>).</li><li>REST API routes without a <code>permission_callback</code> now trigger a <code>_doing_it_wrong()</code> warning (see <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://core.trac.wordpress.org/ticket/50075\">#50075</a>).</li><li>Over 23 Gutenberg changes and updates (see <a href=\"https://github.com/WordPress/gutenberg/pull/24068\">#24068</a> and <a href=\"https://core.trac.wordpress.org/ticket/50712\">#50712</a>).</li><li>A bug with the new import and export database Dashicons has been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li></ul>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> and pay special attention to the <a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a> for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>, where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2020 17:51:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: WordPress 5.5 to Remove Hulu from List of Supported oEmbed Providers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102148\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:201:\"https://wptavern.com/wordpress-5-5-to-remove-hulu-from-list-of-supported-oembed-providers?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-5-5-to-remove-hulu-from-list-of-supported-oembed-providers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2311:\"<p>WordPress 5.5 will be dropping Hulu oEmbed support after Hulu silently disabled its oEmbed API. This is the API that allows users to copy and paste a link into the editor and have it automatically embed the content, as opposed to copying a chunk of embed code. Documentation contributors <a href=\"https://github.com/WordPress/gutenberg/issues/23920\">discovered that it wasn&rsquo;t working</a> while attempting to document the Hulu Embed block.</p>



<p>Birgit Pauli-Haack confirmed with Hulu that embedding is not currently an option. Hulu support did not elaborate on why it was removed.<a href=\"https://wptavern.com/wp-admin/edit.php?post_type=post\"></a></p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Apologies for any disappointment! This isn\'t an available option at the moment, but we\'ll express your interest. If there\'s anything else we can help out with down the road, please don\'t hesitate to reach back out!</p>&mdash; Hulu Support (@hulu_support) <a href=\"https://twitter.com/hulu_support/status/1283562756726300672?ref_src=twsrc%5Etfw\">July 16, 2020</a></blockquote>
</div>



<p>The block currently displays an error when attempting to embed a Hulu link, stating &ldquo;Sorry, this content could not be embedded.&rdquo; As a result, WordPress contributors have <a href=\"https://core.trac.wordpress.org/changeset/48512\">removed</a> both the block from the editor and the provider from core. </p>



<p>WordPress has included Hulu <a href=\"https://wordpress.org/support/article/embeds/#okay-so-what-sites-can-i-embed-from\">oEmbed support</a> for the past 11 years, since it was first added in <a href=\"https://wordpress.org/support/wordpress-version/version-2-9/\">WordPress 2.9</a> (December 2009). Services are <a href=\"https://wordpress.org/support/article/embeds/#okay-so-what-sites-can-i-embed-from\">logged</a> on WordPress.org as they are added or removed. Hulu was removed as soon as it was discovered that oEmbed support no longer worked, similar to other <a href=\"https://core.trac.wordpress.org/ticket/45399\">previously unsupported providers</a> &ndash; most recently FunnyOrDie and Photobucket. This is a major loss of convenience for users who are trying to embed Hulu links but it lies outside of WordPress&rsquo; control. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 20 Jul 2020 22:48:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Theme Authors Can Pass Data to Template Files in WordPress 5.5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/theme-authors-can-pass-data-to-template-files-in-wordpress-5-5?utm_source=rss&utm_medium=rss&utm_campaign=theme-authors-can-pass-data-to-template-files-in-wordpress-5-5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4777:\"<p class=\"has-drop-cap\">Theme developers can finally rejoice. For the first time, it is now possible to pass data to templates via the various core template-loading functions. Enrico Sorcinelli <a href=\"https://make.wordpress.org/core/2020/07/17/passing-arguments-to-template-files-in-wordpress-5-5/\">announced the change</a> on the Make Core blog this past Friday.</p>



<p>The <a href=\"https://core.trac.wordpress.org/ticket/21676\">feature was originally proposed</a> by Scott Kingsley Clark in 2012. Over the years, the ticket has received a dozen patches. It has survived a closure and arguments over why the feature should not go into core. Sorcinelli was a primary driver that kept the ticket alive for the last few years.</p>



<p>WordPress developers have been cleaning up some old-but-useful feature requests for the 5.5 release cycle. A couple of weeks ago, an 11-year-old ticket to allow users to <a href=\"https://wptavern.com/after-11-years-users-will-be-able-to-update-themes-and-plugins-via-a-zip-file\">update themes and plugins via a ZIP file</a> made the cut. Core developers even closed a 9-year-old ticket related to an <a href=\"https://core.trac.wordpress.org/ticket/17232\">Internet Explorer 6 hack</a> &mdash; <em>progress</em>. However, for theme authors, one of the most important additions is control over passing data from one template to another.</p>



<p>Typically, in PHP, variables can be passed from file to file because they remain in the same scope. However, that is not the case if the inclusion of the file is taken out of that scope by including the file from inside of a function. The scope is then limited to the function. That is how the template system works in WordPress. This is not necessarily a bad thing. However, it has meant that theme developers have had no built-in method of passing data from one template to the next.</p>



<p>Imagine creating a variable in one template but needing to access that same variable in a sub-template. There is no shortage of methods to accomplish this, but many are inelegant.</p>



<p>&ldquo;For years, theme developers wishing to pass data to template files have had to use less than ideal workarounds,&rdquo; wrote Sorcinelli in the announcement. The worst solutions typically involved creating a global variable. Others created custom template-loading functions on top of WordPress&rsquo;s existing system. The problem with all methods, regardless of which was ideal, was that no standard existed. Each theme would need to build its own solution, and plugins that touched the front end would often have a competing solution.</p>



<p>All of the WordPress template-loading functions now support an additional parameter of <code>$args</code>, which allows theme authors to pass along an associative array of data to the loaded template. The functions that support this new parameter are:</p>



<ul><li><code>get_header()</code></li><li><code>get_footer()</code></li><li><code>get_sidebar()</code></li><li><code>get_template_part()</code></li><li><code>locate_template()</code></li><li><code>load_template()</code></li></ul>



<p>Any hooks associated with the functions also pass along the data.</p>



<p>The <code>get_search_form()</code> function has supported a similar parameter since WordPress 5.2. In practice, it should work mostly the same, but the function has a couple of default values it sets.</p>



<p>An additional benefit of having a standard method of passing data to templates is that the feature can be built upon in the future. For example, WordPress could eventually offer a hook for filtering the data, which could come in handy with child themes.</p>



<p>The WordPress template system still lacks the robustness of more modern frameworks, but this simple change will allow for a variety of applications.</p>



<p>One question remains: <em>is the arrival of this feature too late?</em> With WordPress on track to revamp the entire theme system to integrate with the upcoming full-site editing feature, will this feature be useful for only the next few months?</p>



<p>Even if most theme developers don&rsquo;t immediately jump on board the block-based themes bandwagon for another year, the feature could come in handy  until they do. Perhaps it will also have some usefulness beyond the current theming paradigm.</p>



<p>Developers still do not have a clear picture of what theming with blocks will look like in the next few years. There may be situations where passing dynamic data is still necessary in the next system. Even if not, it will likely be a long while before there is mass adoption of block-based themes from the existing theme development community. In the meantime, many will be able to drop in-house solutions and use standard functions.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 20 Jul 2020 19:44:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Corner Office Interview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=51861\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://ma.tt/2020/07/corner-office-interview/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2488:\"<p>If you pick up a print edition of the Sunday New York Times today you&#8217;ll see <a href=\"https://www.nytimes.com/2020/07/12/business/matt-mullenweg-automattic-corner-office.html\">the Corner Office interview with David Gelles in the business section</a>. </p>



<img />(Hat tip to <a href=\"http://www.maryconrad.org/\">Mary Conrad</a> for the picture, I haven&#8217;t seen it in person yet.)



<p>A quote that seems to be resonating with people,</p>



<blockquote class=\"wp-block-quote\"><p>This column is called Corner Office, and most people who choose to have offices are usually the bosses. And I’ve been to the offices of billionaire C.E.O.s that have their own private bathroom, beautiful art and couches. But these are all things that you can have in your house. What I love about distributed organizations is every single employee can have a corner office.</p></blockquote>



<p>Sometimes my corner office has been the corner of an airport floor next to a power outlet! I&#8217;ve also heard from colleagues that feel like their office feels like an unsupervised day care center since the quarantine started. The point I want to make is there&#8217;s a world of possibility that opens up when you move from the finite space of a shared office, and all the politics of dividing up the scarce resource of desirable space, to the <a href=\"https://www.amazon.com/Finite-Infinite-Games-James-Carse/dp/1476731713\">infinite game</a> where people can define their own &#8220;office&#8221; as the place where they will be most productive, and do so however they like with no penalties or restraints.</p>



<p>If you had the best space in the legacy office, you probably liked it and may even have had motivated reasoning around ineffable things that happened in the office like &#8220;culture&#8221; that would be impossible without it, but the average experience of an entry-level worker was not as positive. Now there can be a much more even playing field. At <a href=\"https://automattic.com/\">Automattic</a> we have a home office allowance people can use to buy equipment they need to make their home work area comfortable and productive, and it&#8217;s the same if you&#8217;re leading a team of hundreds or if it&#8217;s your first job.</p>



<p>If you&#8217;d like to hear the entire conversation <a href=\"https://www.youtube.com/watch?v=fFg6YcBB2uI&feature=youtu.be\">they&#8217;ve posted the original audio and interview</a> that was distilled into the print version.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 19 Jul 2020 21:13:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: All in One SEO Pack Plugin Patches XSS Vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102036\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:169:\"https://wptavern.com/all-in-one-seo-pack-plugin-patches-xss-vulnerability?utm_source=rss&utm_medium=rss&utm_campaign=all-in-one-seo-pack-plugin-patches-xss-vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1843:\"<p><a href=\"https://wordpress.org/plugins/all-in-one-seo-pack\">All in One SEO Pack</a> patched an XSS vulnerability this week that was <a href=\"https://www.wordfence.com/blog/2020/07/2-million-users-affected-by-vulnerability-in-all-in-one-seo-pack/\">discovered</a> by the security researchers at Wordfence on July 10. The popular plugin has more than 2 million active installs, according to WordPress.org.</p>



<p>Wordfence researchers categorized it as &ldquo;a medium severity security issue&rdquo; that could result in &ldquo;a complete site takeover and other severe consequences:&rdquo;</p>



<blockquote class=\"wp-block-quote\"><p>This flaw allowed authenticated users with contributor level access or above the ability to inject malicious scripts that would be executed if a victim accessed the wp-admin panel&rsquo;s &lsquo;all posts&rsquo; page.</p></blockquote>



<p>Version 3.6.2, released on July 15, 2020, includes the following update in the changelog: &ldquo;Improved the output of SEO meta fields + added additional sanitization for security hardening.&rdquo;</p>



<p>All in One SEO Pack users are strongly recommended to update to the latest version. At the time of publishing, just 12% of the plugin&rsquo;s user base is running versions 3.6.x, which includes the three most recent versions. This leaves more than 1.7 million installations (88% of the plugin&rsquo;s users) vulnerable. </p>



<p>Many users don&rsquo;t log into their WordPress sites often enough to learn about security updates in a timely fashion. Plugin authors often don&rsquo;t advertise the importance of the update on their websites or social media. This is the type of situation that WordPress 5.5 should help to mitigate, as it introduces admin controls in the dashboard that allow users to enable automatic updates for themes and plugins. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Jul 2020 21:48:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"WPTavern: WPCampus Online 2020 Conference Features Accessibility and Higher Education Topics, July 29-30\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=102003\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:251:\"https://wptavern.com/wpcampus-online-2020-conference-features-accessibility-and-higher-education-topics-july-29-30?utm_source=rss&utm_medium=rss&utm_campaign=wpcampus-online-2020-conference-features-accessibility-and-higher-education-topics-july-29-30\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4948:\"<p><a href=\"https://www.wpcampus.org/\">WPCampus</a>, a community focused on WordPress and higher education, will host its 5th annual in-person conference as a free, <a href=\"https://2020.wpcampus.org/\">online event</a> this year.  The two-day event will feature sessions, lightning talks, sponsor demonstrations, and trivia, July 29-30, 2020. </p>



<p>Although the WPCampus community is no stranger to hosting online events (they usually host a virtual conference in January), current events have forced educational institutions to rely more heavily on those who maintain their digital infrastructure. Many WPCampus members fall into this category and are operating under a great deal more stress as compared to previous years. The community has more than 1,116 members representing 688 institutions.</p>



<p>&ldquo;In higher ed, &lsquo;wearer of many hats&rsquo; is a common saying,&rdquo; WPCampus director Rachel Cherry said. &ldquo;Per usual, most who work in our space are already going above and beyond to cover numerous job roles. For example, I was always a team of one: I designed the site, programmed the site, performed QA, and managed content editors. With the pandemic forcing many universities to increase their online presence, higher ed web professionals are busier than ever, working to help with the transition while bearing the stress of lowered budgets, working from home, and whether or not their physical campus will open for the fall semester.&rdquo; </p>



<p>As many institutions are moving to make their courses available online, Cherry said ensuring that vital resources are accessible has become even more critical.</p>



<p>&ldquo;The pandemic forced a vast majority of our society&rsquo;s processes and interactions to go online, and it&rsquo;s shining a spotlight on how inaccessible a lot of our systems are,&rdquo; she said. &ldquo;For example, online event platforms became a necessity for conferences. But the vast majority of these platforms are inaccessible. Crowdcast, for instance, is nearly impossible to use if you can&rsquo;t use a mouse. Using inaccessible online platforms for your event is no different from denying attendee access at the door because the building doesn&rsquo;t have a wheelchair ramp.&rdquo;</p>



<p><a href=\"https://2020.wpcampus.org/\">WPCampus Online 2020</a> will include a selection of sessions from accessibility experts on topics such as justifying the budget for accessibility initiatives, accessibility for non-developers, Gutenberg accessibility, end-to-end accessibility testing, and mobile site and native app accessibility testing guidelines. If you are looking to deepen your knowledge of accessibility, this conference features more sessions on this topic than most WordCamps.</p>



<p>The event&rsquo;s <a href=\"https://2020.wpcampus.org/speakers/\">schedule</a> also includes other topics of interest to those in higher education with sessions on managing multiple WordPress sites, building a self-publishing platform, extending the WP REST API, automation tools, data visualization for WordPress, and improving website performance.</p>



<p>In lieu of giving away swag for the event, WPCampus is coordinating a fundraising effort for the Black Lives Matter movement and those struggling with COVID-19. The organization will <a href=\"https://2020.wpcampus.org/donate/\">match donations</a> to the following organizations: </p>



<ul id=\"input_10_4\"><li>Black Lives Matter</li><li>The American Civil Liberties Union (ACLU)</li><li>NAACP Legal Defense Fund</li><li>Black Girls Code</li><li>Feeding America</li></ul>



<p>Cherry reports that more than 350 people have registered so far and she anticipates 500-600 attendees online this year. WPCampus will stream the session videos on YouTube and they will be recorded and available after the event. <a href=\"https://2020.wpcampus.org/register/\">Registration</a> is free, thanks the the event&rsquo;s sponsors, which include many WordPress agencies, hosts, and contributing individuals.</p>



<p>Despite the disappointment at not being able to meet in-person in New Orleans this year, Cherry said she is grateful for the &ldquo;more in-depth than usual&rdquo; time the community will have to spend together during the virtual conference. WPCampus members have found camaraderie and encouragement in their community by sharing stories and asking each other for help during this profoundly challenging time. </p>



<p>&ldquo;We&rsquo;ve become a family,&rdquo; Cherry said. &ldquo;And not just with higher ed and other web professionals, but with the vendors that support us and want to invest in our growth. Because of our events and community, we were able to sponsor the Gutenberg accessibility audit and play a huge role in improving the accessibility of the WordPress platform. I am incredibly proud of the ever-increasing focus, education, and advocacy our community has placed on accessibility.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Jul 2020 20:44:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Should WordPress Themes Add a Top-Level Admin Menu Item?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101807\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:175:\"https://wptavern.com/should-wordpress-themes-add-a-top-level-admin-menu-item?utm_source=rss&utm_medium=rss&utm_campaign=should-wordpress-themes-add-a-top-level-admin-menu-item\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7349:\"<p class=\"has-drop-cap\">WordPress has almost always provided a top-level admin menu item for themes. It is clearly labeled &ldquo;Appearance.&rdquo; It is the single location that all WordPress users know to visit to modify any appearance-related things for their WordPress site. However, there is a movement within the Themes Team to allow themes to <a href=\"https://make.wordpress.org/themes/2020/07/13/proposal-allow-themes-to-add-a-top-level-admin-menu/\">place an additional top-level menu link</a> in the admin. The big question: <em>should this idea move forward?</em></p>



<p>When the Themes Team (originally called the Theme Review Team) was formed, its members created a set of guidelines that would be shaped and reshaped over the years. They were a set of living guidelines that could always be changed with the times.</p>



<p>One of the oldest guidelines required that themes must place any custom admin pages under the Appearance menu item. It made sense. WordPress provided a standard location for any theme-related pages. The custom header and background features lived under Appearance. Widgets, also defined by the current theme, were housed as a sub-page. Eventually, WordPress&rsquo;s custom nav menu system came along and was &mdash; you guessed it &mdash; situated under Appearance. The core developers even put the customizer link in the same place.</p>



<p>For over a decade, there was a well-defined standard. Sure, commercial themes outside of the official directory would sometimes break the mold. However, themes from the directory followed the pattern.</p>



<p>Now, the Themes Team is proposing that themes should be able to break from tradition.</p>



<p>The discussion arose after a question of whether themes should be able to add a custom panel to the block editor sidebar, which is not allowed.</p>



<p>&ldquo;To keep the editor free from clutter, advertising and upsell, with the customizer being used less, and no dashboard widgets being allowed, can we give theme authors a better place to include their information, and limit upsell to that area?&rdquo; wrote Carolina Nymark in <a href=\"https://make.wordpress.org/themes/2020/07/10/meeting-notes-tuesday-7th-of-july-2020/\">last week&rsquo;s team meeting notes</a>.</p>



<p>The proposal seems to settle on the idea that themes will lose visibility as WordPress moves toward full-site editing and the customizer becomes less important. The customizer is not an ideal place for anything but theme options, but that notion seems to have been overlooked in the discussion. Nevertheless, the original guideline that disallowed themes from creating top-level menu items preceded the advent of the customizer by several years. Advertising, documentation, plugin recommendations, and similar pages were always allowed under the existing Appearance menu. The usefulness of the customizer was never a necessary part of that conversation.</p>



<p>Ultimately, the question should be about what is best for users. There is no data to support making the change or sticking with the status quo. However, we do have a standard that has existed for years.</p>



<h2>The Proposed Guidelines</h2>



<p class=\"has-drop-cap\">The proposal would create several new guidelines for theme authors to follow and reviewers to check, assuming the theme created a top-level admin menu item:</p>



<ul><li>No admin menu priority may be used.</li><li>No UI or color changes are allowed for the menu item.</li><li>The title must be kept short and not include spam.</li><li>No more than three sub-pages.</li><li>Child themes are limited to one sub-page or can remove the parent&rsquo;s pages and add its own.</li></ul>



<p>Some of these make sense and follow along with existing guidelines, such as not spamming or changing the admin UI. However, others could be problematic.</p>



<p>If moving forward with the proposal, setting a menu item priority should be required rather than not allowed. If anything, it would make sense to require a specific priority to place the custom menu item immediately after the existing Appearance item. This would at least group them together by default. If changing the place where users are accustomed to seeing theme-related pages, it is probably best not to break too far from the standard location.</p>



<p><em>No more than three sub-pages?</em> Surely there will be a theme with a top-level admin menu item that needs four sub-pages at some point. If giving theme authors the freedom to take up valuable real estate in the admin, a limit of three sub-pages seems like a rule to fix the mistake of allowing the top-level item in the first place. It is an arbitrary number at best. There would be no reason to cap it once making the guideline change. It also adds one more item that the team will need to police.</p>



<p>The limitation of sub-pages for child themes seems just as arbitrary.  No such limitation exists when placing sub-pages under the standard Appearance screen.</p>



<p>The entire proposal is little more than extra work on a team that is already strained for resources.</p>



<p>Instead of the simple rule that has existed for years, the proposal adds a new rule with several sub-rules. If the team desires the extra work, I suppose this point doesn&rsquo;t matter.</p>



<h2>The Elephant in the Room</h2>



<p class=\"has-drop-cap\">There is one aspect of this discussion that everyone knows about but few are willing to broach. Underneath all the guidelines from the Themes Team and whether most theme authors support a particular decision is how this affects the financial bottom line. When we talk about <em>visibility</em> of a theme&rsquo;s admin pages, we are primarily talking about providing another avenue for commercial upsells.</p>



<p>Some of this discussion on visibility is shrouded in concepts such as surfacing end-user documentation or adding a visible <em>readme</em> for the user&rsquo;s benefit. These are legitimate concerns, especially when theme developers have watched <a href=\"https://meta.trac.wordpress.org/ticket/215\">tickets to address such downfalls</a> seemingly dwindle into obscurity over the years. Whether a top-level admin menu item makes sense for exposing theme documentation might be worth discussing, but there is no world in which this would be the primary use case.</p>



<p>The topic of visibility rests on the idea of upselling the pro version of the theme, add-ons, or other services.</p>



<p>Far too many plugins already go overboard, creating a billboard of the WordPress admin. One of the things users could almost be assured of is that themes from the official directory were constrained enough that they were not the hot mess that plugins have become as of late. However, that could all change.</p>



<p>Do we really want an extra top-level admin menu item that will be, for all intents and purposes, to advertise?</p>



<p>Maybe it doesn&rsquo;t matter in the end. Users are so accustomed to the clutter produced by the dozens of plugins on their sites. One more may not matter at this point.</p>



<p>Or, should we be having a different conversation altogether? If this ultimately boils down to advertising, are there ways we can open this up for theme authors while still creating a user experience that keeps the WordPress admin free of clutter?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Jul 2020 20:03:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Astra Becomes the Only Non-Default WordPress Theme With 1 Million Installs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101924\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:213:\"https://wptavern.com/astra-becomes-the-only-non-default-wordpress-theme-with-1-million-installs?utm_source=rss&utm_medium=rss&utm_campaign=astra-becomes-the-only-non-default-wordpress-theme-with-1-million-installs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5336:\"<p class=\"has-drop-cap\">On Tuesday, Brainstorm Force announced its Astra theme <a href=\"https://wpastra.com/one-million-active-installs/\">passed 1 million active installations</a>. It is the only non-default theme in the official WordPress theme directory to reach such a height.</p>



<p>Popularity breeds popularity. Once the theme broke 50,000 installs in January 2019, it was a quick hop and skip to 500,000 in October and 1 million less than a year later. With the winds of momentum at its back, the theme may become an unstoppable force. It is anyone&rsquo;s guess when growth will begin to plateau.</p>



<p>&ldquo;We recognize that this is not an ordinary feat,&rdquo; wrote Sujay Pawar in the announcement post. He said the team has no plans of resting at this point. &ldquo;1 million is just a milestone in our journey.&rdquo;</p>



<p>Many WordPress plugins have long ago passed the million-install milestone. Several have multi-millions. However, this is a much tougher feat for themes. One of the limiting factors is that users can only activate one of them at a time. There is no limit when it comes to plugins, and users often have dozens running at once. One million active installs is a level of popularity that is almost unheard of in the theming world.</p>



<p>&ldquo;There is a huge gap between Astra and all others,&rdquo; said William Patton, a WordPress Themes Team representative. &ldquo;Hitting 1 million is pretty astounding honestly.&rdquo;</p>



<p>This is not simply a major milestone for the Astra theme. It is huge for WordPress. For a third-party theme creator to reach a number that only the default themes can boast is the sort of thing we should all rejoice in a bit. It is a testament to how much WordPress has grown over the years.</p>



<p>Aside from the default themes that ship with WordPress, there are currently five themes with more than 100,000 active installs:</p>



<ul><li><a href=\"https://wordpress.org/themes/astra/\">Astra</a> &ndash; 1 million</li><li><a href=\"https://wordpress.org/themes/oceanwp/\">OceanWP</a> &ndash; 600,000</li><li><a href=\"https://wordpress.org/themes/generatepress/\">GeneratePress</a> &ndash; 300,000</li><li><a href=\"https://wordpress.org/themes/hello-elementor/\">Hello Elementor</a> &ndash; 300,000</li><li><a href=\"https://wordpress.org/themes/storefront/\">Storefront</a> &ndash; 200,000</li></ul>



<p>Once that first theme passes the 1 million mark, it is only a matter of time before others start breaking the barrier. OceanWP has the shortest striking distance and could be next. However, Hello Elementor is moving fast and earned its install count in a year and a half.</p>



<p>Regardless of the next theme to hit the milestone, this is one of those moments we should look back on in a few years to see how far we have come. Perhaps 1 million active installs will merely be a stepping stone to even greater heights for large numbers of themes.</p>



<h2>What Makes Astra Special?</h2>



<img />



<p class=\"has-drop-cap\">The default Astra theme is not anything particularly revolutionary on the surface. Out of the box, users are given a nearly blank canvas. It seems little more than your run-of-the-mill WordPress theme that would not garner much attention. However, it has one of the easiest setup processes that I have ever experienced with any theme. At the click of a button, end-users can pick from a plethora of starter templates.</p>



<p>There are hundreds of starter templates for Elementor and Beaver Builder. The Brizy page builder gets a little love too. There is even a modest 20 starter templates for Gutenberg. The theme&rsquo;s block editor styling leaves a lot to be desired, but I would wager that Brainstorm Force is serving a primary audience of Elementor users. The team probably won&rsquo;t have a huge incentive to change that anytime soon. And, there is really no need to. Elementor <a href=\"https://elementor.com/blog/5-million-active-installs/\">passed 5 million active installs</a> in May and is showing no signs of slowing down. Smart theme development businesses are making sure they support the plugin. Elementor support is where the money is right now.</p>



<p>Astra&rsquo;s starter templates are not merely templates. The theme will install and activate plugins needed too.</p>



<p>Many of the templates are free, but some are available for purchase. The theme allows users to filter the search between free and &ldquo;agency&rdquo; templates, so there is no trickery going on as is often the case with similar themes from the directory. They clearly label any upsells in the admin. At a time when the WordPress Themes Team struggles with theme authors circumventing advertising guidelines, Astra seems to be hitting a sweet spot that is both user-friendly and within the directory rules.</p>



<p>While good marketing and business plans go a long way toward getting installation numbers up, you cannot keep those numbers without building a product that users will continue using. Its simple import process makes it an easy go-to choice for anyone who doesn&rsquo;t relish the idea of spending hours trying to make their site look like the demo.</p>



<p>The theme&rsquo;s users can probably best answer the question of Astra&rsquo;s popularity.  Brainstorm Force is clearly doing something right.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2020 19:38:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Blocksy Theme Adds New Charity Starter Site, Pro Version to Launch in 2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101884\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/blocksy-theme-adds-new-charity-starter-site-pro-version-to-launch-in-2020?utm_source=rss&utm_medium=rss&utm_campaign=blocksy-theme-adds-new-charity-starter-site-pro-version-to-launch-in-2020\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4087:\"<p><a href=\"https://wordpress.org/themes/blocksy/\">Blocksy</a> is one of the best free themes available for the block editor right now and is rapidly growing in popularity. CreativeThemes, the Romania-based company behind the theme, released an update to Blocksy this week, along with a new starter site for charities. </p>



<p>The concept of &ldquo;starter sites&rdquo; is an interesting new twist on &ldquo;starter templates,&rdquo; which essentially allow users to import the content from a demo. Theme makers for products like <a href=\"https://creativethemes.com/blocksy/\">Blocksy</a>, <a href=\"https://wpastra.com/\">Astra</a>, and <a href=\"https://github.com/godaddy-wordpress/go\">Go</a> use this approach to help users implement different types of websites by importing the content from a pre-built demo site. The demos use the same base theme but vary widely in how they are customized. </p>



<p>Blocksy&rsquo;s starter sites are a one-click XML demo import that automatically brings in the pages, images, and theme options. This puts all the blocks in the right place so the user needs only to customize the demo, instead of trying to find the right settings to match the demo.</p>



<p>The new <a href=\"https://demo.creativethemes.com/blocksy/charity/\">Charity starter site</a> is built with the <a href=\"https://wordpress.org/plugins/stackable-ultimate-gutenberg-blocks/\">Stackable</a> plugin&rsquo;s page builder blocks. It joins four other <a href=\"https://creativethemes.com/blocksy/starter-sites/\">free starter sites</a> designed specifically for blogs, apps, travel, and e-commerce. The design can be imported under the Blocksy menu in the WordPress admin.</p>



<div class=\"wp-block-image\"><img /></div>



<p>According to the theme&rsquo;s beautifully designed and user friendly <a href=\"https://creativethemes.com/blocksy/changelog/\">changelog</a>, Blocksy can now automatically detect Custom Post Types and add their appropriate options. The update also adds a sizing option for related posts thumbnails, a new Twitch social icon, and improves compatibility with WooCommerce product display and miscellaneous extensions.</p>



<h2>Blocksy Pro Version Coming Soon </h2>



<p>When we first <a href=\"https://wptavern.com/blocksy-wordpress-theme-provides-a-solid-block-editor-experience\">reviewed</a> the theme in January 2020, it had 1,000 active installs and 58 five-star reviews. Over the past six months, the theme&rsquo;s user base has grown to more than 4,000 active installs and a perfect five-star rating on WordPress.org from 191 reviewers. It is currently maintained by a team of two &ndash; Sergiu Radu and Andrei Glingeanu.</p>



<p>Blocksy&rsquo;s creators have been working on custom projects and random jobs to support the time they spend developing the theme but they plan to launch a pro version as early as this summer.</p>



<p>&ldquo;We plan to add more features in the premium version, more demos, and also offer better and faster support,&rdquo; Radu said. &ldquo;I hope after we release the premium version we will be able to take on a few more people in our team to help us, at least with support so we can concentrate better on development.&rdquo;</p>



<p>Radu said the pro version will include some premium starter sites as well as additional functionality for the base theme.  They are aiming to include the following features in the first release:</p>



<ul><li>Multiple conditional headers</li><li>Multiple conditional footers</li><li>Multiple conditional sidebars</li><li>More header elements</li><li>More footer elements</li><li>White labeling</li><li>Custom fonts extension</li><li>Adobe Typekit extension</li><li>Hooks (conditional)</li><li>Sticky header</li></ul>



<p>In a second round of updates for the pro version, Blocksy creators plan to include features like custom color palettes, AMP, LearnDash, and EDD integrations, along with extensions for ads, mega menus, and portfolios. In the meantime, Radu says they do not plan to add more features to the free version &ndash; only improvements and new starter sites. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2020 22:32:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Eye-Catching Typography and Personality: Blossom Themes Launches Sarada Lite\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101933\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://wptavern.com/eye-catching-typography-and-personality-blossom-themes-launches-sarada-lite?utm_source=rss&utm_medium=rss&utm_campaign=eye-catching-typography-and-personality-blossom-themes-launches-sarada-lite\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6064:\"<img />Sarada Lite homepage.



<p class=\"has-drop-cap\">Blossom Themes launched <a href=\"https://wordpress.org/themes/sarada-lite/\">Sarada Lite</a>, its 25th theme, on the WordPress theme directory today. The theme is billed as a &ldquo;feminine blog theme&rdquo; specifically for professional bloggers. However, it would work well in a variety of contexts. While it is targeted at fashion, travel, and lifestyle bloggers, it is well-rounded enough for anyone who wants a touch of personality as part of their blogging experience.</p>



<p>I nearly passed over this theme. It had no mention of the block editor or Gutenberg in its description. It was not tagged in the directory as having editor styles (technically, it doesn&rsquo;t have them). There are few themes that I give much attention to if they do not style the latest features and blocks in WordPress. It has to be truly eye-catching otherwise. Sarada Lite is a breathtaking design, so it drew me in. It is the sort of theme that inspires me to write. Plus, its light color scheme along with the author&rsquo;s choice of images in the demo fit perfectly into the summer season. It simply makes me want to sit on the beach with a mojito and my laptop ready to spin up some great content.</p>



<p>What makes this theme stand out is its typography. The status quo with most free themes in the WordPress theme directory is to simply not give any attention to things like font size, characters per line, line height, or vertical rhythm. Long-form content is practically unreadable with such themes. However, long-winded writers need not be fearful of the reader losing interest because of the design. Sarada Lite creates an inviting atmosphere that beckons the visitor to actually read.</p>



<p>The theme supports several plugins, most of which are a part of the Blossom Themes collection. They are unnecessary for a solid blogging experience with this theme. Users should shy away from taking advantage of every bell and whistle the theme or its add-ons provide. The default setup is mostly where the theme shines.</p>



<p>Users who need a shop can also enjoy WooCommerce integration. The theme does not add much in the way of shop-related features, opting to style the default output of the eCommerce plugin instead.</p>



<h2>Design Elements Worth Noting</h2>



<img />Single post view.



<p class=\"has-drop-cap\">When testing and reviewing themes, it is often easy to get lost in the features. However, with Sarada Lite, it&rsquo;s not the theme features that are important. They may even be a detriment to the theme (more on that later). The thing that makes this theme special is the small design elements. The author puts a unique spin on things that give the theme a personality of its own. Designers who want to show off their design chops often go overboard, but Sarada Lite has just enough flair to draw attention to important elements without getting in the way of the content.</p>



<p>In particular, the theme&rsquo;s use of the <a href=\"https://fonts.google.com/specimen/Caveat\">Caveat font</a> gives secondary text just the right amount of pop. It is not a font that lends itself well to long-form content. However, the theme makes use of it for links, captions, quote citations, and a few other elements.</p>



<img />Sarada Lite&rsquo;s blockquote design.



<p>The theme offers various layouts with and without a sidebar. For single posts, I recommend dropping the sidebar and choosing the full-width centered layout to make full use of the block editor&rsquo;s capabilities. This gives enough breathing room for users who like to make liberal use of wide and full-width blocks. The theme has an option to change the layout globally and on a per-post basis.</p>



<h2>Issues</h2>



<p class=\"has-drop-cap\">One of the biggest issues with Sarada Lite is that users do not get a one-to-one match between the editor and the front end. The missing piece is the theme&rsquo;s beautiful typography. It is nowhere to be found while writing a post. The theme&rsquo;s admin-side CSS is bare-bones to the point where there is little use in loading the stylesheet. I hope this is merely something the theme author skipped for version 1.0 with a firm plan to add it in the next release. At worst, it is an extra couple of hours of work that offers a huge benefit to theme users.</p>



<p>The other major downside of Sarada Lite is that it tries to do too much. Its customizer options feel a bit overboard and disorganized. In too many cases, I was left wondering what a particular option was for or searching around for specific options in odd places.</p>



<p>I also found the Instagram feed (available via the Blossom Themes Social Feed add-on) in the header to be a horrendous addition, ruining what is an otherwise open and inviting design. Fortunately, this is an optional feature. Once again, the theme is doing too much here. I understand it is a bullet point on the ol&rsquo; marketing sheet, but it is an eyesore in practice. The Instagram feed works much better in the footer. My advice for theme users: avoid putting this in your header at all costs. Your site visitors should not need to skip over social media images just to get to your content.</p>



<p>As gracefully as the various sliders on the theme&rsquo;s homepage are done, I am now and always anti-slider. They offer no real benefit to the reader and often hide away content that would have otherwise been seen. The theme&rsquo;s slider sections, some of which are optional, are relatively low-key. I have seen far worse, but I would rather not see them at all.</p>



<p>Despite the theme&rsquo;s issues, they are not so detrimental that I wouldn&rsquo;t recommend the theme. Assuming the theme author adds in editor styles that match the front end, the other issues can mostly be avoided by user choice. The theme works well without tinkering with its options and adding extra plugins.</p>



<p>Sarada Lite is best without all the extras. What the user does with the theme will make or break the experience.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2020 20:56:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"HeroPress: Second Chances: How A Trip Back  Into The WordPress Community Saved My Life\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3229\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:220:\"https://heropress.com/essays/second-chances-how-a-trip-back-into-the-wordpress-community-saved-my-life/#utm_source=rss&utm_medium=rss&utm_campaign=second-chances-how-a-trip-back-into-the-wordpress-community-saved-my-life\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7043:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2021/07/071320-min.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: The energies received in return for giving back to the WordPress community healed me emotionally, allowing me to contribute creatively.\" /><p>Often, we refuse change and don&#8217;t get a second opportunity to make things right. But for me, June 17, 2017, changed my life forever. A life-threatening heart event forced me to start over and in the short time since WordPress helped me rediscover myself and to do the things I truly love.</p>
<p>At 10 am that morning, I was laid out flat on a cold, hard operating table being poked, prodded, and prepped for a surgical procedure. According to my doctors, this procedure was the only sure way to find out what had been plaguing me for five long years. Within the next sixty minutes, if things go sideways, I could be dead.</p>
<p>As I slowly came to, words floated through a lifting fog of anesthesia. &#8220;You had two 100% blocked arteries,&#8221; my cardiologist said. A flood of concern and questions seemed to flow freely foremost, &#8220;what will happen to me?&#8221;</p>
<h3>Two Paths Lead to WordPress</h3>
<p>Looking back, my WordPress journey has two paths, pre- or post-heart event. When the lead developer and CSS goddess left our public transit agency almost 10 years ago, they left behind a company news blog with the Headway theme. That year we were fortunate to have room in our budget allowing me to attend the WordPress VIP Intensive Developer Workshop in Napa.</p>
<p>At that time my experience was entirely in basic static HTML as a web designer so imagine how lost and out of place I felt being asked to &#8220;spin up a virtual box&#8221; midway through the first day. Surrounded by the best and the brightest distributed Automatticians from around the world, person after person answered my questions or assisted in any way they could. That day I learned what the phrase WordCamp Community really meant.</p>
<h3>Leaving the Past Behind</h3>
<p>What if you got a do-over? A mulligan, a reset button? Imagine being totally free from the stressors of the daily grind, similar to being a young child, with nothing to do but play all day.</p>
<p>Staring at the ceiling from my bed while recovering, I decided to stop the world and get off. I took a leave of absence from work beginning September 11. Looking deep within, I searched to rediscover me and the loves of my life &#8211; giving selflessly to others, picking up a pencil to sketch, storytelling, and WORDPRESS.</p>
<p>Every day for the next ninety days, I resolved to do only the things reconnected me with things dormant in my past that brought me joy:</p>
<ul>
<li>Each morning I&#8217;d pick up a pencil, sketch;</li>
<li>I&#8217;d exercise and practice mindfulness; and</li>
<li>No day would be complete without giving back, doing something with WordPress for others. Like an Agile process, I&#8217;d loop through these tasks, reassess, then repeat, each morning becoming stronger than the previous.</li>
</ul>
<p>Slowly, progress was being made in my recovery. From feeling faint and unable to walk from my bedside to my bathroom; 100 steps turned into 100 yards then one lap at my local park. I set a goal to climb to one of the highest points in our area, the top of Central Park.</p>
<h3>The Journey of 4,890 Miles Begins with One Step</h3>
<p>My second path into WordPress started later that summer. Untethered, I walked into my first-ever official WordPress Meetup in a coworking space located downtown Los Angeles, apprehensive, unsure what to expect. That evening a wonderful speaker on SEO followed the organizers from WordCamp Los Angeles calling for volunteers and I immediately raised my hand. The old me would not have.</p>
<p>From that point through December, I attended almost twenty (20) WordPress Meetups, attended four WordCamps (Grand Rapids, Los Angeles, Riverside, and United States via Livestream) logging almost 5,000 miles in the process. Rebuilding a website for a printing company pro bono while rehabilitating my heart and body. The energies received in return for giving back to the WordPress Community healed me emotionally, allowing me to contribute creatively &#8212; I loved it and wanted to do even more!</p>
<h3>Making a List, Checking It Twice</h3>
<p>Tired of driving home very late nights from area Meetups from all points around SoCal, I decided to start a meetup locally. On January 26, 2018, at 7:30 pm, I reached the last slide of my first presentation at our official WordPress Santa Clarita Valley Meetup. It read, &#8220;host the first annual WordCamp Santa Clarita&#8221;.</p>
<p>The faces in the audience &#8211; Tom, Steve, Matt, and others new to WordPress all looked at me skeptically, seeing someone full of dreams, spouting enthusiasm. But one thing was clear to me &#8212; WordPress had given me a shot at reclaiming something laid dormant and anything seemed possible.</p>
<p>Sixteen (16) months later, the first WordCamp north of Los Angeles and south of Sacramento since 2014 debuted in Santa Clarita. A small, but an incredible team of volunteers bought into my enthusiasm turned around and gave back to our attendees in our WordPress Community.</p>
<h3>Speak On It</h3>
<p>In my pre-heart event life, I began public speaking in a formal setting completing over 40 presentations but had stepped off the stage years earlier in a company club. Back in 2014 while walking through the break room at WordCamp Los Angeles one of the lead organizers handed me a mic and asked me to speak. Afterward, he said, &#8220;you should present at a WordCamp.&#8221;</p>
<p>Four years later, I stood on stage at WordCamp Chicago sharing my WordPress journey and hoping to inspire others to never give up on going after your dreams. Until that weekend in Chicago, I hadn&#8217;t seen any African-American men onstage and felt it important to encourage diversity through my message of rebirth.</p>
<blockquote><p><i>&#8220;Live as if you were to die tomorrow. Learn as if you were to live forever.&#8221; </i></p>
<p><i>Mahatma Gandhi</i></p></blockquote>
<p>I&#8217;ve met the most incredible group of nurturing, giving, and talented people stretching back to Sara (Rosso) in Napa through Angela (Jin) or David (Bisset) on the WordCamp US team. Every time I needed confidence or a word of encouragement Cami (Kaos), Kathy (Drewien), Brandon (Dove), or someone in the Community was that steadying hand on my shoulder.</p>
<p>I think about these words often as inspiration, waking each morning to greet the sunrise full of ideas and promise. How can I give back? What can I do with WordPress today?</p>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/second-chances-how-a-trip-back-into-the-wordpress-community-saved-my-life/\">Second Chances: How A Trip Back  Into The WordPress Community Saved My Life</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2020 11:00:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Joe Simpson Jr.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WordCamp Europe Goes Virtual for 2021, In-Person Conference to Resume 2022\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101866\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/wordcamp-europe-goes-virtual-for-2021-in-person-conference-to-resume-2022?utm_source=rss&utm_medium=rss&utm_campaign=wordcamp-europe-goes-virtual-for-2021-in-person-conference-to-resume-2022\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7807:\"<p>While much of the world is currently suspended in the uncertainty caused by the pandemic, WordCamp Europe delivered a surprisingly decisive <a href=\"https://europe.wordcamp.org/2021/wordcamp-europe-2021-will-be-online/\">announcement</a> today regarding the status of the 2021 event in Porto. Organizers moved to make it a virtual conference, 10 months in advance of the planned dates, June 3-5, 2021:</p>



<blockquote class=\"wp-block-quote\"><p>After careful consideration, and following guidance from WordCamp Central, we have agreed to hold WCEU 2021 online.</p><p>Although it was a difficult decision, it also seems the right thing to do. Considering the continuing uncertainty regarding COVID-19, we are hesitant to draw so many individuals from so many different places into one physical space.</p><p>We understand that this decision will come as a disappointment to many. We know that this event is a much-needed social outlet for many in our community and that an online event isn&rsquo;t quite the same as a physical event. We&rsquo;re so sad to not be able to greet you all in person in Porto in June.</p></blockquote>



<p>The announcement cited several positive aspects of going virtual, including eliminating the uncertainty for attendees and their travel arrangements, allowing for a larger global audience without the expense and risk, and having more time for creating a better online experience. The 2020 event had just three months to convert to a virtual conference but was able to reach more than 8,000 attendees.</p>



<p>In the absence of a vaccine ready for mass distribution or any proven commercially available therapeutics specifically designed to target the virus, it is impossible for organizers to nail down a safe timeline for a multinational event in 2021. Hugh Lashbrooke, who is assisting the WCEU organizing team as a mentor from WordCamp Central, identified risk mitigation as one of the primary factors in their decision.</p>



<p>&ldquo;Attendee safety is a primary concern in WordCamp organizing,&rdquo; Lashbrooke said. &ldquo;While the pandemic is progressing differently in different regions of the world, it seems that large in-person events that bring together thousands of people from multiple countries in a single shared space are still a risky proposition &mdash; and it&rsquo;s not clear when this will be safe again.&rdquo; </p>



<p>WordCampers <a href=\"https://twitter.com/WCEurope/status/1283017418261049346\">reacting to the news</a> today seemed to understand the need for such a disruptive change, but most expressed deep disappointment. </p>



<p>&ldquo;I&rsquo;m sure the decision won&rsquo;t have been taken lightly,&rdquo; Simon Dickson said. &ldquo;But WCEU is so important in terms of defining and sustaining the European &ndash; and indeed, global &ndash; WordPress community. With all due respect to online alternatives, two blank years will hit community spirit hard.&rdquo;</p>



<p>The goal for WordCamp Europe is to resume the in-person event in 2022 and organizers have booked the Super Bock Arena (Pavilh&atilde;o Rosa Mota) for June 2 &ndash; June 4, 2022.&nbsp;</p>



<p>If WCEU can resume normal operations in 2022, it will be the first time in three years that the European WordPress community has had the opportunity to gather in-person in one place. One disappointed attendee <a href=\"https://twitter.com/7strel/status/1283102522270507008\">said</a>, &ldquo;Understandable. As we say in Portugal: &Agrave; terceira ser&aacute; de vez! At&eacute; 2022,&rdquo; which roughly translates to the English saying, &ldquo;Third time&rsquo;s a charm.&rdquo;</p>



<h2>WordPress Community Team Is Working Towards Facilitating More Effective Events</h2>



<p>Lashbrooke said adjusting to emerging world events has been hard on all WordCamp organizing teams this year, as well as sponsors, speakers, and attendees. WordCamp Asia was forced to cancel, WordCamp US has gone virtual, and many other smaller camps have gone online or been postponed. The WordPress Community team is <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/\">discussing how they can improve online events</a> to provide a better experience for the community. Some of the broader ideas for creating more effective events include the following:</p>



<ul><li>Decouple online events from geography</li><li>Encourage events and workshops defined by topics, languages, etc.</li><li>Explore shorter, &ldquo;snack-sized&rdquo; online events</li><li>Experiment with the frequency of events</li></ul>



<p>A peripheral <a href=\"https://twitter.com/learnwithmattc/status/1282723205728227330\">discussion</a> regarding sponsors is happening on Twitter, after recent online WordCamps failed to deliver a positive experience of virtual sponsor booths.</p>



<p>&ldquo;If you want to offer sponsors a &lsquo;Virtual Booth&rsquo; as a benefit of sponsorship, you&rsquo;re going to have to do something during the main event to make that attractive and easy for attendees to attend &mdash; otherwise it&rsquo;s not a sponsor benefit,&rdquo; Matt Cromwell said.</p>



<p>&ldquo;If attendees have to log off the regular WordCamp platform, then go find some other link to some other virtual platform the experience becomes arduous and full of friction for the attendee making it highly unlikely they&rsquo;ll attend. WordCamps that are switching to virtual should look into more robust platforms like <a href=\"https://hopin.to/\">Hopin</a> which allow for various rooms that are consolidated to the same platform for attendees.&rdquo;</p>



<p>WordCamp Europe 2020 organizer Bernhard Kau said his team looked into using Hopin but found it wasn&rsquo;t fully accessible.</p>



<p>&ldquo;Hopin looked promising at first, not only for sponsors, but also for networking between attendees,&rdquo; Kau said. &ldquo;But it lacks basic accessibility. It&rsquo;s unusable with keyboard only for example. I&rsquo;d love to see it improve, so we could use it in the future.&rdquo; </p>



<p>Lashbrooke said WordCamp Central has also considered Hopin, among other apps, while doing <a href=\"https://docs.google.com/spreadsheets/d/1ym0nuKxhnzyBmNAozSNdviCjmlTq3e2J95usFbpUQrY/edit#gid=0\">extensive research on accessible platforms</a>.</p>



<p>&ldquo;Right now, everyone&rsquo;s still working on a way to make that work for everyone, and we&rsquo;re lucky that our sponsors are so honest with us about their experiences, because it helps us improve,&rdquo; Lashbrooke said. </p>



<p>&ldquo;One thing that is of paramount importance to us as a team is that all WordPress events maintain a high level of accessibility, and unfortunately when it comes to streaming platforms we have very limited options when it comes to accessible streaming services. Zoom is about the only fully-accessible platform, so it&rsquo;s the only option to use for sponsor booths.&rdquo;</p>



<p>With ten months of lead time, WordCamp Europe organizers will have plenty of opportunities to experiment with new ideas to make the event more engaging for both attendees and sponsors. All the other WordCamps on the <a href=\"https://central.wordcamp.org/schedule/\">schedule</a> through the end of the year have already been converted to online events. For the time being, it looks like virtual camps are here to stay.</p>



<p>&ldquo;I really doubt we&rsquo;ll be abandoning online events, after COVID-19 is more under control worldwide,&rdquo; WordPress Community organizer Andrea Middleton <a href=\"https://make.wordpress.org/community/2020/07/13/reimagining-online-events/#comment-28388\">said</a>. &ldquo;I think that we&rsquo;ll need to figure out how in-person events and online events can best coexist, but it seems like we&rsquo;ll have time to figure that out.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2020 23:55:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Call for Block Plugins: The WordPress Block Directory Is Open for Business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101853\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://wptavern.com/call-for-block-plugins-the-wordpress-block-directory-is-open-for-business?utm_source=rss&utm_medium=rss&utm_campaign=call-for-block-plugins-the-wordpress-block-directory-is-open-for-business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6029:\"<img />WordPress block directory.



<p class=\"has-drop-cap\">Over the weekend, Alex Shiels announced an open call for plugin authors to <a href=\"https://make.wordpress.org/plugins/2020/07/11/you-can-now-add-your-own-plugins-to-the-block-directory/\">begin submitting one-off block plugins</a> to the official <a href=\"https://wordpress.org/plugins/browse/block/\">block directory</a>. In the upcoming WordPress 5.5 update, slated for release on August 11, end-users will be able to search for, install, and add blocks directly from the editor. With little time left before release, will plugin authors make this a worthwhile feature for users?</p>



<p>&ldquo;The Block Directory is a subset of plugins in the plugin directory that can be instantly and seamlessly installed from the Gutenberg editor with a single click,&rdquo; wrote Shiels in the announcement. &ldquo;We call these new plugins &lsquo;block plugins&rsquo; and have worked hard to make it easier for people to contribute to this new feature coming to WordPress 5.5.&rdquo;</p>



<p>WordPress plugin authors now have a new <a href=\"https://wordpress.org/plugins/developers/block-plugin-validator/\">block validation tool</a> at their disposal. The validator can check an SVN repository URL, Github URL, or plugin slug to determine if it is suitable for inclusion into the WordPress block directory. It is still under development, so plugin authors should report any issues they run into.</p>



<p>For existing plugins in the plugin directory, developers can publish them to the block directory after passing validation with the tool. Plugin authors can also remove their plugins from the block directory at the click of the button.</p>



<p>The block plugin guidelines are still under development. The <a href=\"https://github.com/WordPress/wporg-plugin-guidelines/pull/68\">draft ticket</a> has been open since November 21, 2019. It has seen little activity in the months since. Presumably, there will be a finalized version on WordPress.org rather than GitHub before WordPress 5.5 lands.</p>



<p>Developers who want to begin building block plugins should follow the updated <a href=\"https://developer.wordpress.org/block-editor/tutorials/block-tutorial/\">block development tutorial</a>.</p>



<h2>A Late Rallying Cry</h2>



<p class=\"has-drop-cap\">Technically, plugin authors have been able to submit blocks to the directory for months. It was a bit of a hidden feature that few developers took advantage of. The user base was primarily Gutenberg plugin users who had enabled the experimental block directory search feature. Despite the small user base, it was an ideal time for plugin authors to begin experimenting and building an audience. It could have also been a great opportunity for relatively unknown developers to make their mark upon the WordPress world. There is still some time for that, but the community has not been actively encouraged to create blocks for the directory. With WordPress 5.5 looming ahead, the past few months seem like a missed opportunity.</p>



<p>Nick Hamze, one of the most prolific publishers of one-off blocks, is <a href=\"https://block.garden/taking-a-break/\">taking a break</a>. He originally had plans to release 99 plugins throughout 2020, but the WordPress plugin review team asked him to dial things back a bit. His routine releases were putting a strain on the team. The problem is that he was one of the few plugin authors <a href=\"https://wptavern.com/the-wacky-world-of-sorta-brilliants-sorta-fun-block-plugins\">putting in the work</a> to make the block directory a great thing.</p>



<p>As a former reviewer for the themes team, I understand how easy it is to get overwhelmed with a wave of new projects that need a code review. At the same time, I would be willing to bump Hamze&rsquo;s work to the front of the line, regardless of how often he was releasing new plugins. It may be a bit unfair to other plugin authors, but few others were betting big on what will be one of WordPress 5.5&rsquo;s highlights: a searchable block directory.</p>



<p>&ldquo;If someone would have just given me the barest encouragement I would have kept going, but due to my experience, I stopped submitting blocks and won&rsquo;t do it anymore in the future,&rdquo; said Hamze.</p>



<p>If no one else was putting in the work, there should have been no harm in giving him a bit of priority or a helping hand. That way, when WordPress 5.5 launches, there is something to show for this feature.</p>



<p>Now, we are in the 11th hour, mere weeks before 5.5&rsquo;s official release, with a meager offering of blocks &mdash; instead of hundreds of blocks, we are currently nearing the 60 mark. It is a last-minute rallying call to get plugin authors churning away before the final bell rings. Yet, WordPress just benched what was essentially its star player.</p>



<p>I have no doubt the block directory will continue to grow. More developers will buy into it, especially as full-site editing creates more possibilities in WordPress 5.6 later this year. Some authors will likely produce more blocks than the totality of the current number in the directory.</p>



<p>If the Gutenberg team had managed to squeeze the <a href=\"https://wptavern.com/version-1-prototype-of-the-wordpress-admin-block-directory-announced\">directory and management screens</a> into WordPress 5.5 admin, it would have made for a far bigger splash. It would have been good visibility for block makers. WordPress will support a block directory search for now. However, there is no way for end-users to more casually browse blocks via their admin. There is no way to see the latest block plugin releases or view the most popular blocks. Some of these things may have made one-off block development a bit more enticing to plugin authors. </p>



<p>I am still optimistic that more plugin authors will jump onto the block bandwagon. It will just be a while before we start seeing the wealth of blocks that cover the entire spectrum of what users need.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2020 20:09:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.5 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8681\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4508:\"<p id=\"block-000046ff-d8e6-40a8-9869-2dd39e50f270\"><br />WordPress 5.5 Beta 2 is now available!</p>



<p id=\"block-81bd56b9-ea44-43ad-ab36-a5ae78b54375\"><strong><strong>This software is still in development,</strong>&nbsp;</strong>so it’s not recommended to run this version on a production site. Consider setting up a test site to play with the new version.</p>



<p id=\"block-7cc1bbc6-17f9-44c5-8f67-da4e3059ad69\">You can test WordPress 5.5 beta 2 in two ways:</p>



<ul id=\"block-4840af57-f44b-4d9f-aa64-c6a452392e42\"><li>Try the&nbsp;<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;plugin (choose the “bleeding edge nightlies” option)</li><li>Or&nbsp;<a href=\"https://wordpress.org/wordpress-5.5-beta2.zip\">download the beta here</a>&nbsp;(zip).</li></ul>



<p id=\"block-a40528cb-eb3b-4c8a-8f5e-aa700f1ba086\">WordPress 5.5 is slated for release on&nbsp;<a href=\"https://make.wordpress.org/core/5-5/\">August 11th, 2020</a>, and <strong>we need your help to get there</strong>!</p>



<p>Thank you to all of the contributors that tested the <a href=\"https://wordpress.org/news/2020/07/wordpress-5-5-beta-1/\">beta 1</a> development release and provided feedback. Testing for bugs is an important part of polishing each release and a great way to contribute to WordPress. Here are some of the changes since beta 1 to pay close attention to while testing.</p>



<h2 id=\"block-15d6d57f-905d-4a47-9f66-839468a5375a\">Some highlights</h2>



<p id=\"block-85da84ec-c841-42f9-8d3b-1a4537a61d10\">Since <a href=\"https://wordpress.org/news/2020/02/wordpress-5-4-beta-1/\">beta 1</a>, <a href=\"https://core.trac.wordpress.org/query?status=closed&changetime=07%2F08%2F2020..07%2F14%2F2020&milestone=5.5&group=component&col=id&col=summary&col=owner&col=type&col=priority&col=component&col=version&order=priority\">48 bugs</a> have been fixed. Here is a summary of a few changes included in beta 2:</p>



<ul><li>19 additional bugs have been fixed in the block editor (see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>).</li><li>The Dashicons icon font has been updated (see <a href=\"https://core.trac.wordpress.org/ticket/49913\">#49913</a>).</li><li>Broken widgets stemming from changes in Beta 1 have been fixed (see <a href=\"https://core.trac.wordpress.org/ticket/50609\">#50609</a>).</li><li>Query handling when counting revisions has been improved (see <a href=\"https://core.trac.wordpress.org/ticket/34560\">#34560</a>).</li><li>An alternate, expanded view was added for <code>wp_list_table</code> (see <a href=\"https://core.trac.wordpress.org/ticket/49715\">#49715</a>).</li><li>Some adjustments were made to the handling of default terms for custom taxonomies (see <a href=\"https://core.trac.wordpress.org/ticket/43517\">#43517</a>)</li></ul>



<p>Several updates have been made to the block editor. For details, see <a href=\"https://github.com/WordPress/gutenberg/pull/23903\">#23903</a> and <a href=\"https://github.com/WordPress/gutenberg/pull/23905\">#23905</a>.</p>



<h2 id=\"block-76156b2b-0a52-4502-b585-6cbe9481f55b\">Developer notes</h2>



<p id=\"block-3fe5e264-0a95-4f12-9a18-0cb9dc5955d1\">WordPress 5.5 has lots of refinements to polish the developer experience. To keep up, subscribe to the&nbsp;<a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a>&nbsp;and pay special attention to the&nbsp;<a href=\"https://make.wordpress.org/core/tag/5-5+dev-notes/\">developers’ notes</a>&nbsp;for updates on those and other changes that could affect your products.</p>



<h2 id=\"block-bc89fd56-47b0-439f-8e2c-4a642c80a616\">How to Help</h2>



<p id=\"block-3ff83a77-8b54-4061-ae2d-45fc984cbd76\">Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help us translate WordPress into more than 100 languages</a>!</p>



<p id=\"block-9d871099-ec49-446c-8322-9e49b7498c10\">If you think you’ve found a bug, you can post to the&nbsp;<a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a>&nbsp;in the support forums. We’d love to hear from you!</p>



<p id=\"block-bd71c1d3-39d9-4b2a-8193-3486497b45fd\">If you’re comfortable writing a reproducible bug report,&nbsp;<a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a>,&nbsp;where you can also find a list of&nbsp;<a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2020 17:24:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Admin 2020 Reimagines WordPress Admin and Media Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101275\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:175:\"https://wptavern.com/admin-2020-reimagines-wordpress-admin-and-media-library?utm_source=rss&utm_medium=rss&utm_campaign=admin-2020-reimagines-wordpress-admin-and-media-library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6102:\"<p>Unless I&rsquo;m trying to be aware of it, I don&rsquo;t see the WordPress admin anymore. When you work inside it every day, it becomes a means to an end, like a subway ride to work. You scan your ticket (log in) and you&rsquo;re on your way to whatever admin business is the order of the day. After awhile, you accept its appearance and no longer spend conscious thoughts critiquing it. </p>



<p>WordPress doesn&rsquo;t overhaul its admin design very often, since it requires a massive effort from contributors. The beauty of this pluggable system is that anyone with the skills can change the design to suit their own aesthetic. That is what WordPress developer Mark Ashton has done with <a href=\"https://admintwentytwenty.com/\">Admin 2020</a>, a plugin that completely reskins the admin to give it a different look.  </p>



<img />



<p>Browsing the Admin 2020 <a href=\"https://demo.ashtonretouch.com/wp-login.php\">demo</a>, you might not even know you were using WordPress. The design is built on top of <a href=\"https://getuikit.com/\">UIkit</a>, a lightweight UI framework that has a softer, rounder look to it. Users can switch between light and dark mode. Admin 2020 features white labeling, allowing users to upload their own logos and brand the dashboard for themselves. The admin area can also be radically simplified based on user role. The plugin allows for admin menu items to be renamed or toggled for visibility.</p>



<div class=\"wp-block-embed__wrapper\">
<a href=\"https://cloudup.com/c7uRS7QtvxU\"><img src=\"https://cldup.com/C4QGUuFG48.gif\" alt=\"Admin 2020 dashboard overview dark mode\" width=\"600\" height=\"336\" /></a>
</div>



<p>Admin 2020 has an Overview page that can sync with Google Analytics to show reports that can be filtered by date, including Users, Page Views, Sessions, and device breakdown. It also displays summaries of recent comments, popular pages, system info, new users, and other content-related data.</p>



<p>The plugin gives WordPress&rsquo; media library a new look, along with folders and filters for an alternative way to organize images. Ashton claims it is up to 50% faster than the classic WordPress media library. The gallery editor also adds filters, free draw, icons/shapes, text and other mask filters for enhancing images.</p>



<div class=\"wp-block-embed__wrapper\">
<a href=\"https://cloudup.com/cMJOcOz4-QQ\"><img src=\"https://cldup.com/hhWJ2HZrFL.gif\" alt=\"Admin 2020 media library\" width=\"800\" height=\"450\" /></a>
</div>



<p>&ldquo;A lot of what admin 2020 does is built on existing WordPress functions, it just uses them in a different way,&rdquo; Ashton said. &ldquo;Instant search for example leverages AJAX and you can search all of your content from one place.&rdquo;</p>



<p>The Admin 2020 plugin started out as a personal passion project. After building everything from plugins to themes to a hospitality reservation management system using WordPress, Ashton thought he would try his hand at making an admin theme he would enjoy using.</p>



<p>&ldquo;It was something I have always wanted and basically got tired of waiting for,&rdquo; he said. &ldquo;I&rsquo;ve been using WordPress for my projects for many years and while I love the platform I have never enjoyed using the backend. I wanted to create something with a strong emphasis on modern UI but also something that brought useful features that would speed up my workflow.&rdquo;</p>



<p>Ashton said supporting third-party extensions is one of the most challenging aspects of maintaining the plugin. Admin 2020 includes<a href=\"https://admintwentytwenty.com/pages/support\"> full support for popular plugins</a> like Jetpack, WooCommerce, Elementor, Yoast SEO, and Divi Builder, but there are thousands of others that have not been tested.</p>



<p>&ldquo;The process of supporting a plugin usually isn&rsquo;t that difficult but it&rsquo;s more the case of there are so many plugins out there,&rdquo; Ashton said. &ldquo;Some plugins rely heavily on their own CSS in which case they usually work fine in light mode but don&rsquo;t look right in dark mode. Then you have plugins that use WP components and they usually work great right out of the box. Some plugins actually disable all custom backend styling, though &ndash; they are a real challenge to get around!&rdquo;</p>



<p>Ashton launched Admin 2020 in April, so it is still relatively new to the commercial plugin scene. It is sold as a single plugin but is built in a modular way so that most parts of it can be disabled. The plugin&rsquo;s tiered pricing begins at $15 for a single site license. He opted to pursue a fully commercial model as opposed to releasing a free plugin with paid upgrades. </p>



<p>&ldquo;In short, I wanted the plugin to stay as streamlined as possible,&rdquo; Ashton said. &ldquo;I didn&rsquo;t want to add yet more plugin notices at the top of admin pages bugging you to upgrade. I wanted people to experience the full version of Admin 2020.&rdquo;</p>



<p>His strategy has been successful so far, as Admin 2020 has become a full-time project after just three months. The London-based company is a one-person effort at the moment, but Ashton is looking to bring another developer on.</p>



<p>&ldquo;Active installs are around 2,000 now, and as a result I am very busy and Admin 2020 is a full time project,&rdquo; he said. &ldquo;I love working on the plugin though, there is a lot of scope on where this can go and the feedback has been great!&rdquo;</p>



<p>When asked if he worries about the name becoming outdated in the coming years, Ashton said he is happy with the name but if he thinks of something more suitable it may change in the future. He believes there is a market for all kinds of different themes to transform the WordPress admin but isn&rsquo;t currently planning to add more designs.</p>



<p>&ldquo;Not everyone is the same, and good design looks different to everybody,&rdquo; Ashton said. &ldquo;I am not looking at other designs at the moment &ndash; more offering the ability to customize the design yourself through Admin 2020.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jul 2020 23:21:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Copy and Paste Editor Blocks via GutenbergHub’s Block Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101455\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:185:\"https://wptavern.com/copy-and-paste-editor-blocks-via-gutenberghubs-block-library?utm_source=rss&utm_medium=rss&utm_campaign=copy-and-paste-editor-blocks-via-gutenberghubs-block-library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6755:\"<img />GutenbergHub block library.



<p class=\"has-drop-cap\">Spearheaded by Munir Kamal, GutenbergHub <a href=\"https://gutenberghub.com/introducing-gutenberg-blocks-library-more/\">launched a free block library</a> to the WordPress community today. Currently, there are 37 custom-designed blocks that users can copy and paste to their website.</p>



<p>Unlike the block directory on WordPress.org, the blocks available from this project are not plugins.  They are handled through copying and pasting a bit of code.  Technicaly they are blocks that act as a grouping of various core WordPress blocks.   However, in reality, they more closely resemble block patterns.</p>



<p>The one caveat is that users must install Kamal&rsquo;s <a href=\"https://wptavern.com/control-block-design-via-the-editorplus-wordpress-plugin\">recently-launched EditorPlus plugin</a>. It allows end-users to style the core WordPress blocks via a slew of custom design options. Because the plugin neither relies on third-party blocks nor creates its own, all of the block designs in GutenbergHub&rsquo;s library are built directly from the blocks available in WordPress. This makes for a much smaller dependency tree and fewer areas where things could go wrong in the fast-moving world of blocks.</p>



<p>By tying the block designs to the <a href=\"https://wordpress.org/plugins/editorplus/\">EditorPlus </a>plugin, it gives Kamal much more control over the final output. Having cross-theme consistency is still a tough job, but it improves by working within the confines of the design framework from the plugin.</p>



<p>&ldquo;I created [EditorPlus] to fulfill my requirements in bringing easily customizable blocks and templates to Gutenberg users,&rdquo; said Kamal.</p>



<p>He launched a <a href=\"https://wptavern.com/gutenberg-hub-launches-collection-of-100-block-templates\">block template library</a> in March. However, it originally asked users to copy block HTML and CSS code separately. Now, both the block and template libraries require the EditorPlus plugin. This allows Kamal to build everything on top of a sort of framework and remove third-party dependencies. Kamal said the system will help make things easier for users while giving him more control over development and maintenance.</p>



<p>Thus far, most of the projects he has launched on GutenbergHub have built on top of the previous project in some way. They were stepping stones that led him to build a bigger yet more well-rounded system. However, we are likely light-years away from seeing how everything takes shape. The Gutenberg project is moving fast, and GutenbergHub will need to react to upcoming changes. It will need to contend with the inclusion of block patterns in WordPress 5.5, full-site editing later this year, and more design options for blocks down the road. Like the block system itself, all of this is still a bit experimental until we begin to see some sort of settling point. It will be interesting to watch how things unfold. Kamal and his GutenbergHub project are in a good position to ride the waves of constant change.</p>



<p>Watch a short video on how GutenbergHub&rsquo;s block library and EditorPlus plugin work together to create pricing columns:</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<h2>How the Block Library Works</h2>



<p class=\"has-drop-cap\">Currently, users can search the <a href=\"https://gutenberghub.com/blocks/\">GutenbergHub block library</a> to pick and choose the blocks they want. The library is sub-divided by seven categories:</p>



<ul><li>Testimonial</li><li>Team</li><li>Feature</li><li>Card</li><li>Pricing</li><li>Call to Action</li><li>Stats</li></ul>



<p>Users can copy a small bit of JSON code for individual blocks they would like to add to their site. To add a block, installing and activating the EditorPlus plugin is a hard requirement. Once that is done, users can visit the Blocks tab under the EditorPlus settings screen and paste the code.</p>



<img />Adding a block&rsquo;s code via the EditorPlus plugin.



<p>The blocks tab acts as a central hub to manage blocks from the library. Users can add, delete, or deactivate any blocks added from GutenbergHub.</p>



<p>Each active block added to the site is available through the block inserter on the editor. Perhaps the one downside is the blocks do not have a preview image. Some of the blocks have similar names, such as Card 1, Card 2, etc. Having a preview image would help distinguish them &mdash; <em>or just better names</em>.</p>



<img />Inserting a block from GutenbergHub into the editor.



<h2>Future Plans</h2>



<p class=\"has-drop-cap\">Ideally, the EditorPlus plugin could serve up GutenbergHub&rsquo;s blocks and templates over an API, providing users with a simple import solution at the click of a mouse. The copy/paste approach means having to visit a separate website instead of staying in the comfort of one&rsquo;s WordPress admin. Kamal originally went with the copy/paste solution because he wanted everything to be independent of plugins. However, because WordPress did not have the design controls in place, he realized he needed at least one plugin as part of the equation. That is where EditorPlus came in. This should ultimately free him up to build an import feature.</p>



<p>&ldquo;I will possibly include a direct inserter for templates and blocks in the Editor Plus plugin,&rdquo; he said. However, there is no indication of when that will happen. It would make the user experience more seamless and efficient.</p>



<p>Kamal is still mulling over how he will eventually monetize the project. Right now, he has put a lot of time and resources behind it with little return on his investment. At some point, this could become unsustainable unless his other commercial ventures can fund it. In the long run, he will need to have a solid business plan behind the entire GutenbergHub project.</p>



<p>&ldquo;I do plan to monetize the GutenbergHub offering somehow,&rdquo; he said. &ldquo;I&rsquo;ve not yet planned out this, but that could be a premium subscription or offering pro blocks, templates, and an EditorPlus add-on. Another option would be to convert it into a marketplace where designers can create and sell blocks and templates. This is something I&rsquo;ve yet to plan out to be honest. Rest assured, what is free will remain free and will actually improve over time.&rdquo;</p>



<p>Kamal said his most immediate plan is to gather more feedback from users. &ldquo;I ended up creating a <a href=\"https://www.facebook.com/groups/gutenberghub/\">Facebook group</a>,&rdquo; he said. &ldquo;This would be the best and easiest way for anyone to share ideas, suggestions, and feedback about GutenbergHub.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jul 2020 21:14:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: WordPress Documentation Team Bans Links to Commercial Websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101625\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:189:\"https://wptavern.com/wordpress-documentation-team-bans-links-to-commercial-websites?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-documentation-team-bans-links-to-commercial-websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5904:\"<p>This week WordPress&rsquo; Documentation team <a href=\"https://make.wordpress.org/docs/tag/external-linking-policy/\">announced</a> a ban on links to commercial websites in a revision to its external linking policy:</p>



<blockquote class=\"wp-block-quote\"><p>During discussion about external linking policy, we came to conclusion that we won&rsquo;t allow, at least in the beginning and for the time being, any commercial blogs. So before you start arguing that some popular&nbsp;plugin&rsquo;s blogs have valuable information, let me stop you right there.</p><p>Allowing &ldquo;popular plugin&rsquo;s/theme&rsquo;s/services&rsquo; etc blogs&rdquo; and all other commercial blogs will put us in a position to protect documentation from being abused as marketing media, to protect ourselves from accusations of being biased and to defend every decision we make along the way. And still, there will be dissatisfied sides claiming we weren&rsquo;t fair and did them wrong. The idea of allowing external linking will become its own purpose.</p></blockquote>



<p>Despite the announcement&rsquo;s abrasive phrasing discouraging further discussion on the matter, the controversial decision stirred up a heated conversation in the comments. Yoast founder Joost de Valk <a href=\"https://make.wordpress.org/docs/2020/07/06/external-linking-policy-commercial-blogs/#comment-40100\">contends</a> that companies contributing to WordPress might as well receive some promotion as a benefit:</p>



<blockquote class=\"wp-block-quote\"><p>I understand that you want to prevent discussions about bias.</p><p>But I think your premise here is wrong: you&rsquo;re saying you&rsquo;re not &ldquo;biased&rdquo; if you&rsquo;re not linking to commercial companies. I would say we&rsquo;re all inherently biased, because some of those companies do a lot for the WordPress community, while others do not.</p><p>The companies that contribute to WordPress a lot used to get some links, and thus some promotion as benefit from the fact that they&rsquo;re contributing. By removing that from them, you&rsquo;re basically treating those that don&rsquo;t give back the same as companies that do give back, something which I think is simply wrong. So I very heavily disagree with this decision.</p></blockquote>



<p>Milana Cap, the Documentation Team member who penned the announcement, clarified that the policy change does not remove external links to commercial sites from WordPress.org. It only applies to documentation sites, including <a href=\"https://wordpress.org/support/\">HelpHub</a>,&nbsp;<a href=\"https://developer.wordpress.org/reference/\">Code Reference</a>,&nbsp;<a href=\"https://developer.wordpress.org/plugins/\">Plugin</a>&nbsp;and&nbsp;<a href=\"https://developer.wordpress.org/themes/\">Theme</a>&nbsp;Developer Handbook,&nbsp;<a href=\"https://developer.wordpress.org/block-editor/\">Block Editor Handbook</a>,&nbsp;<a href=\"https://developer.wordpress.org/apis/\">Common APIs Handbook</a>.</p>



<p>&ldquo;There is no way to make this fair,&rdquo; Cap said. &ldquo;And we can discuss about many unfair parallels happening in&nbsp;open source&nbsp;communities; such as how many hours per week can be contributed by a freelancer vs paid company contributor, meeting times (where decisions are made) in the middle of the night in your timezone etc.&rdquo;</p>



<p>Timi Wahalahti suggested one solution would be to better utilize the <a href=\"https://wordpress.org/five-for-the-future/pledges/\">Five for the Future pledges</a> page to identify significant contributors to documentation if links to commercial sites are no longer an option.</p>



<p>Several commenters noted the value of linking to additional examples and resources but also recommended WordPress put a version or timestamp in place to give the reader more context.</p>



<p>WordPress agency owner Jon Brown characterized the ban as &ldquo;undesirable gatekeeping,&rdquo; saying that the policy suggests all things commercial are &ldquo;inherently corrupt and not trustworthy nor valuable.&rdquo; </p>



<p>&ldquo;A links value is inherently subjective and ought to be delt with subjectively,&rdquo; Brown said. &ldquo;Trying to create high level objective rules doesn&rsquo;t seem beneficial or realistic. I certainly disagree that all &lsquo;commercial&rsquo; sites should be blanket banned.</p>



<p>&ldquo;I do think there are some low level disqualifiers that could guide authors and moderators in what links are appropriate. Those should be criteria that directly impact the users of docs, and being commercial doesn&rsquo;t. Those are things like, the source being accessible, the source not being pay walled, etc.&rdquo;</p>



<p>Cap responded, saying that the root of the issue is that allowing commercial links puts the documentation team in the unwanted position of having to find a fair way to decide on which links are allowed to be included. She also indicated that the policy may evolve over time but that for now the decision on the ban is final.</p>



<p>&ldquo;Perhaps over time we&rsquo;ll figure that out,&rdquo; Cap said. &ldquo;We&rsquo;ll certainly know more once we start doing it. For now, this is the decision.&rdquo;</p>



<p>External sources can be valuable supplements to documentation, but this conversation underscores the need for better incentives for people to spend time documenting WordPress. As the team is already running on limited resources, they are trying to avoid having to heavily police links to commercial websites.</p>



<p>&ldquo;The bottom line is: we haven&rsquo;t figured out the best way to deal with commercial blogs or sites in a fair manner and thus our focus is going to be on links that don&rsquo;t drop into that grey zone,&rdquo; Cap said. &ldquo;We do expect to eventually get towards discussing how we can safely include commercial blog links (if this even is possible).&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2020 23:22:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Ariele Lite Is a Fun and Refreshing Theme for WordPress Bloggers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101733\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:193:\"https://wptavern.com/ariele-lite-is-a-fun-and-refreshing-theme-for-wordpress-bloggers?utm_source=rss&utm_medium=rss&utm_campaign=ariele-lite-is-a-fun-and-refreshing-theme-for-wordpress-bloggers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6559:\"<img />



<p class=\"has-drop-cap\">Ariele Lite, the latest theme from Rough Pixels, went live in the <a href=\"https://wordpress.org/themes/ariele-lite/\">WordPress theme directory</a> today. In an ecosystem where designers are dubbing most themes as multipurpose, it is refreshing to see a well-designed theme that is unafraid to cater specifically to bloggers.</p>



<p>It is not often that I get the opportunity to test a brand new theme from the official WordPress theme directory that supports block editor styles. Or, at least it&rsquo;s not often that I test one that lives up to the claim. Despite a couple of trivial issues, Ariele Lite is a theme that will appeal to a wide audience.</p>



<p>Whenever I see the word &ldquo;lite&rdquo; appended to the end of a theme name, it is immediately off-putting. Far too often, I have been burned when activating such themes. My already low expectations are generally met with unfulfilled promises, missing styles for basic features, and a metric ton of advertising for the <em>real</em> product (i.e., the non-lite version that I can buy). However, I was pleasantly surprised by the work that went into Ariele Lite. It was a complete and fully-functioning theme and did not feel like crippleware. Plus, most of the upsell features in the commercial version were not that appealing to me. I can find most of them in plugin form. However, they could be nice additions for the user who wants integrated features that will look and feel like they are a part of the theme without the hassle of hunting down the perfect plugin.</p>



<p>What makes Ariele Lite a great theme is that it has an opinionated style, even if it is merely some subtle flavoring, for nearly every element or block. It never goes overboard into lavishness, which means it doesn&rsquo;t break readability. It is a theme that has fun with its design while being well-groomed enough for professional bloggers.</p>



<p>Even if Ariele Lite is not to your taste, Rough Pixels has a history of releasing <a href=\"https://wordpress.org/themes/author/roughpixels/\">clean, well-designed themes</a>. There is a little something for almost anyone. The company is also one of the few theme-makers with multiple themes that support the block editor in the free directory.</p>



<h2>Theme Design and Features</h2>



<img />Ariele Lite customizer options.



<p class=\"has-drop-cap\">Ariele Lite is not stock full of custom features, but it has enough flexibility to satisfy most people who want to do some customization. More than anything, my favorite thing about the theme is that it does not take much cajoling to achieve the look of the <a href=\"https://demos.roughpixels.com/ariele-lite/\">demo</a> the theme author has put together. <em>There should be a WordPress theme directory filter tag titled &ldquo;what you see in the demo is what you get.&rdquo;</em></p>



<p>The theme comes with a reasonable number of theme design options. Users can change nearly every aspect of their front end. The theme has options for all its colors, several labels, and other theme-specific elements. It stops short of adding font settings, which is likely a good thing given the theme&rsquo;s attention to detail with typography.</p>



<p>The one particular design element that caught my eye was the theme&rsquo;s blockquote style. Some bloggers may want something a bit less pronounced in design, depending on how they want to present quotes. However, I am a sucker for beautiful quote designs, and Ariele Lite did not disappoint.</p>



<img />Ariele Lite&rsquo;s blockquote style.



<p>The quote design is representative of the attention that Rough Pixels has given to other elements in the theme. From the bold headings to the caption design that overlays the featured image, the team has left few stones unturned.</p>



<p>For bloggers, the most important element is the typography. It is one of those elements that too many theme authors overlook, but it is paramount when catering a theme to bloggers. This is one area the theme excels at. However, if selecting the sidebar-less layout option, there are too many characters per line for comfortable reading. Stick with either the left or right sidebar option to stay on point.</p>



<p>The theme comes with Jetpack infinite scrolling support, a custom posts widget with thumbnails, and enough sidebars to put widgets anywhere you might want. I like the default setup well enough, so these features are less important to me. However, they are likely welcome additions for many users.</p>



<h2>Not Without Issues</h2>



<p class=\"has-drop-cap\">I have been building this theme up thus far in the review. Now, it is time to take it down a notch or two. Ariele Lite is by no means perfect. No software is. I hit a few snags.</p>



<p>The biggest issue I ran into was the theme did not handle full-aligned blocks well. Instead of capping them to the width of the content container, they would break out into the sidebar. Even when selecting a layout with no sidebar, the same issue persists.</p>



<img />Full-width image creates a design issue.



<p>This would be an absolute deal-breaker for me as a user. As a developer, I know that it is simply an oversight and can be corrected. The theme author can correct it with a single line of CSS. Users should simply be aware of the problem, at least until the theme author has a chance to address it.</p>



<p>Outside of that, nested lists in sidebars need a little TLC. The spacing is off. It is also missing support for pagination via the <code>&lt;!--nextpage--&gt;</code> quick tag on single post views.</p>



<p>These few items are relatively trivial issues to address. They are worth noting for the 1.0.4 version of the theme and will likely be fixed in future iterations.</p>



<p class=\"is-style-highlight has-gray-100-background-color has-background bg-gray-100\"><strong>Note:</strong> The above issues were quickly addressed by the theme author in version 1.0.5.</p>



<h2>Final Thoughts</h2>



<p class=\"has-drop-cap\">Ariele Lite does not break much new ground. It is simply a solid blogging theme that supports the block editor. Nearly two years in, such themes are still few and far between. It is ideally suited for people who love to write, and it has enough options to keep those who want to do a bit of tweaking happy.</p>



<p>If the theme&rsquo;s development team is proactive about addressing the few minor issues, I would recommend it to anyone who wants a good theme that fully supports the latest version of WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2020 20:35:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"WPTavern: Open Source Initiative to Host Virtual State of the Source Summit, September 9-10\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wptavern.com/?p=101622\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:225:\"https://wptavern.com/open-source-initiative-to-host-virtual-state-of-the-source-summit-september-9-10?utm_source=rss&utm_medium=rss&utm_campaign=open-source-initiative-to-host-virtual-state-of-the-source-summit-september-9-10\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2787:\"<p>OSI (Open Source Initiative) is hosting a new 24-hour, virtual conference called <a href=\"https://opensource.org/StateOfTheSource\">State of the Source Summit</a>, September 9-10. The non-profit organization plays an important role in the open source ecosystem as stewards of the&nbsp;<a href=\"https://opensource.org/docs/osd\">Open Source Definition (OSD)</a>.&nbsp;OSI is responsible for reviewing and approving licenses as OSD-conformant, which indirectly helps mediate community conflicts.</p>



<p>As part of the organization&rsquo;s overall mission to educate the public on the economic and strategic advantages of open source technologies and licenses, OSI is hosting a global summit to facilitate conversations on the current state of open source software. </p>



<p>&ldquo;We are so very excited to host our first-ever conference, with a global approach,&rdquo; OSI Board President Josh Simmons said. &ldquo;State of the Source provides an opportunity for both the open source software community and the OSI&mdash;all those who have contributed so much&mdash;to reflect on how we got here, why we have succeeded, and what needs to happen now.&rdquo;</p>



<p>The conference will run four tracks with sessions that fall under these general groupings:</p>



<ul><li><a href=\"https://opensource.org/StateOfTheSource#OSLOSI\">Open Source Licenses and the OSI</a></li><li><a href=\"https://opensource.org/StateOfTheSource#Business\">Projects &amp; People</a></li><li><a href=\"https://opensource.org/StateOfTheSource#Principles\">Principles, Policy, &amp; Practices</a></li><li><a href=\"https://opensource.org/StateOfTheSource#HotTopics\">&ldquo;Hot Topics&rdquo;</a></li></ul>



<p>OSI has identified several example topics for each track, to guide potential presenters in writing a proposal. The first track encompasses more OSI-specific topics, such as license proliferation and license enforcement. </p>



<p>Projects &amp; People includes topics that apply more broadly to communities and organizations &ndash; open source business models, sustainability, patents, and trademarks. The Principles, Policy, and Practices track is geared towards application and example topics include things like explaining a license to your peers, learning how to select a license for your project, and compliance, compatibility, and re-licensing.</p>



<p>As more conferences are forced to move to a virtual format, the wider open source community has the opportunity to be more engaged in an event like State of the Source. It&rsquo;s a good venue for addressing non-technical issues related to the challenges facing open source maintainers and the community. The <a href=\"https://forms.gle/CriSN1Ddtjb1GPbX8\">call for proposals</a> ends July 16, and speakers will be announced August 25.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2020 22:07:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 07 Aug 2020 06:09:56 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Fri, 07 Aug 2020 06:00:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("141","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1596823795","no");
INSERT INTO `wp_options` VALUES("142","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1596780595","no");
INSERT INTO `wp_options` VALUES("143","_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b","1596823795","no");
INSERT INTO `wp_options` VALUES("144","_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2020/08/wordpress-5-5-release-candidate-2/\'>WordPress 5.5 Release Candidate 2</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/automattic-relaunches-p2-self-hosted-version-on-the-roadmap?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=automattic-relaunches-p2-self-hosted-version-on-the-roadmap\'>WPTavern: Automattic Relaunches P2, Self-Hosted Version on the Roadmap</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/plugin-rank-provides-insight-into-wordpress-search-results-competitive-analysis-and-email-reports-for-developers?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=plugin-rank-provides-insight-into-wordpress-search-results-competitive-analysis-and-email-reports-for-developers\'>WPTavern: Plugin Rank Provides Insight Into WordPress Search Results, Competitive Analysis, and Email Reports for Developers</a></li><li><a class=\'rsswidget\' href=\'https://buddypress.org/2020/08/buddypress-6-2-0/\'>BuddyPress: BuddyPress 6.2.0 Maintenance release</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("146","core_updater.lock","1596780618","no");
INSERT INTO `wp_options` VALUES("150","_site_transient_timeout_available_translations","1596792507","no");
INSERT INTO `wp_options` VALUES("151","_site_transient_available_translations","a:121:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-17 12:47:05\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-06 11:16:33\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.15/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-01-22 10:57:09\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:6:\"4.8.14\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.8.14/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-19 11:34:21\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:33:\"མུ་མཐུད་དུ།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-24 08:04:42\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-27 07:17:53\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-11 08:59:48\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-12 08:30:51\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-15 20:45:17\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-02 17:15:46\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.3.4/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-17 18:24:32\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-12 08:02:09\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-12 08:02:56\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.3.3/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-02 17:15:35\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 19:35:42\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-11 06:02:49\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 19:05:13\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-02-14 09:40:29\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-03 08:38:10\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-18 22:29:01\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-02-14 12:06:57\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.3/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 20:23:33\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-17 21:25:28\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-02-10 15:47:49\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-01-23 23:02:03\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:5:\"5.3.2\";s:7:\"updated\";s:19:\"2019-11-12 04:43:11\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.2/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 21:29:36\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-26 20:03:50\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-13 05:44:24\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:9:\"5.0-beta3\";s:7:\"updated\";s:19:\"2018-11-28 16:04:33\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0-beta3/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-08 17:55:03\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.3/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-16 16:44:44\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-16 12:41:52\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 21:55:26\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-04 11:58:26\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2020-07-04 16:43:09\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.15/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-11 12:25:16\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-16 16:33:37\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-06-05 20:32:13\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.3/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 20:26:35\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3.4/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-19 14:36:40\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-01-04 22:54:51\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-12 21:35:30\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-05-19 07:43:57\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"次へ\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-03-25 11:03:02\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-02-28 21:59:12\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3.3/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-09 07:34:10\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.3/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2019-12-04 12:22:34\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.15/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-29 06:09:28\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.2.7\";s:7:\"updated\";s:19:\"2020-07-14 08:45:32\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.7/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:6:\"4.7.18\";s:7:\"updated\";s:19:\"2020-07-14 09:04:42\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.18/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-08 12:57:25\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.8.14\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.14/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:6:\"4.9.15\";s:7:\"updated\";s:19:\"2018-08-31 11:57:07\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.15/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-13 22:20:11\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 20:47:20\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.3.4/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 20:46:26\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-22 15:40:41\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-01-01 08:53:00\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-22 13:24:47\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-10 19:31:47\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-18 23:47:49\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-01-08 13:01:50\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.3.3/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-25 10:44:19\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-28 11:14:18\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-06 17:31:43\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:3:\"5.3\";s:7:\"updated\";s:19:\"2019-11-12 04:37:38\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.3/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:3:\"snd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-02 07:46:23\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-26 11:40:37\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.3/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-13 09:13:17\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-15 22:50:02\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-26 23:48:18\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.2.6\";s:7:\"updated\";s:19:\"2019-10-22 00:19:41\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.6/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.2.7\";s:7:\"updated\";s:19:\"2020-06-04 18:07:56\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.7/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-06-16 22:44:16\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-07-27 13:00:28\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.4/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2020-04-09 10:48:08\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:6:\"5.0.10\";s:7:\"updated\";s:19:\"2019-01-23 12:32:40\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0.10/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2019-12-07 15:52:24\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.3/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2020-08-02 01:01:25\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.3.4\";s:7:\"updated\";s:19:\"2019-12-08 21:26:25\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.4/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.3.3\";s:7:\"updated\";s:19:\"2020-03-08 12:12:22\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.3/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `wp_options` VALUES("152","WPLANG","","yes");
INSERT INTO `wp_options` VALUES("153","new_admin_email","skyloft@example.com","yes");
INSERT INTO `wp_options` VALUES("156","_transient_timeout_plugin_slugs","1596876670","no");
INSERT INTO `wp_options` VALUES("157","_transient_plugin_slugs","a:6:{i:0;s:19:\"akismet/akismet.php\";i:1;s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:36:\"contact-form-7/wp-contact-form-7.php\";i:4;s:33:\"smart-slider-3/smart-slider-3.php\";i:5;s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";}","no");
INSERT INTO `wp_options` VALUES("158","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("159","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1596792757","no");
INSERT INTO `wp_options` VALUES("160","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4714;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:4275;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2679;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2560;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1966;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1815;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1797;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1486;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1481;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1477;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1453;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1444;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1442;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1306;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1212;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1203;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1139;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1129;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1099;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:1002;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:890;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:887;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:881;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:879;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:792;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:792;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:784;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:778;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:772;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:751;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:733;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:722;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:719;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:699;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:692;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:671;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:661;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:661;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:657;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:649;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:634;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:629;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:602;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:589;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:589;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:580;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:580;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:574;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:561;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:554;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:554;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:550;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:541;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:539;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:532;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:531;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:528;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:517;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:517;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:512;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:508;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:503;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:494;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:491;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:479;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:478;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:471;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:454;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:445;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:438;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:438;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:432;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:432;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:430;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:423;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:421;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:419;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:413;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:411;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:409;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:400;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:398;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:396;}s:5:\"block\";a:3:{s:4:\"name\";s:5:\"block\";s:4:\"slug\";s:5:\"block\";s:5:\"count\";i:393;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:388;}s:9:\"elementor\";a:3:{s:4:\"name\";s:9:\"elementor\";s:4:\"slug\";s:9:\"elementor\";s:5:\"count\";i:387;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:382;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:382;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:378;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:377;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:374;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:371;}s:8:\"shipping\";a:3:{s:4:\"name\";s:8:\"shipping\";s:4:\"slug\";s:8:\"shipping\";s:5:\"count\";i:366;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:364;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:360;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:353;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:348;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:342;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:342;}s:6:\"import\";a:3:{s:4:\"name\";s:6:\"import\";s:4:\"slug\";s:6:\"import\";s:5:\"count\";i:338;}}","no");
INSERT INTO `wp_options` VALUES("163","n2_ss3_version","3.4.1.8/b:release-3.4.1.8/r:70fceec40b0e84027a126b8c6fc9c014dc33808d","yes");
INSERT INTO `wp_options` VALUES("164","widget_smartslider3","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("172","wpcf7","a:2:{s:7:\"version\";s:5:\"5.2.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1596782905;s:7:\"version\";s:5:\"5.2.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}","yes");
INSERT INTO `wp_options` VALUES("173","secret_key","[p( ll#(-*k<xEY2{-gdp2Fj:eYpYh[FOpi/MMa*~fyB5sC]MP*Z,4~MAiH+Nv/C","no");
INSERT INTO `wp_options` VALUES("176","nav_menu_options","a:1:{s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("178","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1596790258;s:7:\"checked\";a:6:{s:7:\"skyloft\";s:5:\"1.0.0\";s:14:\"twentynineteen\";s:3:\"1.4\";s:15:\"twentyseventeen\";s:3:\"2.2\";s:13:\"twentysixteen\";s:3:\"2.0\";s:12:\"twentytwenty\";s:3:\"1.1\";s:20:\"wp-bootstrap-starter\";s:5:\"3.3.3\";}s:8:\"response\";a:4:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.1.6.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.3.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:13:\"twentysixteen\";a:6:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.2.1.zip\";s:8:\"requires\";s:3:\"4.4\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.4.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("179","theme_mods_skyloft","a:8:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:27:\"header_banner_title_setting\";s:21:\"Skyloft Climbing Park\";s:29:\"header_banner_tagline_setting\";s:20:\"For your excitement!\";s:24:\"header_banner_visibility\";b:0;s:16:\"header_textcolor\";s:5:\"blank\";s:25:\"wp_bootstrap_starter_logo\";s:52:\"http://localhost/wp-content/uploads/2020/08/logo.png\";s:16:\"background_color\";s:6:\"ffffff\";}","yes");
INSERT INTO `wp_options` VALUES("181","theme_switch_menu_locations","a:2:{s:7:\"primary\";i:2;s:8:\"expanded\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("182","current_theme","Skyloft","yes");
INSERT INTO `wp_options` VALUES("183","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("184","theme_switched_via_customizer","","yes");
INSERT INTO `wp_options` VALUES("185","customize_stashed_theme_mods","a:0:{}","no");
INSERT INTO `wp_options` VALUES("186","triggered_welcomet","1","yes");
INSERT INTO `wp_options` VALUES("201","analyst_cache","s:6:\"a:0:{}\";","yes");
INSERT INTO `wp_options` VALUES("203","show_new_notification","yes","yes");
INSERT INTO `wp_options` VALUES("204","show_premium_cumulative_count_notification","yes","yes");
INSERT INTO `wp_options` VALUES("205","sfsi_custom_icons","no","yes");
INSERT INTO `wp_options` VALUES("206","sfsi_section1_options","s:511:\"a:14:{s:16:\"sfsi_rss_display\";s:2:\"no\";s:18:\"sfsi_email_display\";s:2:\"no\";s:21:\"sfsi_facebook_display\";s:3:\"yes\";s:20:\"sfsi_twitter_display\";s:3:\"yes\";s:20:\"sfsi_youtube_display\";s:3:\"yes\";s:22:\"sfsi_pinterest_display\";s:2:\"no\";s:21:\"sfsi_telegram_display\";s:2:\"no\";s:15:\"sfsi_vk_display\";s:2:\"no\";s:15:\"sfsi_ok_display\";s:2:\"no\";s:19:\"sfsi_wechat_display\";s:2:\"no\";s:18:\"sfsi_weibo_display\";s:2:\"no\";s:21:\"sfsi_linkedin_display\";s:2:\"no\";s:22:\"sfsi_instagram_display\";s:2:\"no\";s:17:\"sfsi_custom_files\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("207","sfsi_section2_options","s:1756:\"a:44:{s:12:\"sfsi_rss_url\";s:0:\"\";s:17:\"sfsi_rss_blogName\";s:0:\"\";s:18:\"sfsi_rss_blogEmail\";s:0:\"\";s:14:\"sfsi_rss_icons\";s:0:\"\";s:14:\"sfsi_email_url\";s:21:\"https://follow.it/now\";s:24:\"sfsi_facebookPage_option\";s:3:\"yes\";s:21:\"sfsi_facebookPage_url\";s:25:\"http://www.facebook.com/#\";s:24:\"sfsi_facebookLike_option\";s:2:\"no\";s:25:\"sfsi_facebookShare_option\";s:2:\"no\";s:21:\"sfsi_twitter_followme\";s:2:\"no\";s:27:\"sfsi_twitter_followUserName\";s:0:\"\";s:22:\"sfsi_twitter_aboutPage\";s:2:\"no\";s:17:\"sfsi_twitter_page\";s:3:\"yes\";s:20:\"sfsi_twitter_pageURL\";s:24:\"http://www.twitter.com/#\";s:26:\"sfsi_twitter_aboutPageText\";s:82:\"Hey, check out this cool site I found: www.yourname.com #Topic via@my_twitter_name\";s:20:\"sfsi_youtube_pageUrl\";s:24:\"http://www.youtube.com/#\";s:17:\"sfsi_youtube_page\";s:3:\"yes\";s:19:\"sfsi_youtube_follow\";s:2:\"no\";s:24:\"sfsi_youtubeusernameorid\";s:0:\"\";s:15:\"sfsi_ytube_user\";s:0:\"\";s:17:\"sfsi_ytube_chnlid\";s:0:\"\";s:19:\"sfsi_pinterest_page\";s:0:\"\";s:22:\"sfsi_pinterest_pageUrl\";s:0:\"\";s:23:\"sfsi_pinterest_pingBlog\";s:0:\"\";s:22:\"sfsi_instagram_pageUrl\";s:0:\"\";s:18:\"sfsi_linkedin_page\";s:0:\"\";s:21:\"sfsi_linkedin_pageURL\";s:0:\"\";s:20:\"sfsi_linkedin_follow\";s:0:\"\";s:27:\"sfsi_linkedin_followCompany\";i:0;s:23:\"sfsi_linkedin_SharePage\";s:0:\"\";s:30:\"sfsi_linkedin_recommendBusines\";s:2:\"no\";s:30:\"sfsi_linkedin_recommendCompany\";s:0:\"\";s:32:\"sfsi_linkedin_recommendProductId\";i:0;s:21:\"sfsi_CustomIcon_links\";s:0:\"\";s:18:\"sfsi_telegram_page\";s:2:\"no\";s:21:\"sfsi_telegram_pageURL\";s:0:\"\";s:21:\"sfsi_telegram_message\";s:0:\"\";s:22:\"sfsi_telegram_username\";s:0:\"\";s:15:\"sfsi_weibo_page\";s:0:\"\";s:18:\"sfsi_weibo_pageURL\";s:0:\"\";s:12:\"sfsi_vk_page\";s:0:\"\";s:15:\"sfsi_vk_pageURL\";s:0:\"\";s:12:\"sfsi_ok_page\";s:0:\"\";s:15:\"sfsi_ok_pageURL\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("208","sfsi_section3_options","s:630:\"a:15:{s:18:\"sfsi_actvite_theme\";s:4:\"flat\";s:14:\"sfsi_mouseOver\";s:2:\"no\";s:21:\"sfsi_mouseOver_effect\";s:7:\"fade_in\";s:26:\"sfsi_mouseover_effect_type\";s:10:\"same_icons\";s:18:\"sfsi_shuffle_icons\";s:2:\"no\";s:22:\"sfsi_shuffle_Firstload\";s:2:\"no\";s:21:\"sfsi_shuffle_interval\";s:2:\"no\";s:25:\"sfsi_shuffle_intervalTime\";i:0;s:26:\"sfsi_specialIcon_animation\";s:0:\"\";s:26:\"sfsi_specialIcon_MouseOver\";s:2:\"no\";s:26:\"sfsi_specialIcon_Firstload\";s:2:\"no\";s:32:\"sfsi_specialIcon_Firstload_Icons\";s:3:\"all\";s:25:\"sfsi_specialIcon_interval\";s:2:\"no\";s:29:\"sfsi_specialIcon_intervalTime\";s:0:\"\";s:30:\"sfsi_specialIcon_intervalIcons\";s:3:\"all\";}\";","yes");
INSERT INTO `wp_options` VALUES("209","sfsi_section4_options","s:2267:\"a:57:{s:19:\"sfsi_display_counts\";s:2:\"no\";s:24:\"sfsi_email_countsDisplay\";s:2:\"no\";s:21:\"sfsi_email_countsFrom\";s:6:\"source\";s:23:\"sfsi_email_manualCounts\";s:2:\"20\";s:22:\"sfsi_rss_countsDisplay\";s:2:\"no\";s:21:\"sfsi_rss_manualCounts\";s:2:\"20\";s:22:\"sfsi_facebook_PageLink\";s:0:\"\";s:27:\"sfsi_facebook_countsDisplay\";s:2:\"no\";s:24:\"sfsi_facebook_countsFrom\";s:6:\"manual\";s:26:\"sfsi_facebook_manualCounts\";s:2:\"20\";s:26:\"sfsi_twitter_countsDisplay\";s:2:\"no\";s:23:\"sfsi_twitter_countsFrom\";s:6:\"manual\";s:25:\"sfsi_twitter_manualCounts\";s:2:\"20\";s:27:\"sfsi_linkedIn_countsDisplay\";s:2:\"no\";s:24:\"sfsi_linkedIn_countsFrom\";s:6:\"manual\";s:26:\"sfsi_linkedIn_manualCounts\";s:2:\"20\";s:27:\"sfsi_telegram_countsDisplay\";s:2:\"no\";s:24:\"sfsi_telegram_countsFrom\";s:6:\"manual\";s:26:\"sfsi_telegram_manualCounts\";s:2:\"20\";s:21:\"sfsi_vk_countsDisplay\";s:2:\"no\";s:18:\"sfsi_vk_countsFrom\";s:6:\"manual\";s:20:\"sfsi_vk_manualCounts\";s:2:\"20\";s:21:\"sfsi_ok_countsDisplay\";s:2:\"no\";s:18:\"sfsi_ok_countsFrom\";s:6:\"manual\";s:20:\"sfsi_ok_manualCounts\";s:2:\"20\";s:24:\"sfsi_weibo_countsDisplay\";s:2:\"no\";s:21:\"sfsi_weibo_countsFrom\";s:6:\"manual\";s:23:\"sfsi_weibo_manualCounts\";s:2:\"20\";s:17:\"sfsi_round_counts\";s:3:\"yes\";s:20:\"sfsi_original_counts\";s:3:\"yes\";s:27:\"sfsi_responsive_share_count\";s:3:\"yes\";s:25:\"sfsi_wechat_countsDisplay\";s:2:\"no\";s:22:\"sfsi_wechat_countsFrom\";s:6:\"manual\";s:24:\"sfsi_wechat_manualCounts\";s:2:\"20\";s:10:\"ln_api_key\";s:0:\"\";s:13:\"ln_secret_key\";s:0:\"\";s:19:\"ln_oAuth_user_token\";s:0:\"\";s:10:\"ln_company\";s:0:\"\";s:24:\"sfsi_youtubeusernameorid\";s:4:\"name\";s:17:\"sfsi_youtube_user\";s:0:\"\";s:22:\"sfsi_youtube_channelId\";s:0:\"\";s:17:\"sfsi_ytube_chnlid\";s:0:\"\";s:26:\"sfsi_youtube_countsDisplay\";s:2:\"no\";s:23:\"sfsi_youtube_countsFrom\";s:6:\"manual\";s:25:\"sfsi_youtube_manualCounts\";s:2:\"20\";s:28:\"sfsi_pinterest_countsDisplay\";s:2:\"no\";s:25:\"sfsi_pinterest_countsFrom\";s:6:\"manual\";s:27:\"sfsi_pinterest_manualCounts\";s:2:\"20\";s:19:\"sfsi_pinterest_user\";s:0:\"\";s:20:\"sfsi_pinterest_board\";s:0:\"\";s:25:\"sfsi_instagram_countsFrom\";s:6:\"manual\";s:28:\"sfsi_instagram_countsDisplay\";s:2:\"no\";s:27:\"sfsi_instagram_manualCounts\";s:2:\"20\";s:19:\"sfsi_instagram_User\";s:0:\"\";s:23:\"sfsi_instagram_clientid\";s:0:\"\";s:21:\"sfsi_instagram_appurl\";s:0:\"\";s:20:\"sfsi_instagram_token\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("210","sfsi_section5_options","s:1631:\"a:39:{s:15:\"sfsi_icons_size\";s:2:\"40\";s:18:\"sfsi_icons_spacing\";s:1:\"5\";s:20:\"sfsi_icons_Alignment\";s:4:\"left\";s:31:\"sfsi_icons_Alignment_via_widget\";s:4:\"left\";s:34:\"sfsi_icons_Alignment_via_shortcode\";s:4:\"left\";s:17:\"sfsi_icons_perRow\";s:1:\"5\";s:24:\"sfsi_icons_ClickPageOpen\";s:3:\"yes\";s:26:\"sfsi_icons_suppress_errors\";s:2:\"no\";s:16:\"sfsi_icons_stick\";s:2:\"no\";s:18:\"sfsi_rssIcon_order\";s:1:\"1\";s:20:\"sfsi_emailIcon_order\";s:1:\"2\";s:23:\"sfsi_facebookIcon_order\";s:1:\"3\";s:22:\"sfsi_twitterIcon_order\";s:1:\"4\";s:22:\"sfsi_youtubeIcon_order\";s:1:\"5\";s:24:\"sfsi_pinterestIcon_order\";s:1:\"7\";s:23:\"sfsi_linkedinIcon_order\";s:1:\"8\";s:24:\"sfsi_instagramIcon_order\";s:1:\"9\";s:23:\"sfsi_telegramIcon_order\";s:2:\"11\";s:17:\"sfsi_vkIcon_order\";s:2:\"12\";s:17:\"sfsi_okIcon_order\";s:2:\"13\";s:20:\"sfsi_weiboIcon_order\";s:2:\"14\";s:21:\"sfsi_wechatIcon_order\";s:2:\"15\";s:22:\"sfsi_CustomIcons_order\";s:0:\"\";s:22:\"sfsi_rss_MouseOverText\";s:3:\"RSS\";s:24:\"sfsi_email_MouseOverText\";s:15:\"Follow by Email\";s:26:\"sfsi_twitter_MouseOverText\";s:7:\"Twitter\";s:27:\"sfsi_facebook_MouseOverText\";s:8:\"Facebook\";s:27:\"sfsi_linkedIn_MouseOverText\";s:8:\"LinkedIn\";s:28:\"sfsi_pinterest_MouseOverText\";s:9:\"Pinterest\";s:28:\"sfsi_instagram_MouseOverText\";s:9:\"Instagram\";s:26:\"sfsi_youtube_MouseOverText\";s:7:\"YouTube\";s:27:\"sfsi_telegram_MouseOverText\";s:8:\"Telegram\";s:21:\"sfsi_vk_MouseOverText\";s:2:\"VK\";s:21:\"sfsi_ok_MouseOverText\";s:2:\"OK\";s:24:\"sfsi_weibo_MouseOverText\";s:5:\"Weibo\";s:25:\"sfsi_wechat_MouseOverText\";s:6:\"WeChat\";s:26:\"sfsi_custom_MouseOverTexts\";s:0:\"\";s:23:\"sfsi_custom_social_hide\";s:2:\"no\";s:32:\"sfsi_pplus_icons_suppress_errors\";s:2:\"no\";}\";","yes");
INSERT INTO `wp_options` VALUES("211","sfsi_section6_options","s:1233:\"a:12:{s:17:\"sfsi_show_Onposts\";s:2:\"no\";s:22:\"sfsi_icons_postPositon\";s:0:\"\";s:20:\"sfsi_icons_alignment\";s:4:\"left\";s:20:\"sfsi_textBefor_icons\";s:26:\"Please follow and like us:\";s:12:\"sfsi_rectsub\";s:3:\"yes\";s:11:\"sfsi_rectfb\";s:3:\"yes\";s:12:\"sfsi_rectshr\";s:2:\"no\";s:13:\"sfsi_recttwtr\";s:3:\"yes\";s:14:\"sfsi_rectpinit\";s:3:\"yes\";s:16:\"sfsi_rectfbshare\";s:3:\"yes\";s:21:\"sfsi_responsive_icons\";a:3:{s:13:\"default_icons\";a:3:{s:8:\"facebook\";a:3:{s:6:\"active\";s:3:\"yes\";s:4:\"text\";s:17:\"Share on Facebook\";s:3:\"url\";s:0:\"\";}s:7:\"Twitter\";a:3:{s:6:\"active\";s:3:\"yes\";s:4:\"text\";s:5:\"Tweet\";s:3:\"url\";s:0:\"\";}s:6:\"Follow\";a:3:{s:6:\"active\";s:3:\"yes\";s:4:\"text\";s:9:\"Follow us\";s:3:\"url\";s:0:\"\";}}s:8:\"settings\";a:14:{s:9:\"icon_size\";s:6:\"Medium\";s:15:\"icon_width_type\";s:16:\"Fully responsive\";s:15:\"icon_width_size\";s:3:\"240\";s:9:\"edge_type\";s:5:\"Round\";s:11:\"edge_radius\";s:1:\"5\";s:5:\"style\";s:8:\"Gradient\";s:6:\"margin\";s:2:\"10\";s:10:\"text_align\";s:8:\"Centered\";s:12:\"margin_above\";s:1:\"0\";s:12:\"margin_below\";s:1:\"0\";s:10:\"show_count\";s:2:\"no\";s:13:\"counter_color\";s:7:\"#aaaaaa\";s:16:\"counter_bg_color\";s:4:\"#fff\";s:16:\"share_count_text\";s:6:\"SHARES\";}s:12:\"custom_icons\";a:0:{}}s:24:\"sfsi_display_button_type\";s:17:\"responsive_button\";}\";","yes");
INSERT INTO `wp_options` VALUES("212","sfsi_section7_options","s:666:\"a:15:{s:15:\"sfsi_show_popup\";s:2:\"no\";s:15:\"sfsi_popup_text\";s:42:\"Enjoy this blog? Please spread the word :)\";s:27:\"sfsi_popup_background_color\";s:7:\"#eff7f7\";s:23:\"sfsi_popup_border_color\";s:7:\"#f3faf2\";s:27:\"sfsi_popup_border_thickness\";s:1:\"1\";s:24:\"sfsi_popup_border_shadow\";s:3:\"yes\";s:15:\"sfsi_popup_font\";s:26:\"Helvetica,Arial,sans-serif\";s:19:\"sfsi_popup_fontSize\";s:2:\"30\";s:20:\"sfsi_popup_fontStyle\";s:6:\"normal\";s:20:\"sfsi_popup_fontColor\";s:7:\"#000000\";s:17:\"sfsi_Show_popupOn\";s:4:\"none\";s:25:\"sfsi_Show_popupOn_PageIDs\";s:0:\"\";s:14:\"sfsi_Shown_pop\";s:8:\"ETscroll\";s:24:\"sfsi_Shown_popupOnceTime\";s:0:\"\";s:32:\"sfsi_Shown_popuplimitPerUserTime\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("213","sfsi_section8_options","s:1208:\"a:26:{s:20:\"sfsi_form_adjustment\";s:3:\"yes\";s:16:\"sfsi_form_height\";s:3:\"180\";s:15:\"sfsi_form_width\";s:3:\"230\";s:16:\"sfsi_form_border\";s:2:\"no\";s:26:\"sfsi_form_border_thickness\";s:1:\"1\";s:22:\"sfsi_form_border_color\";s:7:\"#b5b5b5\";s:20:\"sfsi_form_background\";s:7:\"#ffffff\";s:22:\"sfsi_form_heading_text\";s:22:\"Get new posts by email\";s:22:\"sfsi_form_heading_font\";s:26:\"Helvetica,Arial,sans-serif\";s:27:\"sfsi_form_heading_fontstyle\";s:4:\"bold\";s:27:\"sfsi_form_heading_fontcolor\";s:7:\"#000000\";s:26:\"sfsi_form_heading_fontsize\";s:2:\"16\";s:27:\"sfsi_form_heading_fontalign\";s:6:\"center\";s:20:\"sfsi_form_field_text\";s:9:\"Subscribe\";s:20:\"sfsi_form_field_font\";s:26:\"Helvetica,Arial,sans-serif\";s:25:\"sfsi_form_field_fontstyle\";s:6:\"normal\";s:25:\"sfsi_form_field_fontcolor\";s:7:\"#000000\";s:24:\"sfsi_form_field_fontsize\";s:2:\"14\";s:25:\"sfsi_form_field_fontalign\";s:6:\"center\";s:21:\"sfsi_form_button_text\";s:9:\"Subscribe\";s:21:\"sfsi_form_button_font\";s:26:\"Helvetica,Arial,sans-serif\";s:26:\"sfsi_form_button_fontstyle\";s:4:\"bold\";s:26:\"sfsi_form_button_fontcolor\";s:7:\"#000000\";s:25:\"sfsi_form_button_fontsize\";s:2:\"16\";s:26:\"sfsi_form_button_fontalign\";s:6:\"center\";s:27:\"sfsi_form_button_background\";s:7:\"#dedede\";}\";","yes");
INSERT INTO `wp_options` VALUES("214","sfsi_section9_options","s:409:\"a:10:{s:20:\"sfsi_show_via_widget\";s:2:\"no\";s:16:\"sfsi_icons_float\";s:2:\"no\";s:24:\"sfsi_icons_floatPosition\";s:12:\"center-right\";s:26:\"sfsi_icons_floatMargin_top\";i:0;s:29:\"sfsi_icons_floatMargin_bottom\";i:0;s:27:\"sfsi_icons_floatMargin_left\";i:0;s:28:\"sfsi_icons_floatMargin_right\";i:0;s:23:\"sfsi_disable_floaticons\";s:2:\"no\";s:23:\"sfsi_show_via_shortcode\";s:3:\"yes\";s:24:\"sfsi_show_via_afterposts\";s:2:\"no\";}\";","yes");
INSERT INTO `wp_options` VALUES("215","sfsi_feed_id","","yes");
INSERT INTO `wp_options` VALUES("216","sfsi_redirect_url","https://follow.it/now","yes");
INSERT INTO `wp_options` VALUES("217","sfsi_installDate","2020-08-07 08:02:39","yes");
INSERT INTO `wp_options` VALUES("218","sfsi_currentDate","2020-08-07 08:02:39","yes");
INSERT INTO `wp_options` VALUES("219","sfsi_showNextBannerDate","21 day","yes");
INSERT INTO `wp_options` VALUES("220","sfsi_cycleDate","180 day","yes");
INSERT INTO `wp_options` VALUES("221","sfsi_loyaltyDate","180 day","yes");
INSERT INTO `wp_options` VALUES("222","sfsi_RatingDiv","no","yes");
INSERT INTO `wp_options` VALUES("223","sfsi_footer_sec","no","yes");
INSERT INTO `wp_options` VALUES("224","sfsi_activate","0","yes");
INSERT INTO `wp_options` VALUES("225","sfsi_dismiss_sharecount","s:58:\"a:2:{s:11:\"show_banner\";s:3:\"yes\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("226","sfsi_dismiss_google_analytic","s:63:\"a:2:{s:11:\"show_banner\";s:2:\"no\";s:9:\"timestamp\";i:1596789968;}\";","yes");
INSERT INTO `wp_options` VALUES("227","sfsi_banner_global_firsttime_offer","s:104:\"a:3:{s:12:\"met_criteria\";s:3:\"yes\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:19:\"2020-08-07 08:09:03\";}\";","yes");
INSERT INTO `wp_options` VALUES("228","sfsi_dismiss_gdpr","s:58:\"a:2:{s:11:\"show_banner\";s:3:\"yes\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("229","sfsi_dismiss_optimization","s:58:\"a:2:{s:11:\"show_banner\";s:3:\"yes\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("230","sfsi_dismiss_gallery","s:58:\"a:2:{s:11:\"show_banner\";s:3:\"yes\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("231","sfsi_banner_global_upgrade","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("232","sfsi_banner_global_http","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("233","sfsi_banner_global_gdpr","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("234","sfsi_banner_global_shares","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("235","sfsi_banner_global_load_faster","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("236","sfsi_banner_global_social","s:115:\"a:4:{s:12:\"met_criteria\";s:2:\"no\";s:15:\"banner_appeared\";s:2:\"no\";s:9:\"is_active\";s:2:\"no\";s:9:\"timestamp\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("237","sfsi_banner_global_pinterest","s:138:\"a:4:{s:12:\"met_criteria\";s:3:\"yes\";s:15:\"banner_appeared\";s:3:\"yes\";s:9:\"is_active\";s:3:\"yes\";s:9:\"timestamp\";s:19:\"2020-08-28 08:09:04\";}\";","yes");
INSERT INTO `wp_options` VALUES("238","sfsi_instagram_sf_count","s:126:\"a:4:{s:7:\"date_sf\";i:1596758400;s:14:\"date_instagram\";s:0:\"\";s:13:\"sfsi_sf_count\";s:1:\"O\";s:20:\"sfsi_instagram_count\";s:0:\"\";}\";","yes");
INSERT INTO `wp_options` VALUES("239","sfsi_error_reporting_notice_dismissed","1","yes");
INSERT INTO `wp_options` VALUES("240","sfsi_fb_count","","yes");
INSERT INTO `wp_options` VALUES("241","adding_tags","no","yes");
INSERT INTO `wp_options` VALUES("242","widget_sfsi-widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("243","widget_subscriber_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("244","sfsi_pluginVersion","2.58","yes");
INSERT INTO `wp_options` VALUES("245","sfsi_serverphpVersionnotification","yes","yes");
INSERT INTO `wp_options` VALUES("246","show_premium_notification","yes","yes");
INSERT INTO `wp_options` VALUES("247","show_notification","yes","yes");
INSERT INTO `wp_options` VALUES("248","sfsi_pplus_error_reporting_notice_dismissed","1","yes");
INSERT INTO `wp_options` VALUES("249","sfsi_addThis_icon_removal_notice_dismissed","1","yes");
INSERT INTO `wp_options` VALUES("251","_transient_is_multi_author","0","yes");
INSERT INTO `wp_options` VALUES("253","_site_transient_timeout_theme_roots","1596791740","no");
INSERT INTO `wp_options` VALUES("254","_site_transient_theme_roots","a:6:{s:7:\"skyloft\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:20:\"wp-bootstrap-starter\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("256","aioseop_options","a:84:{s:17:\"aiosp_license_key\";s:0:\"\";s:16:\"aiosp_home_title\";s:44:\"Skyloft Climbing Park - For your excitement!\";s:22:\"aiosp_home_description\";s:108:\"Tension, nerve kitzel, an ultimate outdoor experience at dizzy heights awaits you in our high-ropes skyloft.\";s:20:\"aiosp_togglekeywords\";s:1:\"1\";s:19:\"aiosp_home_keywords\";s:0:\"\";s:26:\"aiosp_use_static_home_info\";s:1:\"0\";s:9:\"aiosp_can\";s:2:\"on\";s:30:\"aiosp_no_paged_canonical_links\";s:2:\"on\";s:20:\"aiosp_force_rewrites\";s:1:\"1\";s:24:\"aiosp_use_original_title\";s:1:\"1\";s:28:\"aiosp_home_page_title_format\";s:12:\"%page_title%\";s:23:\"aiosp_page_title_format\";s:27:\"%page_title% | %site_title%\";s:23:\"aiosp_post_title_format\";s:27:\"%post_title% | %site_title%\";s:27:\"aiosp_category_title_format\";s:31:\"%category_title% | %site_title%\";s:26:\"aiosp_archive_title_format\";s:30:\"%archive_title% | %site_title%\";s:23:\"aiosp_date_title_format\";s:21:\"%date% | %site_title%\";s:25:\"aiosp_author_title_format\";s:23:\"%author% | %site_title%\";s:22:\"aiosp_tag_title_format\";s:20:\"%tag% | %site_title%\";s:25:\"aiosp_search_title_format\";s:23:\"%search% | %site_title%\";s:24:\"aiosp_description_format\";s:13:\"%description%\";s:22:\"aiosp_404_title_format\";s:33:\"Nothing found for %request_words%\";s:18:\"aiosp_paged_format\";s:14:\" - Part %page%\";s:17:\"aiosp_cpostactive\";a:2:{i:0;s:4:\"page\";i:1;s:10:\"attachment\";}s:18:\"aiosp_cpostnoindex\";a:5:{i:0;s:4:\"post\";i:1;s:12:\"oembed_cache\";i:2;s:12:\"user_request\";i:3;s:8:\"wp_block\";i:4;s:18:\"wpcf7_contact_form\";}s:19:\"aiosp_cpostnofollow\";a:6:{i:0;s:4:\"post\";i:1;s:10:\"attachment\";i:2;s:12:\"oembed_cache\";i:3;s:12:\"user_request\";i:4;s:8:\"wp_block\";i:5;s:18:\"wpcf7_contact_form\";}s:21:\"aiosp_posttypecolumns\";a:2:{i:0;s:4:\"page\";i:1;s:10:\"attachment\";}s:19:\"aiosp_google_verify\";s:0:\"\";s:17:\"aiosp_bing_verify\";s:0:\"\";s:22:\"aiosp_pinterest_verify\";s:0:\"\";s:19:\"aiosp_yandex_verify\";s:0:\"\";s:18:\"aiosp_baidu_verify\";s:0:\"\";s:25:\"aiosp_google_analytics_id\";s:13:\"UA-54516992-1\";s:25:\"aiosp_ga_advanced_options\";s:2:\"on\";s:15:\"aiosp_ga_domain\";s:0:\"\";s:21:\"aiosp_ga_multi_domain\";s:0:\"\";s:21:\"aiosp_ga_addl_domains\";s:0:\"\";s:21:\"aiosp_ga_anonymize_ip\";s:0:\"\";s:28:\"aiosp_ga_display_advertising\";s:0:\"\";s:22:\"aiosp_ga_exclude_users\";s:0:\"\";s:29:\"aiosp_ga_track_outbound_links\";s:0:\"\";s:25:\"aiosp_ga_link_attribution\";s:0:\"\";s:27:\"aiosp_ga_enhanced_ecommerce\";s:0:\"\";s:19:\"aiosp_schema_markup\";s:1:\"1\";s:32:\"aiosp_schema_search_results_page\";s:2:\"on\";s:33:\"aiosp_schema_social_profile_links\";s:0:\"\";s:28:\"aiosp_schema_site_represents\";s:12:\"organization\";s:30:\"aiosp_schema_organization_name\";s:0:\"\";s:30:\"aiosp_schema_organization_logo\";s:0:\"\";s:24:\"aiosp_schema_person_user\";s:1:\"1\";s:31:\"aiosp_schema_person_manual_name\";s:0:\"\";s:32:\"aiosp_schema_person_manual_image\";s:0:\"\";s:25:\"aiosp_schema_phone_number\";s:0:\"\";s:25:\"aiosp_schema_contact_type\";s:4:\"none\";s:20:\"aiosp_use_categories\";s:0:\"\";s:26:\"aiosp_use_tags_as_keywords\";s:2:\"on\";s:32:\"aiosp_dynamic_postspage_keywords\";s:2:\"on\";s:22:\"aiosp_category_noindex\";s:2:\"on\";s:26:\"aiosp_archive_date_noindex\";s:2:\"on\";s:28:\"aiosp_archive_author_noindex\";s:2:\"on\";s:18:\"aiosp_tags_noindex\";s:0:\"\";s:20:\"aiosp_search_noindex\";s:2:\"on\";s:17:\"aiosp_404_noindex\";s:2:\"on\";s:17:\"aiosp_tax_noindex\";a:0:{}s:23:\"aiosp_paginated_noindex\";s:0:\"\";s:24:\"aiosp_paginated_nofollow\";s:0:\"\";s:27:\"aiosp_generate_descriptions\";s:2:\"on\";s:18:\"aiosp_skip_excerpt\";s:2:\"on\";s:20:\"aiosp_run_shortcodes\";s:0:\"\";s:33:\"aiosp_hide_paginated_descriptions\";s:0:\"\";s:32:\"aiosp_dont_truncate_descriptions\";s:0:\"\";s:20:\"aiosp_unprotect_meta\";s:0:\"\";s:33:\"aiosp_redirect_attachement_parent\";s:0:\"\";s:14:\"aiosp_ex_pages\";s:0:\"\";s:20:\"aiosp_post_meta_tags\";s:0:\"\";s:20:\"aiosp_page_meta_tags\";s:0:\"\";s:21:\"aiosp_front_meta_tags\";s:0:\"\";s:20:\"aiosp_home_meta_tags\";s:0:\"\";s:12:\"aiosp_do_log\";s:0:\"\";s:19:\"last_active_version\";s:5:\"3.6.2\";s:29:\"aiosp_attachment_title_format\";s:27:\"%post_title% | %site_title%\";s:31:\"aiosp_oembed_cache_title_format\";s:27:\"%post_title% | %site_title%\";s:31:\"aiosp_user_request_title_format\";s:27:\"%post_title% | %site_title%\";s:27:\"aiosp_wp_block_title_format\";s:27:\"%post_title% | %site_title%\";s:37:\"aiosp_wpcf7_contact_form_title_format\";s:27:\"%post_title% | %site_title%\";}","yes");
INSERT INTO `wp_options` VALUES("257","_transient_timeout_aiosp_sitemap_rules_flushed","1596833145","no");
INSERT INTO `wp_options` VALUES("258","_transient_aiosp_sitemap_rules_flushed","1","no");
INSERT INTO `wp_options` VALUES("259","aioseop_notices","a:4:{s:7:\"notices\";a:2:{s:20:\"blog_public_disabled\";a:3:{s:4:\"slug\";s:20:\"blog_public_disabled\";s:10:\"time_start\";i:1597394762;s:8:\"time_set\";i:1596789963;}s:17:\"review_plugin_cta\";a:3:{s:4:\"slug\";s:17:\"review_plugin_cta\";s:10:\"time_start\";i:1597999544;s:8:\"time_set\";i:1596789945;}}s:14:\"remote_notices\";a:0:{}s:14:\"active_notices\";a:2:{s:20:\"blog_public_disabled\";i:1597394762;s:17:\"review_plugin_cta\";i:1597999544;}s:17:\"dismissed_notices\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("260","aioseop_detected_conflicting_plugins","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("263","_site_transient_timeout_aioseop_update_check_time","1596811550","no");
INSERT INTO `wp_options` VALUES("264","_site_transient_aioseop_update_check_time","1596789950","no");
INSERT INTO `wp_options` VALUES("267","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1596790268;s:7:\"checked\";a:6:{s:19:\"akismet/akismet.php\";s:5:\"4.1.6\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:5:\"3.6.2\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.4\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.2.1\";s:33:\"smart-slider-3/smart-slider-3.php\";s:7:\"3.4.1.8\";s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";s:5:\"2.5.8\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:6:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.6\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/all-in-one-seo-pack\";s:4:\"slug\";s:19:\"all-in-one-seo-pack\";s:6:\"plugin\";s:43:\"all-in-one-seo-pack/all_in_one_seo_pack.php\";s:11:\"new_version\";s:5:\"3.6.2\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/all-in-one-seo-pack/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/all-in-one-seo-pack.3.6.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/all-in-one-seo-pack/assets/icon-256x256.png?rev=2075006\";s:2:\"1x\";s:72:\"https://ps.w.org/all-in-one-seo-pack/assets/icon-128x128.png?rev=2075006\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-1544x500.png?rev=1354894\";s:2:\"1x\";s:74:\"https://ps.w.org/all-in-one-seo-pack/assets/banner-772x250.png?rev=1354894\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.4\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.2.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.2.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=2279696\";s:2:\"1x\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";s:3:\"svg\";s:59:\"https://ps.w.org/contact-form-7/assets/icon.svg?rev=2339255\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"smart-slider-3/smart-slider-3.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/smart-slider-3\";s:4:\"slug\";s:14:\"smart-slider-3\";s:6:\"plugin\";s:33:\"smart-slider-3/smart-slider-3.php\";s:11:\"new_version\";s:7:\"3.4.1.8\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/smart-slider-3/\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/plugin/smart-slider-3.3.4.1.8.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/smart-slider-3/assets/icon-256x256.png?rev=2307688\";s:2:\"1x\";s:59:\"https://ps.w.org/smart-slider-3/assets/icon.svg?rev=2307688\";s:3:\"svg\";s:59:\"https://ps.w.org/smart-slider-3/assets/icon.svg?rev=2307688\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/smart-slider-3/assets/banner-1544x500.png?rev=2307688\";s:2:\"1x\";s:69:\"https://ps.w.org/smart-slider-3/assets/banner-772x250.png?rev=2307688\";}s:11:\"banners_rtl\";a:0:{}}s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:41:\"w.org/plugins/ultimate-social-media-icons\";s:4:\"slug\";s:27:\"ultimate-social-media-icons\";s:6:\"plugin\";s:59:\"ultimate-social-media-icons/ultimate_social_media_icons.php\";s:11:\"new_version\";s:5:\"2.5.8\";s:3:\"url\";s:58:\"https://wordpress.org/plugins/ultimate-social-media-icons/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/ultimate-social-media-icons.2.5.8.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:80:\"https://ps.w.org/ultimate-social-media-icons/assets/icon-128x128.png?rev=2228479\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:82:\"https://ps.w.org/ultimate-social-media-icons/assets/banner-772x250.png?rev=2230335\";}s:11:\"banners_rtl\";a:0:{}}}}","no");
INSERT INTO `wp_options` VALUES("268","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("269","aio_wp_security_configs","a:92:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:0:\"\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:0:\"\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";s:1:\"3\";s:24:\"aiowps_retry_time_period\";s:1:\"5\";s:26:\"aiowps_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:19:\"skyloft@example.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"r3g6wpw1ysgawu527v5m\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"4296vbctkuame07st7na\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:19:\"skyloft@example.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:27:\"aiowps_max_file_upload_size\";s:2:\"10\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:19:\"skyloft@example.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("270","_transient_timeout_users_online","1596792069","no");
INSERT INTO `wp_options` VALUES("271","_transient_users_online","a:1:{i:0;a:4:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1596790269;s:10:\"ip_address\";s:3:\"::1\";s:7:\"blog_id\";b:0;}}","no");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_edit_lock","1596788026:1");
INSERT INTO `wp_postmeta` VALUES("4","6","_wp_attached_file","2020/08/Bild_17.jpg");
INSERT INTO `wp_postmeta` VALUES("5","6","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:19:\"2020/08/Bild_17.jpg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Bild_17-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Bild_17-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Bild_17-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Bild_17-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"Bild_17-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:21:\"Bild_17-2048x1366.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_17-1200x800.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:21:\"Bild_17-1980x1320.jpg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"16\";s:6:\"credit\";s:14:\"manu - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 400D DIGITAL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1187055034\";s:9:\"copyright\";s:14:\"manu - Fotolia\";s:12:\"focal_length\";s:2:\"95\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:16:\"klettern - seile\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:19:{i:0;s:8:\"klettern\";i:1;s:7:\"spielen\";i:2;s:10:\"spielplatz\";i:3;s:7:\"motorik\";i:4;s:8:\"bewegung\";i:5;s:5:\"aktiv\";i:6;s:6:\"urlaub\";i:7;s:8:\"freizeit\";i:8;s:5:\"spaß\";i:9;s:11:\"kinderspiel\";i:10;s:14:\"klettergerüst\";i:11;s:12:\"kindergarten\";i:12;s:7:\"bewegen\";i:13;s:9:\"motorisch\";i:14;s:4:\"seil\";i:15;s:4:\"bunt\";i:16;s:12:\"hochklettern\";i:17;s:6:\"turnen\";i:18;s:10:\"turngerät\";}}}");
INSERT INTO `wp_postmeta` VALUES("6","5","_thumbnail_id","25");
INSERT INTO `wp_postmeta` VALUES("7","8","_edit_lock","1596790292:1");
INSERT INTO `wp_postmeta` VALUES("8","9","_wp_attached_file","2020/08/Bild_08.jpg");
INSERT INTO `wp_postmeta` VALUES("9","9","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1574;s:6:\"height\";i:2351;s:4:\"file\";s:19:\"2020/08/Bild_08.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Bild_08-201x300.jpg\";s:5:\"width\";i:201;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Bild_08-686x1024.jpg\";s:5:\"width\";i:686;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Bild_08-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_08-768x1147.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1147;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"Bild_08-1028x1536.jpg\";s:5:\"width\";i:1028;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:21:\"Bild_08-1371x2048.jpg\";s:5:\"width\";i:1371;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_08-1200x1792.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:1792;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:18:\"dudadidi - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1245352135\";s:9:\"copyright\";s:18:\"dudadidi - Fotolia\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:6:\"0.0008\";s:5:\"title\";s:12:\"Seilklettern\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:14:{i:0;s:8:\"klettern\";i:1;s:12:\"seilklettern\";i:2;s:11:\"bergsteigen\";i:3;s:11:\"kletterwald\";i:4;s:4:\"seil\";i:5;s:4:\"frau\";i:6;s:9:\"abenteuer\";i:7;s:5:\"sport\";i:8;s:8:\"freizeit\";i:9;s:10:\"sicherheit\";i:10;s:6:\"wolken\";i:11;s:6:\"himmel\";i:12;s:5:\"natur\";i:13;s:4:\"blau\";}}}");
INSERT INTO `wp_postmeta` VALUES("10","10","_wp_attached_file","2020/08/Bild_21-scaled.jpg");
INSERT INTO `wp_postmeta` VALUES("11","10","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1714;s:4:\"file\";s:26:\"2020/08/Bild_21-scaled.jpg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Bild_21-300x201.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Bild_21-1024x685.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Bild_21-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Bild_21-768x514.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"Bild_21-1536x1028.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:21:\"Bild_21-2048x1371.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1371;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_21-1200x803.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:803;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:21:\"Bild_21-1980x1325.jpg\";s:5:\"width\";i:1980;s:6:\"height\";i:1325;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.7\";s:6:\"credit\";s:14:\"Tony - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:52:\"Two girls preparing for a jump high above the ground\";s:17:\"created_timestamp\";s:10:\"1161965337\";s:9:\"copyright\";s:14:\"Tony - Fotolia\";s:12:\"focal_length\";s:2:\"70\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:28:\"preparing for the risky jump\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:52:{i:0;s:62:\"girls, risk, sport, game, play, climbing, climb, rope, safety,\";i:1;s:288:\"tree, gear, jump, dare, prepare, preparing, for, a, jump, high, above, the, ground, climber, exercise, fitness, effort, empowerment, health,  inspiration, inspiring, blue, sky, space for text, sport, strength, hang, hanging, amusement, amusement park, entertainment, help, help each other\";i:2;s:5:\"girls\";i:3;s:4:\"risk\";i:4;s:5:\"sport\";i:5;s:4:\"game\";i:6;s:4:\"play\";i:7;s:8:\"climbing\";i:8;s:5:\"climb\";i:9;s:4:\"rope\";i:10;s:6:\"safety\";i:11;s:4:\"tree\";i:12;s:4:\"gear\";i:13;s:4:\"jump\";i:14;s:4:\"dare\";i:15;s:7:\"prepare\";i:16;s:9:\"preparing\";i:17;s:3:\"for\";i:18;s:4:\"high\";i:19;s:5:\"above\";i:20;s:3:\"the\";i:21;s:6:\"ground\";i:22;s:7:\"climber\";i:23;s:8:\"exercise\";i:24;s:7:\"fitness\";i:25;s:6:\"effort\";i:26;s:11:\"empowerment\";i:27;s:6:\"health\";i:28;s:11:\"inspiration\";i:29;s:9:\"inspiring\";i:30;s:4:\"blue\";i:31;s:3:\"sky\";i:32;s:14:\"space for text\";i:33;s:8:\"strength\";i:34;s:4:\"hang\";i:35;s:7:\"hanging\";i:36;s:9:\"amusement\";i:37;s:14:\"amusement park\";i:38;s:13:\"entertainment\";i:39;s:4:\"help\";i:40;s:15:\"help each other\";i:41;s:7:\"helping\";i:42;s:4:\"hand\";i:43;s:5:\"hands\";i:44;s:4:\"hold\";i:45;s:7:\"holding\";i:46;s:6:\"scared\";i:47;s:5:\"scary\";i:48;s:6:\"breath\";i:49;s:6:\"taking\";i:50;s:6:\"secure\";i:51;s:7:\"secured\";}}s:14:\"original_image\";s:11:\"Bild_21.jpg\";}");
INSERT INTO `wp_postmeta` VALUES("12","12","_wp_attached_file","2020/08/Bild_15.jpg");
INSERT INTO `wp_postmeta` VALUES("13","12","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1568;s:6:\"height\";i:2360;s:4:\"file\";s:19:\"2020/08/Bild_15.jpg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Bild_15-199x300.jpg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Bild_15-680x1024.jpg\";s:5:\"width\";i:680;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Bild_15-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_15-768x1156.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1156;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"Bild_15-1021x1536.jpg\";s:5:\"width\";i:1021;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:21:\"Bild_15-1361x2048.jpg\";s:5:\"width\";i:1361;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_15-1200x1806.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:1806;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"NIKON D300\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1262449657\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"60\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("14","13","_wp_attached_file","2020/08/Bild_19.jpg");
INSERT INTO `wp_postmeta` VALUES("15","13","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:19:\"2020/08/Bild_19.jpg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"Bild_19-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"Bild_19-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"Bild_19-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"Bild_19-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:21:\"Bild_19-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:21:\"Bild_19-2048x1366.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_19-1200x800.jpg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:21:\"Bild_19-1980x1320.jpg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:22:\"Tino Hemmann - Fotolia\";s:6:\"camera\";s:9:\"DSLR-A700\";s:7:\"caption\";s:13:\"kleiner Pirat\";s:17:\"created_timestamp\";s:10:\"1217928805\";s:9:\"copyright\";s:22:\"Tino Hemmann - Fotolia\";s:12:\"focal_length\";s:2:\"45\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:8:\"0.003125\";s:5:\"title\";s:13:\"kleiner Pirat\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:21:{i:0;s:7:\"piraten\";i:1;s:3:\"boy\";i:2;s:6:\"sommer\";i:3;s:4:\"frei\";i:4;s:4:\"meer\";i:5;s:6:\"wasser\";i:6;s:4:\"blau\";i:7;s:8:\"horizont\";i:8;s:6:\"himmel\";i:9;s:5:\"sonne\";i:10;s:4:\"warm\";i:11;s:6:\"urlaub\";i:12;s:6:\"schiff\";i:13;s:8:\"seefahrt\";i:14;s:9:\"abenteuer\";i:15;s:5:\"junge\";i:16;s:4:\"kind\";i:17;s:4:\"seil\";i:18;s:8:\"takelage\";i:19;s:5:\"segel\";i:20;s:8:\"klettern\";}}}");
INSERT INTO `wp_postmeta` VALUES("16","16","_edit_lock","1596782487:1");
INSERT INTO `wp_postmeta` VALUES("17","19","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_08.jpeg");
INSERT INTO `wp_postmeta` VALUES("18","19","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1574;s:6:\"height\";i:2351;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_08.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_08-201x300.jpeg\";s:5:\"width\";i:201;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_08-686x1024.jpeg\";s:5:\"width\";i:686;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_08-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_08-768x1147.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1147;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_08-1028x1536.jpeg\";s:5:\"width\";i:1028;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_08-1371x2048.jpeg\";s:5:\"width\";i:1371;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_08-1200x1792.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1792;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:18:\"dudadidi - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1245352135\";s:9:\"copyright\";s:18:\"dudadidi - Fotolia\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:6:\"0.0008\";s:5:\"title\";s:12:\"Seilklettern\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:14:{i:0;s:8:\"klettern\";i:1;s:12:\"seilklettern\";i:2;s:11:\"bergsteigen\";i:3;s:11:\"kletterwald\";i:4;s:4:\"seil\";i:5;s:4:\"frau\";i:6;s:9:\"abenteuer\";i:7;s:5:\"sport\";i:8;s:8:\"freizeit\";i:9;s:10:\"sicherheit\";i:10;s:6:\"wolken\";i:11;s:6:\"himmel\";i:12;s:5:\"natur\";i:13;s:4:\"blau\";}}}");
INSERT INTO `wp_postmeta` VALUES("19","20","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_07.jpeg");
INSERT INTO `wp_postmeta` VALUES("20","20","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1574;s:6:\"height\";i:2351;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_07.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_07-201x300.jpeg\";s:5:\"width\";i:201;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_07-686x1024.jpeg\";s:5:\"width\";i:686;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_07-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_07-768x1147.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1147;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_07-1028x1536.jpeg\";s:5:\"width\";i:1028;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_07-1371x2048.jpeg\";s:5:\"width\";i:1371;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_07-1200x1792.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1792;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:18:\"dudadidi - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1268660631\";s:9:\"copyright\";s:18:\"dudadidi - Fotolia\";s:12:\"focal_length\";s:2:\"50\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:12:\"Seilklettern\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:14:{i:0;s:12:\"seilklettern\";i:1;s:8:\"klettern\";i:2;s:11:\"kletterwald\";i:3;s:11:\"kletterpark\";i:4;s:11:\"bergsteigen\";i:5;s:4:\"mann\";i:6;s:6:\"himmel\";i:7;s:5:\"sport\";i:8;s:8:\"freizeit\";i:9;s:9:\"abenteuer\";i:10;s:4:\"blau\";i:11;s:6:\"wolken\";i:12;s:10:\"sicherheit\";i:13;s:4:\"berg\";}}}");
INSERT INTO `wp_postmeta` VALUES("21","21","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_06.jpeg");
INSERT INTO `wp_postmeta` VALUES("22","22","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_09.jpeg");
INSERT INTO `wp_postmeta` VALUES("23","23","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_05-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("24","21","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_06.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_06-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_06-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_06-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_06-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_06-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_06-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_06-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_06-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:22:\"Klaus Eppele - Fotolia\";s:6:\"camera\";s:13:\"Canon EOS 50D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1270221685\";s:9:\"copyright\";s:22:\"Klaus Eppele - Fotolia\";s:12:\"focal_length\";s:2:\"38\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:13:\"Klettergarten\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:10:{i:0;s:13:\"klettergarten\";i:1;s:8:\"klettern\";i:2;s:11:\"kletterpark\";i:3;s:4:\"wald\";i:4;s:4:\"park\";i:5;s:8:\"geschick\";i:6;s:4:\"hoch\";i:7;s:9:\"plattform\";i:8;s:8:\"abseilen\";i:9;s:13:\"schwindelfrei\";}}}");
INSERT INTO `wp_postmeta` VALUES("25","22","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1567;s:6:\"height\";i:2361;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_09.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_09-199x300.jpeg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_09-680x1024.jpeg\";s:5:\"width\";i:680;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_09-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_09-768x1157.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1157;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_09-1019x1536.jpeg\";s:5:\"width\";i:1019;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_09-1359x2048.jpeg\";s:5:\"width\";i:1359;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_09-1200x1808.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1808;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"7.1\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"NIKON D300\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1242147232\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"32\";s:3:\"iso\";s:3:\"500\";s:13:\"shutter_speed\";s:17:\"0.033333333333333\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("26","24","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_04.jpeg");
INSERT INTO `wp_postmeta` VALUES("27","24","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2358;s:6:\"height\";i:1569;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_04.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_04-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_04-1024x681.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:681;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_04-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_04-768x511.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_04-1536x1022.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1022;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_04-2048x1363.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1363;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_04-1200x798.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:798;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_04-1980x1317.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1317;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.5\";s:6:\"credit\";s:23:\"Thomas Reimer - Fotolia\";s:6:\"camera\";s:9:\"NIKON D90\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:23:\"Thomas Reimer - Fotolia\";s:12:\"focal_length\";s:2:\"18\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:13:\"Lammerklamm 2\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:46:{i:0;s:5:\"klamm\";i:1;s:10:\"felsspalte\";i:2;s:10:\"wasserfall\";i:3;s:9:\"schnellen\";i:4;s:14:\"stromschnellen\";i:5;s:6:\"spalte\";i:6;s:4:\"fels\";i:7;s:6:\"felsen\";i:8;s:11:\"lammeröfen\";i:9;s:11:\"lammerklamm\";i:10;s:11:\"österreich\";i:11;s:7:\"wandern\";i:12;s:8:\"klettern\";i:13;s:6:\"wasser\";i:14;s:12:\"wasserspalte\";i:15;s:4:\"berg\";i:16;s:10:\"bergspalte\";i:17;s:13:\"tennengebirge\";i:18;s:8:\"scheffau\";i:19;s:6:\"lammer\";i:20;s:12:\"naturdenkmal\";i:21;s:9:\"kalkstein\";i:22;s:8:\"schlucht\";i:23;s:5:\"enges\";i:24;s:3:\"tal\";i:25;s:11:\"gebirgsbach\";i:26;s:4:\"bach\";i:27;s:14:\"durchbruchstal\";i:28;s:10:\"durchbruch\";i:29;s:5:\"zwang\";i:30;s:10:\"reissender\";i:31;s:10:\"reißender\";i:32;s:7:\"gestein\";i:33;s:10:\"felswände\";i:34;s:6:\"höhle\";i:35;s:11:\"höhlenbach\";i:36;s:9:\"gewässer\";i:37;s:13:\"schmelzwasser\";i:38;s:10:\"wasserlauf\";i:39;s:7:\"erosion\";i:40;s:9:\"vorfluter\";i:41;s:11:\"festgestein\";i:42;s:13:\"tiefenerosion\";i:43;s:10:\"denudation\";i:44;s:6:\"engtal\";i:45;s:7:\"klammen\";}}}");
INSERT INTO `wp_postmeta` VALUES("28","23","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_05-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_05-225x300.jpeg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_05-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_05-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_05-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_05-1152x1536.jpeg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_05-1536x2048.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_05-1200x1600.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_05-1980x2640.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:2640;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:22:\"Marius Lazin - Fotolia\";s:6:\"camera\";s:20:\"Canon PowerShot A620\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1154773359\";s:9:\"copyright\";s:22:\"Marius Lazin - Fotolia\";s:12:\"focal_length\";s:3:\"7.3\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:5:\"0.005\";s:5:\"title\";s:6:\"bridge\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:69:{i:0;s:10:\"carpathian\";i:1;s:11:\"carpathians\";i:2;s:8:\"mountain\";i:3;s:9:\"landscape\";i:4;s:4:\"view\";i:5;s:4:\"hill\";i:6;s:8:\"hillside\";i:7;s:3:\"fir\";i:8;s:5:\"molid\";i:9;s:5:\"white\";i:10;s:4:\"grey\";i:11;s:4:\"tree\";i:12;s:5:\"trees\";i:13;s:6:\"forest\";i:14;s:4:\"wood\";i:15;s:6:\"wooden\";i:16;s:6:\"pillar\";i:17;s:6:\"valley\";i:18;s:4:\"rock\";i:19;s:5:\"rocks\";i:20;s:5:\"climb\";i:21;s:4:\"road\";i:22;s:6:\"travel\";i:23;s:9:\"traveling\";i:24;s:5:\"green\";i:25;s:3:\"fog\";i:26;s:5:\"foggy\";i:27;s:8:\"altitude\";i:28;s:5:\"bluff\";i:29;s:5:\"ridge\";i:30;s:5:\"crest\";i:31;s:4:\"comb\";i:32;s:5:\"plant\";i:33;s:6:\"plants\";i:34;s:6:\"nature\";i:35;s:10:\"background\";i:36;s:9:\"wallpaper\";i:37;s:5:\"vaser\";i:38;s:5:\"water\";i:39;s:5:\"river\";i:40;s:7:\"cascade\";i:41;s:9:\"tributary\";i:42;s:7:\"ancient\";i:43;s:7:\"antique\";i:44;s:3:\"old\";i:45;s:7:\"working\";i:46;s:6:\"resita\";i:47;s:8:\"mocanita\";i:48;s:8:\"ecotours\";i:49;s:5:\"viseu\";i:50;s:12:\"viseu de sus\";i:51;s:6:\"wasser\";i:52;s:9:\"wassertal\";i:53;s:12:\"vaser valley\";i:54;s:7:\"romania\";i:55;s:2:\"mm\";i:56;s:9:\"maramures\";i:57;s:4:\"coal\";i:58;s:5:\"group\";i:59;s:5:\"sepia\";i:60;s:10:\"functional\";i:61;s:5:\"coach\";i:62;s:7:\"sleeper\";i:63;s:5:\"truck\";i:64;s:7:\"touring\";i:65;s:7:\"30 km h\";i:66;s:6:\"150 cp\";i:67;s:5:\"canon\";i:68;s:6:\"bridge\";}}s:14:\"original_image\";s:12:\"Bild_05.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("29","26","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_10-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("30","25","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_11-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("31","27","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_12.jpeg");
INSERT INTO `wp_postmeta` VALUES("32","27","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1691;s:6:\"height\";i:1123;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_12.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_12-300x199.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:199;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_12-1024x680.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:680;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_12-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_12-768x510.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:510;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_12-1536x1020.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1020;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_12-1200x797.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:797;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"9\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"NIKON D300\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1236249068\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"40\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:5:\"0.025\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("33","28","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_13.jpeg");
INSERT INTO `wp_postmeta` VALUES("34","28","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1571;s:6:\"height\";i:2356;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_13.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_13-200x300.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_13-683x1024.jpeg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_13-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_13-768x1152.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_13-1024x1536.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_13-1366x2048.jpeg\";s:5:\"width\";i:1366;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_13-1200x1800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:16:\"fotobi - Fotolia\";s:6:\"camera\";s:13:\"Canon EOS 30D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1214756152\";s:9:\"copyright\";s:16:\"fotobi - Fotolia\";s:12:\"focal_length\";s:3:\"105\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:9:\"0.0003125\";s:5:\"title\";s:21:\"hochseilpark klettern\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:13:{i:0;s:8:\"klettern\";i:1;s:12:\"hochseilpark\";i:2;s:5:\"sport\";i:3;s:6:\"wolken\";i:4;s:6:\"himmel\";i:5;s:10:\"festhalten\";i:6;s:11:\"extremsport\";i:7;s:14:\"hochseilgarten\";i:8;s:8:\"hochseil\";i:9;s:13:\"klettergarten\";i:10;s:12:\"hochseilcamp\";i:11;s:16:\"niederseilgarten\";i:12;s:16:\"hochseilparcours\";}}}");
INSERT INTO `wp_postmeta` VALUES("35","29","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_14-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("36","26","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1920;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_10-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_10-300x225.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_10-1024x768.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_10-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_10-768x576.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_10-1536x1152.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_10-2048x1536.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_10-1200x900.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:900;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_10-1980x1485.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1485;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"3.1\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"COOLPIX S220\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1280923786\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"6.3\";s:3:\"iso\";s:3:\"236\";s:13:\"shutter_speed\";s:17:\"0.014684287812041\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:12:\"Bild_10.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("37","25","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1920;s:6:\"height\";i:2560;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_11-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_11-225x300.jpeg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_11-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_11-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_11-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_11-1152x1536.jpeg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_11-1536x2048.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_11-1200x1600.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_11-1980x2640.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:2640;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"5.1\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:12:\"COOLPIX S220\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1280923798\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:4:\"14.3\";s:3:\"iso\";s:3:\"694\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:12:\"Bild_11.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("38","30","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_15.jpeg");
INSERT INTO `wp_postmeta` VALUES("39","30","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1568;s:6:\"height\";i:2360;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_15.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_15-199x300.jpeg\";s:5:\"width\";i:199;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_15-680x1024.jpeg\";s:5:\"width\";i:680;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_15-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_15-768x1156.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1156;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_15-1021x1536.jpeg\";s:5:\"width\";i:1021;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_15-1361x2048.jpeg\";s:5:\"width\";i:1361;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_15-1200x1806.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1806;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:10:\"NIKON D300\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1262449657\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"60\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("40","29","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1707;s:6:\"height\";i:2560;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_14-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_14-200x300.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_14-683x1024.jpeg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_14-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_14-768x1152.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_14-1024x1536.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_14-1365x2048.jpeg\";s:5:\"width\";i:1365;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_14-1200x1800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_14-1980x2970.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:2970;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:15:\"Siggi - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:68:\"Junge Frau balanciert ber wackeliege Holzbrcke im Hochseilgarten\";s:17:\"created_timestamp\";s:10:\"1221328463\";s:9:\"copyright\";s:15:\"Siggi - Fotolia\";s:12:\"focal_length\";s:2:\"11\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.02\";s:5:\"title\";s:8:\"Wackelig\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:52:{i:0;s:14:\"Hochseilgarten\";i:1;s:4:\"Frau\";i:2;s:8:\"Klettern\";i:3;s:11:\"balancieren\";i:4;s:4:\"wald\";i:5;s:4:\"holz\";i:6;s:7:\"brcke\";i:7;s:5:\"seile\";i:8;s:4:\"seil\";i:9;s:4:\"helm\";i:10;s:11:\"klettergurt\";i:11;s:4:\"gurt\";i:12;s:15:\"sicherheitsgurt\";i:13;s:9:\"sicherung\";i:14;s:10:\"karabiener\";i:15;s:14:\"geleichgewicht\";i:16;s:4:\"hoch\";i:17;s:4:\"tief\";i:18;s:5:\"angst\";i:19;s:9:\"schwindel\";i:20;s:13:\"schwindelfrei\";i:21;s:10:\"weitwinkel\";i:22;s:10:\"hochvormat\";i:23;s:10:\"festhalten\";i:24;s:4:\"halt\";i:25;s:4:\"fest\";i:26;s:14:\"hochseilgarten\";i:27;s:4:\"frau\";i:28;s:8:\"klettern\";i:29;s:11:\"balancieren\";i:30;s:4:\"wald\";i:31;s:4:\"holz\";i:32;s:7:\"brücke\";i:33;s:5:\"seile\";i:34;s:4:\"seil\";i:35;s:4:\"helm\";i:36;s:11:\"klettergurt\";i:37;s:4:\"gurt\";i:38;s:15:\"sicherheitsgurt\";i:39;s:9:\"sicherung\";i:40;s:10:\"karabiener\";i:41;s:14:\"geleichgewicht\";i:42;s:4:\"hoch\";i:43;s:4:\"tief\";i:44;s:5:\"angst\";i:45;s:9:\"schwindel\";i:46;s:13:\"schwindelfrei\";i:47;s:10:\"weitwinkel\";i:48;s:10:\"hochvormat\";i:49;s:10:\"festhalten\";i:50;s:4:\"halt\";i:51;s:4:\"fest\";}}s:14:\"original_image\";s:12:\"Bild_14.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("41","31","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_16.jpeg");
INSERT INTO `wp_postmeta` VALUES("42","31","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2221;s:6:\"height\";i:1666;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_16.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_16-300x225.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_16-1024x768.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_16-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_16-768x576.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_16-1536x1152.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_16-2048x1536.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_16-1200x900.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:900;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_16-1980x1485.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1485;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:16:\"fuxart - Fotolia\";s:6:\"camera\";s:7:\"EX-Z850\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1148227465\";s:9:\"copyright\";s:16:\"fuxart - Fotolia\";s:12:\"focal_length\";s:3:\"7.9\";s:3:\"iso\";s:2:\"50\";s:13:\"shutter_speed\";s:5:\"0.008\";s:5:\"title\";s:14:\"spieltrieb (4)\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:69:{i:0;s:10:\"spieltrieb\";i:1;s:7:\"spielen\";i:2;s:8:\"klettern\";i:3;s:14:\"abenteuerplatz\";i:4;s:10:\"spielplatz\";i:5;s:19:\"abenteuerspielplatz\";i:6;s:4:\"frau\";i:7;s:10:\"junge frau\";i:8;s:10:\"burschikos\";i:9;s:10:\"jugendlich\";i:10;s:14:\"klettergerüst\";i:11;s:4:\"netz\";i:12;s:11:\"kletternetz\";i:13;s:7:\"hängen\";i:14;s:9:\"abhängen\";i:15;s:5:\"grün\";i:16;s:5:\"jacke\";i:17;s:5:\"jeans\";i:18;s:5:\"boots\";i:19;s:4:\"sand\";i:20;s:11:\"spielkasten\";i:21;s:15:\"spielkastensand\";i:22;s:10:\"buddelsand\";i:23;s:3:\"cap\";i:24;s:7:\"gesicht\";i:25;s:5:\"beine\";i:26;s:6:\"schuhe\";i:27;s:6:\"fallen\";i:28;s:9:\"hinfallen\";i:29;s:10:\"festhalten\";i:30;s:9:\"schaukeln\";i:31;s:5:\"stadt\";i:32;s:6:\"kinder\";i:33;s:9:\"spielzeug\";i:34;s:11:\"wetterjacke\";i:35;s:10:\"wachsjacke\";i:36;s:10:\"regenjacke\";i:37;s:9:\"jeanslook\";i:38;s:14:\"jeansklamotten\";i:39;s:6:\"gesund\";i:40;s:8:\"erholung\";i:41;s:5:\"spass\";i:42;s:5:\"spaß\";i:43;s:6:\"freude\";i:44;s:10:\"vergnügen\";i:45;s:6:\"ferien\";i:46;s:6:\"urlaub\";i:47;s:10:\"spielspass\";i:48;s:7:\"baumeln\";i:49;s:7:\"taumeln\";i:50;s:8:\"strecken\";i:51;s:7:\"hüpfen\";i:52;s:8:\"springen\";i:53;s:6:\"lachen\";i:54;s:5:\"feude\";i:55;s:9:\"ausgleich\";i:56;s:10:\"hyperaktiv\";i:57;s:11:\"schwungvoll\";i:58;s:7:\"kreativ\";i:59;s:9:\"wettkampf\";i:60;s:10:\"gute laune\";i:61;s:8:\"lächeln\";i:62;s:7:\"fitness\";i:63;s:8:\"training\";i:64;s:11:\"entspannung\";i:65;s:4:\"ergo\";i:66;s:8:\"therapie\";i:67;s:5:\"sport\";i:68;s:20:\"körperertüchtigung\";}}}");
INSERT INTO `wp_postmeta` VALUES("43","32","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_17.jpeg");
INSERT INTO `wp_postmeta` VALUES("44","32","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_17.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_17-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_17-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_17-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_17-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_17-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_17-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_17-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_17-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"16\";s:6:\"credit\";s:14:\"manu - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 400D DIGITAL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1187055034\";s:9:\"copyright\";s:14:\"manu - Fotolia\";s:12:\"focal_length\";s:2:\"95\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:16:\"klettern - seile\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:19:{i:0;s:8:\"klettern\";i:1;s:7:\"spielen\";i:2;s:10:\"spielplatz\";i:3;s:7:\"motorik\";i:4;s:8:\"bewegung\";i:5;s:5:\"aktiv\";i:6;s:6:\"urlaub\";i:7;s:8:\"freizeit\";i:8;s:5:\"spaß\";i:9;s:11:\"kinderspiel\";i:10;s:14:\"klettergerüst\";i:11;s:12:\"kindergarten\";i:12;s:7:\"bewegen\";i:13;s:9:\"motorisch\";i:14;s:4:\"seil\";i:15;s:4:\"bunt\";i:16;s:12:\"hochklettern\";i:17;s:6:\"turnen\";i:18;s:10:\"turngerät\";}}}");
INSERT INTO `wp_postmeta` VALUES("45","33","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_18.jpeg");
INSERT INTO `wp_postmeta` VALUES("46","33","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_18.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_18-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_18-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_18-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_18-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_18-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_18-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_18-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_18-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"16\";s:6:\"credit\";s:18:\"Fontanis - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1218905822\";s:9:\"copyright\";s:18:\"Fontanis - Fotolia\";s:12:\"focal_length\";s:2:\"45\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:6:\"0.0025\";s:5:\"title\";s:36:\"Mädchen an den Stangen des Parcours\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:45:{i:0;s:8:\"mädchen\";i:1;s:7:\"stangen\";i:2;s:7:\"parcour\";i:3;s:6:\"himmel\";i:4;s:11:\"jugendliche\";i:5;s:4:\"gurt\";i:6;s:4:\"seil\";i:7;s:14:\"hochseilgarten\";i:8;s:9:\"abenteuer\";i:9;s:6:\"aktion\";i:10;s:5:\"aktiv\";i:11;s:5:\"angst\";i:12;s:8:\"klettern\";i:13;s:4:\"baum\";i:14;s:12:\"beherrschung\";i:15;s:11:\"balancieren\";i:16;s:8:\"bewegung\";i:17;s:12:\"bewältigung\";i:18;s:9:\"erfahrung\";i:19;s:10:\"festhalten\";i:20;s:7:\"fitness\";i:21;s:8:\"freizeit\";i:22;s:12:\"freizeitpark\";i:23;s:6:\"freude\";i:24;s:3:\"fun\";i:25;s:6:\"gefahr\";i:26;s:7:\"grenzen\";i:27;s:9:\"hindernis\";i:28;s:11:\"hindernisse\";i:29;s:8:\"hochseil\";i:30;s:5:\"höhe\";i:31;s:14:\"klettertrainer\";i:32;s:3:\"mut\";i:33;s:12:\"nervenkitzel\";i:34;s:7:\"outdoor\";i:35;s:5:\"route\";i:36;s:13:\"schwierigkeit\";i:37;s:5:\"seile\";i:38;s:15:\"selbsterfahrung\";i:39;s:10:\"sicherheit\";i:40;s:8:\"spannend\";i:41;s:8:\"spannung\";i:42;s:5:\"sport\";i:43;s:6:\"bäume\";i:44;s:4:\"wald\";}}}");
INSERT INTO `wp_postmeta` VALUES("47","34","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_19.jpeg");
INSERT INTO `wp_postmeta` VALUES("48","34","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_19.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_19-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_19-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_19-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_19-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_19-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_19-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_19-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_19-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:22:\"Tino Hemmann - Fotolia\";s:6:\"camera\";s:9:\"DSLR-A700\";s:7:\"caption\";s:13:\"kleiner Pirat\";s:17:\"created_timestamp\";s:10:\"1217928805\";s:9:\"copyright\";s:22:\"Tino Hemmann - Fotolia\";s:12:\"focal_length\";s:2:\"45\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:8:\"0.003125\";s:5:\"title\";s:13:\"kleiner Pirat\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:21:{i:0;s:7:\"piraten\";i:1;s:3:\"boy\";i:2;s:6:\"sommer\";i:3;s:4:\"frei\";i:4;s:4:\"meer\";i:5;s:6:\"wasser\";i:6;s:4:\"blau\";i:7;s:8:\"horizont\";i:8;s:6:\"himmel\";i:9;s:5:\"sonne\";i:10;s:4:\"warm\";i:11;s:6:\"urlaub\";i:12;s:6:\"schiff\";i:13;s:8:\"seefahrt\";i:14;s:9:\"abenteuer\";i:15;s:5:\"junge\";i:16;s:4:\"kind\";i:17;s:4:\"seil\";i:18;s:8:\"takelage\";i:19;s:5:\"segel\";i:20;s:8:\"klettern\";}}}");
INSERT INTO `wp_postmeta` VALUES("49","35","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_20.jpeg");
INSERT INTO `wp_postmeta` VALUES("50","35","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1800;s:6:\"height\";i:2400;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_20.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_20-225x300.jpeg\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_20-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_20-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_20-768x1024.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_20-1152x1536.jpeg\";s:5:\"width\";i:1152;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_20-1536x2048.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_20-1200x1600.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1600;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:18:\"theogott - Fotolia\";s:6:\"camera\";s:4:\"E885\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:12:\"-62169984000\";s:9:\"copyright\";s:18:\"theogott - Fotolia\";s:12:\"focal_length\";s:1:\"8\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:17:\"0.014925373134328\";s:5:\"title\";s:31:\"Schönes Mädchen beim Klettern\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:10:{i:0;s:6:\"kinder\";i:1;s:8:\"mädchen\";i:2;s:3:\"rot\";i:3;s:6:\"schön\";i:4;s:8:\"klettern\";i:5;s:11:\"kletterpark\";i:6;s:9:\"amusement\";i:7;s:5:\"augen\";i:8;s:7:\"ausflug\";i:9;s:5:\"blick\";}}}");
INSERT INTO `wp_postmeta` VALUES("51","36","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_21-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("52","37","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_22.jpeg");
INSERT INTO `wp_postmeta` VALUES("53","37","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:2000;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_22.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_22-240x300.jpeg\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_22-819x1024.jpeg\";s:5:\"width\";i:819;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_22-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_22-768x960.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_22-1229x1536.jpeg\";s:5:\"width\";i:1229;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_22-1200x1500.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1500;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.7\";s:6:\"credit\";s:18:\"searagen - Fotolia\";s:6:\"camera\";s:13:\"Canon EOS 10D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1131396906\";s:9:\"copyright\";s:18:\"searagen - Fotolia\";s:12:\"focal_length\";s:2:\"28\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:18:\"0.0028571428571429\";s:5:\"title\";s:16:\"three at the top\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:26:{i:0;s:8:\"teamwork\";i:1;s:7:\"success\";i:2;s:5:\"group\";i:3;s:4:\"team\";i:4;s:5:\"three\";i:5;s:8:\"climbers\";i:6;s:4:\"wall\";i:7;s:5:\"reach\";i:8;s:8:\"reaching\";i:9;s:9:\"adventure\";i:10;s:5:\"climb\";i:11;s:8:\"climbing\";i:12;s:6:\"effort\";i:13;s:4:\"rock\";i:14;s:4:\"rope\";i:15;s:5:\"ropes\";i:16;s:6:\"safety\";i:17;s:8:\"security\";i:18;s:8:\"strength\";i:19;s:6:\"strong\";i:20;s:6:\"higher\";i:21;s:2:\"up\";i:22;s:5:\"holds\";i:23;s:8:\"together\";i:24;s:4:\"high\";i:25;s:3:\"top\";}}}");
INSERT INTO `wp_postmeta` VALUES("54","38","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_23.jpeg");
INSERT INTO `wp_postmeta` VALUES("55","38","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_23.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_23-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_23-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_23-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_23-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_23-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_23-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_23-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_23-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:15:\"Siggi - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:61:\"Junge Frau befestigt Sicherung an Stahlsein im Hochseilgarten\";s:17:\"created_timestamp\";s:10:\"1221329656\";s:9:\"copyright\";s:15:\"Siggi - Fotolia\";s:12:\"focal_length\";s:2:\"11\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:4:\"0.01\";s:5:\"title\";s:23:\"Seilrutsche vorbereiten\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:50:{i:0;s:14:\"Hochseilgarten\";i:1;s:11:\"Seilrutsche\";i:2;s:9:\"Sicherung\";i:3;s:4:\"helm\";i:4;s:4:\"frau\";i:5;s:4:\"jung\";i:6;s:4:\"seil\";i:7;s:9:\"karabiner\";i:8;s:4:\"wald\";i:9;s:4:\"baum\";i:10;s:4:\"seil\";i:11;s:9:\"stahlsein\";i:12;s:11:\"seilrutsche\";i:13;s:11:\"klettergurt\";i:14;s:4:\"gurt\";i:15;s:15:\"sicherheitsgurt\";i:16;s:9:\"brustgurt\";i:17;s:8:\"sitzgurt\";i:18;s:7:\"sichern\";i:19;s:10:\"befestigen\";i:20;s:5:\"angst\";i:21;s:6:\"furcht\";i:22;s:3:\"mut\";i:23;s:12:\"ueberwindung\";i:24;s:6:\"sprung\";i:25;s:8:\"springen\";i:26;s:14:\"hochseilgarten\";i:27;s:11:\"seilrutsche\";i:28;s:9:\"sicherung\";i:29;s:4:\"helm\";i:30;s:4:\"frau\";i:31;s:4:\"jung\";i:32;s:4:\"seil\";i:33;s:9:\"karabiner\";i:34;s:4:\"wald\";i:35;s:4:\"baum\";i:36;s:11:\"klettergurt\";i:37;s:4:\"gurt\";i:38;s:15:\"sicherheitsgurt\";i:39;s:9:\"brustgurt\";i:40;s:8:\"sitzgurt\";i:41;s:7:\"sichern\";i:42;s:10:\"befestigen\";i:43;s:5:\"angst\";i:44;s:6:\"furcht\";i:45;s:3:\"mut\";i:46;s:12:\"ueberwindung\";i:47;s:6:\"sprung\";i:48;s:8:\"springen\";i:49;s:9:\"stahlseil\";}}}");
INSERT INTO `wp_postmeta` VALUES("56","39","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_24.jpeg");
INSERT INTO `wp_postmeta` VALUES("57","39","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1571;s:6:\"height\";i:2356;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_24.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_24-200x300.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_24-683x1024.jpeg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_24-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_24-768x1152.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_24-1024x1536.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_24-1366x2048.jpeg\";s:5:\"width\";i:1366;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_24-1200x1800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"4\";s:6:\"credit\";s:15:\"Siggi - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:44:\"Frau erklettert einen Baum im Hochseilgarten\";s:17:\"created_timestamp\";s:10:\"1221325124\";s:9:\"copyright\";s:15:\"Siggi - Fotolia\";s:12:\"focal_length\";s:2:\"11\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:17:\"0.033333333333333\";s:5:\"title\";s:14:\"Hochseilgarten\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:49:{i:0;s:14:\"Hochseilgarten\";i:1;s:8:\"Klettern\";i:2;s:4:\"Frau\";i:3;s:4:\"Holz\";i:4;s:4:\"Wald\";i:5;s:4:\"Baum\";i:6;s:12:\"Strickleiter\";i:7;s:4:\"Helm\";i:8;s:4:\"Seil\";i:9;s:9:\"Waldboden\";i:10;s:9:\"Plattform\";i:11;s:8:\"Klettern\";i:12;s:7:\"Steigen\";i:13;s:6:\"Fallen\";i:14;s:7:\"Sichern\";i:15;s:10:\"Sicherheit\";i:16;s:3:\"Mut\";i:17;s:6:\"Wagnis\";i:18;s:5:\"Wagen\";i:19;s:5:\"Angst\";i:20;s:4:\"Hoch\";i:21;s:4:\"Tief\";i:22;s:10:\"Weitwinkel\";i:23;s:12:\"Ueberwindung\";i:24;s:10:\"Hochvormat\";i:25;s:14:\"hochseilgarten\";i:26;s:8:\"klettern\";i:27;s:4:\"frau\";i:28;s:4:\"holz\";i:29;s:4:\"wald\";i:30;s:4:\"baum\";i:31;s:12:\"strickleiter\";i:32;s:4:\"helm\";i:33;s:4:\"seil\";i:34;s:9:\"waldboden\";i:35;s:9:\"plattform\";i:36;s:7:\"steigen\";i:37;s:6:\"fallen\";i:38;s:7:\"sichern\";i:39;s:10:\"sicherheit\";i:40;s:3:\"mut\";i:41;s:6:\"wagnis\";i:42;s:5:\"wagen\";i:43;s:5:\"angst\";i:44;s:4:\"hoch\";i:45;s:4:\"tief\";i:46;s:10:\"weitwinkel\";i:47;s:12:\"überwindung\";i:48;s:10:\"hochvormat\";}}}");
INSERT INTO `wp_postmeta` VALUES("58","36","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1714;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_21-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_21-300x201.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_21-1024x685.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:685;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_21-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_21-768x514.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_21-1536x1028.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_21-2048x1371.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1371;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_21-1200x803.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:803;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_21-1980x1325.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1325;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.7\";s:6:\"credit\";s:14:\"Tony - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:52:\"Two girls preparing for a jump high above the ground\";s:17:\"created_timestamp\";s:10:\"1161965337\";s:9:\"copyright\";s:14:\"Tony - Fotolia\";s:12:\"focal_length\";s:2:\"70\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:28:\"preparing for the risky jump\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:52:{i:0;s:62:\"girls, risk, sport, game, play, climbing, climb, rope, safety,\";i:1;s:288:\"tree, gear, jump, dare, prepare, preparing, for, a, jump, high, above, the, ground, climber, exercise, fitness, effort, empowerment, health,  inspiration, inspiring, blue, sky, space for text, sport, strength, hang, hanging, amusement, amusement park, entertainment, help, help each other\";i:2;s:5:\"girls\";i:3;s:4:\"risk\";i:4;s:5:\"sport\";i:5;s:4:\"game\";i:6;s:4:\"play\";i:7;s:8:\"climbing\";i:8;s:5:\"climb\";i:9;s:4:\"rope\";i:10;s:6:\"safety\";i:11;s:4:\"tree\";i:12;s:4:\"gear\";i:13;s:4:\"jump\";i:14;s:4:\"dare\";i:15;s:7:\"prepare\";i:16;s:9:\"preparing\";i:17;s:3:\"for\";i:18;s:4:\"high\";i:19;s:5:\"above\";i:20;s:3:\"the\";i:21;s:6:\"ground\";i:22;s:7:\"climber\";i:23;s:8:\"exercise\";i:24;s:7:\"fitness\";i:25;s:6:\"effort\";i:26;s:11:\"empowerment\";i:27;s:6:\"health\";i:28;s:11:\"inspiration\";i:29;s:9:\"inspiring\";i:30;s:4:\"blue\";i:31;s:3:\"sky\";i:32;s:14:\"space for text\";i:33;s:8:\"strength\";i:34;s:4:\"hang\";i:35;s:7:\"hanging\";i:36;s:9:\"amusement\";i:37;s:14:\"amusement park\";i:38;s:13:\"entertainment\";i:39;s:4:\"help\";i:40;s:15:\"help each other\";i:41;s:7:\"helping\";i:42;s:4:\"hand\";i:43;s:5:\"hands\";i:44;s:4:\"hold\";i:45;s:7:\"holding\";i:46;s:6:\"scared\";i:47;s:5:\"scary\";i:48;s:6:\"breath\";i:49;s:6:\"taking\";i:50;s:6:\"secure\";i:51;s:7:\"secured\";}}s:14:\"original_image\";s:12:\"Bild_21.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("59","40","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_25.jpeg");
INSERT INTO `wp_postmeta` VALUES("60","40","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_25.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_25-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_25-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_25-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_25-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_25-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_25-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_25-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_25-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:15:\"Siggi - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:37:\"Frau im Hochseilgarten hngt im Seil\";s:17:\"created_timestamp\";s:10:\"1221326351\";s:9:\"copyright\";s:15:\"Siggi - Fotolia\";s:12:\"focal_length\";s:2:\"11\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:6:\"0.0025\";s:5:\"title\";s:25:\"Hochseilgarten Uebersicht\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:62:{i:0;s:14:\"Hochseilgarten\";i:1;s:4:\"Frau\";i:2;s:8:\"Klettern\";i:3;s:4:\"Wald\";i:4;s:4:\"Seil\";i:5;s:4:\"Helm\";i:6;s:4:\"jung\";i:7;s:5:\"junge\";i:8;s:6:\"mensch\";i:9;s:4:\"baum\";i:10;s:8:\"blaetter\";i:11;s:11:\"balancieren\";i:12;s:4:\"helm\";i:13;s:11:\"klettergurt\";i:14;s:15:\"sicherheitsgurt\";i:15;s:10:\"sicherheit\";i:16;s:3:\"mut\";i:17;s:6:\"wagnis\";i:18;s:5:\"angst\";i:19;s:12:\"ueberwindung\";i:20;s:13:\"gleichgewicht\";i:21;s:5:\"sport\";i:22;s:11:\"anstrengung\";i:23;s:7:\"fitness\";i:24;s:11:\"kletterwald\";i:25;s:6:\"furcht\";i:26;s:4:\"fest\";i:27;s:6:\"halten\";i:28;s:6:\"gefahr\";i:29;s:11:\"gefaehrlich\";i:30;s:11:\"kletterwald\";i:31;s:8:\"hochseil\";i:32;s:14:\"hochseilgarten\";i:33;s:4:\"frau\";i:34;s:8:\"klettern\";i:35;s:4:\"wald\";i:36;s:4:\"seil\";i:37;s:4:\"helm\";i:38;s:4:\"jung\";i:39;s:5:\"junge\";i:40;s:6:\"mensch\";i:41;s:4:\"baum\";i:42;s:8:\"blätter\";i:43;s:11:\"balancieren\";i:44;s:11:\"klettergurt\";i:45;s:15:\"sicherheitsgurt\";i:46;s:10:\"sicherheit\";i:47;s:3:\"mut\";i:48;s:6:\"wagnis\";i:49;s:5:\"angst\";i:50;s:12:\"überwindung\";i:51;s:13:\"gleichgewicht\";i:52;s:5:\"sport\";i:53;s:11:\"anstrengung\";i:54;s:7:\"fitness\";i:55;s:11:\"kletterwald\";i:56;s:6:\"furcht\";i:57;s:4:\"fest\";i:58;s:6:\"halten\";i:59;s:6:\"gefahr\";i:60;s:11:\"gefährlich\";i:61;s:8:\"hochseil\";}}}");
INSERT INTO `wp_postmeta` VALUES("61","41","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_26-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("62","42","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_27.jpeg");
INSERT INTO `wp_postmeta` VALUES("63","42","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_27.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_27-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_27-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_27-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_27-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_27-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_27-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_27-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_27-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"5.6\";s:6:\"credit\";s:22:\"JENS SCHMIDT - Fotolia\";s:6:\"camera\";s:21:\"Canon EOS-1Ds Mark II\";s:7:\"caption\";s:32:\"FAMILIE IM HERBSTWALD, SPAZIEREN\";s:17:\"created_timestamp\";s:10:\"1223451182\";s:9:\"copyright\";s:22:\"JENS SCHMIDT - Fotolia\";s:12:\"focal_length\";s:2:\"44\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:8:\"0.003125\";s:5:\"title\";s:10:\"STADTLEBEN\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:102:{i:0;s:5:\"LIEBE\";i:1;s:9:\"ZUNEIGUNG\";i:2;s:5:\"SPASS\";i:3;s:5:\"SPIEL\";i:4;s:6:\"LIEBEN\";i:5;s:9:\"BERHREN\";i:6;s:4:\"MANN\";i:7;s:4:\"KIND\";i:8;s:7:\"TOCHTER\";i:9;s:8:\"ZUSAMMEN\";i:10;s:9:\"GEMEINSAM\";i:11;s:7:\"FAMILIE\";i:12;s:8:\"UMARMUNG\";i:13;s:6:\"KINDER\";i:14;s:5:\"NATUR\";i:15;s:14:\"SOMMERSTIMMUNG\";i:16;s:9:\"SPAZIEREN\";i:17;s:6:\"LACHEN\";i:18;s:7:\"GRINSEN\";i:19;s:9:\"FRHLICH\";i:20;s:8:\"ENSPANNT\";i:21;s:5:\"VATER\";i:22;s:8:\"SCHULTER\";i:23;s:4:\"OBEN\";i:24;s:4:\"JUNG\";i:25;s:8:\"KINDLICH\";i:26;s:9:\"SPORTLICH\";i:27;s:7:\"UMARMEN\";i:28;s:8:\"VERTAUEN\";i:29;s:4:\"PAAR\";i:30;s:7:\"VERLOBT\";i:31;s:9:\"BERUEHREN\";i:32;s:4:\"FRAU\";i:33;s:6:\"HERBST\";i:34;s:14:\"HERBSTBLAETTER\";i:35;s:4:\"LAUB\";i:36;s:14:\"HERBSTSTIMMUNG\";i:37;s:7:\"WANDERN\";i:38;s:6:\"PULLIS\";i:39;s:9:\"FROEHLICH\";i:40;s:4:\"KALT\";i:41;s:6:\"KAELTE\";i:42;s:8:\"ANZIEHEN\";i:43;s:9:\"GENIESSEN\";i:44;s:8:\"BLAETTER\";i:45;s:8:\"STIMMUNG\";i:46;s:8:\"MAEDCHEN\";i:47;s:6:\"TRAGEN\";i:48;s:7:\"RUECKEN\";i:49;s:7:\"SPASSEN\";i:50;s:5:\"liebe\";i:51;s:9:\"zuneigung\";i:52;s:5:\"spass\";i:53;s:5:\"spiel\";i:54;s:6:\"lieben\";i:55;s:3:\"ber\";i:56;s:4:\"hren\";i:57;s:4:\"mann\";i:58;s:4:\"kind\";i:59;s:7:\"tochter\";i:60;s:8:\"zusammen\";i:61;s:9:\"gemeinsam\";i:62;s:7:\"familie\";i:63;s:8:\"umarmung\";i:64;s:6:\"kinder\";i:65;s:5:\"natur\";i:66;s:14:\"sommerstimmung\";i:67;s:9:\"spazieren\";i:68;s:6:\"lachen\";i:69;s:7:\"grinsen\";i:70;s:2:\"fr\";i:71;s:5:\"hlich\";i:72;s:8:\"enspannt\";i:73;s:5:\"vater\";i:74;s:8:\"schulter\";i:75;s:4:\"oben\";i:76;s:4:\"jung\";i:77;s:8:\"kindlich\";i:78;s:9:\"sportlich\";i:79;s:7:\"umarmen\";i:80;s:8:\"vertauen\";i:81;s:4:\"paar\";i:82;s:7:\"verlobt\";i:83;s:9:\"beruehren\";i:84;s:4:\"frau\";i:85;s:6:\"herbst\";i:86;s:14:\"herbstblaetter\";i:87;s:4:\"laub\";i:88;s:14:\"herbststimmung\";i:89;s:7:\"wandern\";i:90;s:6:\"pullis\";i:91;s:9:\"froehlich\";i:92;s:4:\"kalt\";i:93;s:6:\"kaelte\";i:94;s:8:\"anziehen\";i:95;s:9:\"geniessen\";i:96;s:8:\"blaetter\";i:97;s:8:\"stimmung\";i:98;s:8:\"maedchen\";i:99;s:6:\"tragen\";i:100;s:7:\"ruecken\";i:101;s:7:\"spassen\";}}}");
INSERT INTO `wp_postmeta` VALUES("64","41","_wp_attachment_metadata","a:6:{s:5:\"width\";i:1707;s:6:\"height\";i:2560;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_26-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_26-200x300.jpeg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_26-683x1024.jpeg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_26-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_26-768x1152.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_26-1024x1536.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_26-1365x2048.jpeg\";s:5:\"width\";i:1365;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_26-1200x1800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_26-1980x2970.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:2970;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:15:\"Siggi - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 350D DIGITAL\";s:7:\"caption\";s:64:\"Junge Frau springt von Platform in Seilrutsche im Hochseilgarten\";s:17:\"created_timestamp\";s:10:\"1221329672\";s:9:\"copyright\";s:15:\"Siggi - Fotolia\";s:12:\"focal_length\";s:2:\"11\";s:3:\"iso\";s:3:\"400\";s:13:\"shutter_speed\";s:7:\"0.00625\";s:5:\"title\";s:10:\"Seilsprung\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:50:{i:0;s:14:\"Hochseilgarten\";i:1;s:11:\"Seilrutsche\";i:2;s:9:\"Sicherung\";i:3;s:4:\"helm\";i:4;s:4:\"frau\";i:5;s:4:\"jung\";i:6;s:4:\"seil\";i:7;s:9:\"karabiner\";i:8;s:4:\"wald\";i:9;s:4:\"baum\";i:10;s:4:\"seil\";i:11;s:9:\"stahlsein\";i:12;s:11:\"seilrutsche\";i:13;s:11:\"klettergurt\";i:14;s:4:\"gurt\";i:15;s:15:\"sicherheitsgurt\";i:16;s:9:\"brustgurt\";i:17;s:8:\"sitzgurt\";i:18;s:7:\"sichern\";i:19;s:10:\"befestigen\";i:20;s:5:\"angst\";i:21;s:6:\"furcht\";i:22;s:3:\"mut\";i:23;s:12:\"ueberwindung\";i:24;s:6:\"sprung\";i:25;s:8:\"springen\";i:26;s:14:\"hochseilgarten\";i:27;s:11:\"seilrutsche\";i:28;s:9:\"sicherung\";i:29;s:4:\"helm\";i:30;s:4:\"frau\";i:31;s:4:\"jung\";i:32;s:4:\"seil\";i:33;s:9:\"karabiner\";i:34;s:4:\"wald\";i:35;s:4:\"baum\";i:36;s:9:\"stahlseil\";i:37;s:11:\"klettergurt\";i:38;s:4:\"gurt\";i:39;s:15:\"sicherheitsgurt\";i:40;s:9:\"brustgurt\";i:41;s:8:\"sitzgurt\";i:42;s:7:\"sichern\";i:43;s:10:\"befestigen\";i:44;s:5:\"angst\";i:45;s:6:\"furcht\";i:46;s:3:\"mut\";i:47;s:12:\"ueberwindung\";i:48;s:6:\"sprung\";i:49;s:8:\"springen\";}}s:14:\"original_image\";s:12:\"Bild_26.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("65","43","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_28.jpeg");
INSERT INTO `wp_postmeta` VALUES("66","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1626;s:6:\"height\";i:2276;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_28.jpeg\";s:5:\"sizes\";a:7:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_28-214x300.jpeg\";s:5:\"width\";i:214;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_28-732x1024.jpeg\";s:5:\"width\";i:732;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_28-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"Bild_28-768x1075.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:1075;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_28-1097x1536.jpeg\";s:5:\"width\";i:1097;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_28-1463x2048.jpeg\";s:5:\"width\";i:1463;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:22:\"Bild_28-1200x1680.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:1680;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.7\";s:6:\"credit\";s:18:\"searagen - Fotolia\";s:6:\"camera\";s:13:\"Canon EOS 10D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1127173439\";s:9:\"copyright\";s:18:\"searagen - Fotolia\";s:12:\"focal_length\";s:2:\"60\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:5:\"0.002\";s:5:\"title\";s:13:\"working hands\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:23:{i:0;s:9:\"adventure\";i:1;s:5:\"belay\";i:2;s:6:\"effort\";i:3;s:5:\"glove\";i:4;s:6:\"gloves\";i:5;s:4:\"hand\";i:6;s:5:\"hands\";i:7;s:6:\"safety\";i:8;s:8:\"security\";i:9;s:8:\"strength\";i:10;s:7:\"tension\";i:11;s:9:\"tightness\";i:12;s:4:\"taut\";i:13;s:5:\"climb\";i:14;s:8:\"climbing\";i:15;s:8:\"teamwork\";i:16;s:4:\"rock\";i:17;s:4:\"rope\";i:18;s:5:\"ropes\";i:19;s:6:\"strong\";i:20;s:5:\"group\";i:21;s:4:\"team\";i:22;s:4:\"line\";}}}");
INSERT INTO `wp_postmeta` VALUES("67","44","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_29.jpeg");
INSERT INTO `wp_postmeta` VALUES("68","44","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2356;s:6:\"height\";i:1571;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_29.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_29-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_29-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_29-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_29-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_29-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_29-2048x1366.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_29-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_29-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:2:\"13\";s:6:\"credit\";s:22:\"Ermano Grosz - Fotolia\";s:6:\"camera\";s:12:\"Canon EOS 5D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1239974755\";s:9:\"copyright\";s:22:\"Ermano Grosz - Fotolia\";s:12:\"focal_length\";s:2:\"90\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:6:\"0.0125\";s:5:\"title\";s:20:\"Kletterausrüstung 6\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:12:{i:0;s:18:\"kletterausrüstung\";i:1;s:8:\"klettern\";i:2;s:6:\"hände\";i:3;s:9:\"karabiner\";i:4;s:14:\"expresschlinge\";i:5;s:4:\"seil\";i:6;s:11:\"bergsteigen\";i:7;s:6:\"felsen\";i:8;s:7:\"sichern\";i:9;s:10:\"seilschaft\";i:10;s:7:\"gebirge\";i:11;s:10:\"alpinismus\";}}}");
INSERT INTO `wp_postmeta` VALUES("69","45","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_30-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("70","46","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_31.jpeg");
INSERT INTO `wp_postmeta` VALUES("71","46","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1892;s:6:\"height\";i:1336;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_31.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_31-300x212.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:212;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_31-1024x723.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:723;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_31-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_31-768x542.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:542;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_31-1536x1085.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1085;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_31-1200x847.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:847;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:10:\"Copyright,\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("72","47","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_01-scaled.jpeg");
INSERT INTO `wp_postmeta` VALUES("73","48","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_02.jpeg");
INSERT INTO `wp_postmeta` VALUES("74","49","_wp_attached_file","C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_03.jpeg");
INSERT INTO `wp_postmeta` VALUES("75","48","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2351;s:6:\"height\";i:1574;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_02.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_02-300x201.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_02-1024x686.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:686;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_02-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_02-768x514.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_02-1536x1028.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_02-2048x1371.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1371;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_02-1200x803.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:803;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_02-1980x1326.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1326;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"8\";s:6:\"credit\";s:20:\"Klaus Rose - Fotolia\";s:6:\"camera\";s:9:\"NIKON D80\";s:7:\"caption\";s:296:\"DEU,Deutschland, Goslar : Die 1000-jaehrige Stadt und das Erzbergwerk Rammelsberg  sind  Weltkullturerbe , nicht der einzige Grund eines Besuchs . | DEU, Germany, Goslar: The 1000 years old city and the Erzbergwerk Rammelsberg are world cultural heritage, not the only reason of an attendance. |\";s:17:\"created_timestamp\";s:10:\"1180525708\";s:9:\"copyright\";s:20:\"Klaus Rose - Fotolia\";s:12:\"focal_length\";s:2:\"85\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:5:\"0.005\";s:5:\"title\";s:15:\"Reiseziel  Harz\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:14:{i:0;s:9:\"CD 6.0-07\";i:1;s:3:\"DEU\";i:2;s:11:\"Deutschalnd\";i:3;s:7:\"Germany\";i:4;s:6:\"Goslar\";i:5;s:14:\"Weltkulturerbe\";i:6;s:11:\"deutschland\";i:7;s:13:\"niedersachsen\";i:8;s:8:\"westharz\";i:9;s:6:\"goslar\";i:10;s:10:\"historisch\";i:11;s:9:\"stadtbild\";i:12;s:8:\"fachwerk\";i:13;s:14:\"weltkulturerbe\";}}}");
INSERT INTO `wp_postmeta` VALUES("76","49","_wp_attachment_metadata","a:5:{s:5:\"width\";i:2351;s:6:\"height\";i:1574;s:4:\"file\";s:77:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_03.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_03-300x201.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:201;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_03-1024x686.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:686;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_03-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_03-768x514.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:514;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_03-1536x1028.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1028;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_03-2048x1371.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1371;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_03-1200x803.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:803;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_03-1980x1326.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1326;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"6.7\";s:6:\"credit\";s:24:\"Dimitri Surkov - Fotolia\";s:6:\"camera\";s:11:\"PENTAX K10D\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1270386165\";s:9:\"copyright\";s:24:\"Dimitri Surkov - Fotolia\";s:12:\"focal_length\";s:2:\"40\";s:3:\"iso\";s:3:\"100\";s:13:\"shutter_speed\";s:17:\"0.011111111111111\";s:5:\"title\";s:40:\"Techniques of cultivation of olive trees\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:44:{i:0;s:5:\"olive\";i:1;s:4:\"tree\";i:2;s:10:\"olive tree\";i:3;s:14:\"old olive tree\";i:4;s:4:\"bark\";i:5;s:5:\"trunk\";i:6;s:4:\"root\";i:7;s:4:\"leaf\";i:8;s:6:\"nature\";i:9;s:19:\"traditional culture\";i:10;s:11:\"agriculture\";i:11;s:7:\"culture\";i:12;s:9:\"olive oil\";i:13;s:11:\"cultivation\";i:14;s:8:\"industry\";i:15;s:4:\"food\";i:16;s:9:\"nutrition\";i:17;s:5:\"fruit\";i:18;s:5:\"flora\";i:19;s:4:\"land\";i:20;s:6:\"garden\";i:21;s:5:\"green\";i:22;s:10:\"fruit tree\";i:23;s:12:\"olive branch\";i:24;s:6:\"branch\";i:25;s:5:\"trees\";i:26;s:8:\"business\";i:27;s:10:\"plantation\";i:28;s:3:\"old\";i:29;s:3:\"net\";i:30;s:4:\"nets\";i:31;s:11:\"olive trees\";i:32;s:10:\"techniques\";i:33;s:10:\"production\";i:34;s:14:\"oil production\";i:35;s:9:\"landscape\";i:36;s:15:\"non-urban scene\";i:37;s:8:\"outdoors\";i:38;s:7:\"outdoor\";i:39;s:10:\"industrial\";i:40;s:13:\"mediterranean\";i:41;s:5:\"italy\";i:42;s:7:\"liguria\";i:43;s:7:\"imperia\";}}}");
INSERT INTO `wp_postmeta` VALUES("77","45","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1792;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_30-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_30-300x210.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:210;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_30-1024x717.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:717;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_30-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_30-768x538.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:538;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_30-1536x1075.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1075;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_30-2048x1433.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1433;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_30-1200x840.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:840;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_30-1980x1386.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1386;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:19:\"MEV-Verlag, Germany\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:23:\"Seil mit Karabinerhaken\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:19:\"MEV-Verlag, Germany\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:23:\"Seil mit Karabinerhaken\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:3:{i:0;s:9:\"Sicherung\";i:1;s:5:\"Haken\";i:2;s:7:\"Symbole\";}}s:14:\"original_image\";s:12:\"Bild_30.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("78","47","_wp_attachment_metadata","a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:84:\"C:/xampp/htdocs/es2016_third/module_c/wp-content/uploads/slider2/Bild_01-scaled.jpeg\";s:5:\"sizes\";a:8:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"Bild_01-300x200.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"Bild_01-1024x683.jpeg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"Bild_01-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"Bild_01-768x512.jpeg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"Bild_01-1536x1024.jpeg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:22:\"Bild_01-2048x1365.jpeg\";s:5:\"width\";i:2048;s:6:\"height\";i:1365;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"post-thumbnail\";a:4:{s:4:\"file\";s:21:\"Bild_01-1200x800.jpeg\";s:5:\"width\";i:1200;s:6:\"height\";i:800;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:23:\"twentytwenty-fullscreen\";a:4:{s:4:\"file\";s:22:\"Bild_01-1980x1320.jpeg\";s:5:\"width\";i:1980;s:6:\"height\";i:1320;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"1\";s:6:\"credit\";s:27:\"David Kitzmueller - Fotolia\";s:6:\"camera\";s:22:\"Canon EOS 300D DIGITAL\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1160303385\";s:9:\"copyright\";s:27:\"David Kitzmueller - Fotolia\";s:12:\"focal_length\";s:2:\"61\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:9:\"0.0015625\";s:5:\"title\";s:25:\"meditativer Sonnenaufgang\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:52:{i:0;s:4:\"baum\";i:1;s:4:\"wald\";i:2;s:6:\"bäume\";i:3;s:5:\"sonne\";i:4;s:8:\"strahlen\";i:5;s:6:\"diffus\";i:6;s:5:\"nebel\";i:7;s:4:\"hell\";i:8;s:5:\"licht\";i:9;s:8:\"leuchten\";i:10;s:9:\"gebrochen\";i:11;s:14:\"undurchsichtig\";i:12;s:8:\"hoffnung\";i:13;s:4:\"gott\";i:14;s:5:\"liebe\";i:15;s:3:\"tod\";i:16;s:6:\"weinen\";i:17;s:6:\"trauer\";i:18;s:4:\"blau\";i:19;s:5:\"weiß\";i:20;s:6:\"herbst\";i:21;s:3:\"tag\";i:22;s:6:\"morgen\";i:23;s:5:\"früh\";i:24;s:8:\"stimmung\";i:25;s:7:\"aufgang\";i:26;s:5:\"sonne\";i:27;s:8:\"strahlen\";i:28;s:6:\"trauer\";i:29;s:7:\"aufgang\";i:30;s:4:\"baum\";i:31;s:4:\"blau\";i:32;s:6:\"bäume\";i:33;s:6:\"diffus\";i:34;s:5:\"früh\";i:35;s:9:\"gebrochen\";i:36;s:4:\"gott\";i:37;s:4:\"hell\";i:38;s:6:\"herbst\";i:39;s:8:\"hoffnung\";i:40;s:8:\"leuchten\";i:41;s:5:\"licht\";i:42;s:5:\"liebe\";i:43;s:6:\"morgen\";i:44;s:5:\"nebel\";i:45;s:8:\"stimmung\";i:46;s:3:\"tag\";i:47;s:3:\"tod\";i:48;s:14:\"undurchsichtig\";i:49;s:4:\"wald\";i:50;s:6:\"weinen\";i:51;s:5:\"weiß\";}}s:14:\"original_image\";s:12:\"Bild_01.jpeg\";}");
INSERT INTO `wp_postmeta` VALUES("79","16","_thumbnail_id","48");
INSERT INTO `wp_postmeta` VALUES("80","8","_thumbnail_id","6");
INSERT INTO `wp_postmeta` VALUES("81","3","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("82","3","_wp_trash_meta_time","1596782635");
INSERT INTO `wp_postmeta` VALUES("83","3","_wp_desired_post_slug","privacy-policy");
INSERT INTO `wp_postmeta` VALUES("84","2","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("85","2","_wp_trash_meta_time","1596782637");
INSERT INTO `wp_postmeta` VALUES("86","2","_wp_desired_post_slug","sample-page");
INSERT INTO `wp_postmeta` VALUES("87","56","_edit_lock","1596785087:1");
INSERT INTO `wp_postmeta` VALUES("88","59","_form","<label>
    [text* your-name placeholder \"Name\"] </label>

<label>
    [email* your-email placeholder \"Email\"] </label>

<label>
    [textarea your-message placeholder \"Message\"] </label>

[submit \"Submit\"]");
INSERT INTO `wp_postmeta` VALUES("89","59","_mail","a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:38:\"Skyloft Climbing park \"[your-subject]\"\";s:6:\"sender\";s:43:\"Skyloft Climbing park <skyloft@example.com>\";s:9:\"recipient\";s:19:\"skyloft@example.com\";s:4:\"body\";s:183:\"From: [your-name] <[your-email]>
Subject: Mail from [your-name]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Skyloft Climbing park (http://localhost)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("90","59","_mail_2","a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:38:\"Skyloft Climbing park \"[your-subject]\"\";s:6:\"sender\";s:43:\"Skyloft Climbing park <skyloft@example.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:118:\"Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Skyloft Climbing park (http://localhost)\";s:18:\"additional_headers\";s:29:\"Reply-To: skyloft@example.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}");
INSERT INTO `wp_postmeta` VALUES("91","59","_messages","a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}");
INSERT INTO `wp_postmeta` VALUES("92","59","_additional_settings","");
INSERT INTO `wp_postmeta` VALUES("93","59","_locale","en_US");
INSERT INTO `wp_postmeta` VALUES("94","60","_edit_lock","1596788731:1");
INSERT INTO `wp_postmeta` VALUES("95","62","_edit_lock","1596783389:1");
INSERT INTO `wp_postmeta` VALUES("96","63","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("97","63","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("98","63","_menu_item_object_id","5");
INSERT INTO `wp_postmeta` VALUES("99","63","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("100","63","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("101","63","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("102","63","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("103","63","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("104","64","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("105","64","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("106","64","_menu_item_object_id","8");
INSERT INTO `wp_postmeta` VALUES("107","64","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("108","64","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("109","64","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("110","64","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("111","64","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("112","65","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("113","65","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("114","65","_menu_item_object_id","16");
INSERT INTO `wp_postmeta` VALUES("115","65","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("116","65","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("117","65","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("118","65","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("119","65","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("120","66","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("121","66","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("122","66","_menu_item_object_id","56");
INSERT INTO `wp_postmeta` VALUES("123","66","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("124","66","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("125","66","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("126","66","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("127","66","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("128","67","_menu_item_type","post_type");
INSERT INTO `wp_postmeta` VALUES("129","67","_menu_item_menu_item_parent","0");
INSERT INTO `wp_postmeta` VALUES("130","67","_menu_item_object_id","60");
INSERT INTO `wp_postmeta` VALUES("131","67","_menu_item_object","page");
INSERT INTO `wp_postmeta` VALUES("132","67","_menu_item_target","");
INSERT INTO `wp_postmeta` VALUES("133","67","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("134","67","_menu_item_xfn","");
INSERT INTO `wp_postmeta` VALUES("135","67","_menu_item_url","");
INSERT INTO `wp_postmeta` VALUES("136","62","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("137","62","_wp_trash_meta_time","1596783442");
INSERT INTO `wp_postmeta` VALUES("138","68","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("139","68","_wp_trash_meta_time","1596783464");
INSERT INTO `wp_postmeta` VALUES("140","69","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("141","69","_wp_trash_meta_time","1596783483");
INSERT INTO `wp_postmeta` VALUES("142","70","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("143","70","_wp_trash_meta_time","1596783728");
INSERT INTO `wp_postmeta` VALUES("144","71","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("145","71","_wp_trash_meta_time","1596783987");
INSERT INTO `wp_postmeta` VALUES("146","72","_edit_lock","1596785970:1");
INSERT INTO `wp_postmeta` VALUES("147","72","_customize_restore_dismissed","1");
INSERT INTO `wp_postmeta` VALUES("148","73","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("149","73","_wp_trash_meta_time","1596784552");
INSERT INTO `wp_postmeta` VALUES("150","56","_thumbnail_id","27");
INSERT INTO `wp_postmeta` VALUES("151","60","_thumbnail_id","36");
INSERT INTO `wp_postmeta` VALUES("152","75","_wp_attached_file","2020/08/logo.png");
INSERT INTO `wp_postmeta` VALUES("153","75","_wp_attachment_metadata","a:5:{s:5:\"width\";i:209;s:6:\"height\";i:95;s:4:\"file\";s:16:\"2020/08/logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x95.png\";s:5:\"width\";i:150;s:6:\"height\";i:95;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("154","76","_wp_attached_file","2020/08/cropped-logo.png");
INSERT INTO `wp_postmeta` VALUES("155","76","_wp_attachment_context","site-icon");
INSERT INTO `wp_postmeta` VALUES("156","76","_wp_attachment_metadata","a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:24:\"2020/08/cropped-logo.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"cropped-logo-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"cropped-logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:24:\"cropped-logo-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:24:\"cropped-logo-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:24:\"cropped-logo-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:22:\"cropped-logo-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("157","77","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("158","77","_wp_trash_meta_time","1596786148");
INSERT INTO `wp_postmeta` VALUES("159","78","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("160","78","_wp_trash_meta_time","1596786346");
INSERT INTO `wp_postmeta` VALUES("161","60","_edit_last","1");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_posts` VALUES("1","1","2020-08-07 06:09:39","2020-08-07 06:09:39","<!-- wp:paragraph -->
<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>
<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2020-08-07 06:09:39","2020-08-07 06:09:39","","0","http://localhost/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2020-08-07 06:09:39","2020-08-07 06:09:39","<!-- wp:paragraph -->
<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...or something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>As a new WordPress user, you should go to <a href=\"http://localhost/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>
<!-- /wp:paragraph -->","Sample Page","","trash","closed","open","","sample-page__trashed","","","2020-08-07 06:43:57","2020-08-07 06:43:57","","0","http://localhost/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2020-08-07 06:09:39","2020-08-07 06:09:39","<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->","Privacy Policy","","trash","closed","open","","privacy-policy__trashed","","","2020-08-07 06:43:55","2020-08-07 06:43:55","","0","http://localhost/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2020-08-07 06:09:52","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2020-08-07 06:09:52","0000-00-00 00:00:00","","0","http://localhost/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2020-08-07 06:18:02","2020-08-07 06:18:02","<!-- wp:paragraph -->
<p>Tension, nerve kitzel, an ultimate outdoor experience at dizzy heights awaits you in our high-ropes skyloft. Five courses with different levels of difficulty ensure the right kick. At a height between 8 and 15 meters you move from tree crown to tree crown, from one platform to the next. They balance beams, tree trunks, ropes and overcome swinging rope constructions. They mobilize unimaginable forces. Experience the world from the bird\'s eye view. Discover yourself and rely on your team. Skyloft is pure adventure.</p>
<!-- /wp:paragraph -->","Start","","publish","closed","closed","","start","","","2020-08-07 06:42:33","2020-08-07 06:42:33","","0","http://localhost/?page_id=5","0","page","","0");
INSERT INTO `wp_posts` VALUES("6","1","2020-08-07 06:17:48","2020-08-07 06:17:48","","klettern - seile","","inherit","open","closed","","klettern-seile","","","2020-08-07 06:17:48","2020-08-07 06:17:48","","5","http://localhost/wp-content/uploads/2020/08/Bild_17.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("7","1","2020-08-07 06:18:02","2020-08-07 06:18:02","<!-- wp:paragraph -->
<p>Tension, nerve kitzel, an ultimate outdoor experience at dizzy heights awaits you in our high-ropes skyloft. Five courses with different levels of difficulty ensure the right kick. At a height between 8 and 15 meters you move from tree crown to tree crown, from one platform to the next. They balance beams, tree trunks, ropes and overcome swinging rope constructions. They mobilize unimaginable forces. Experience the world from the bird\'s eye view. Discover yourself and rely on your team. Skyloft is pure adventure.</p>
<!-- /wp:paragraph -->","Start","","inherit","closed","closed","","5-revision-v1","","","2020-08-07 06:18:02","2020-08-07 06:18:02","","5","http://localhost/2020/08/07/5-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("8","1","2020-08-07 06:29:34","2020-08-07 06:29:34","<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75},\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>You decide how high you are going.</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p> Start the mammoth tour, climb the Eagle Trail, choose the Silver Trail, the Magic Circle or the Flying Circus!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> In the Skyloft, you decide how far and how high you are going. Families with children, climbers, athletes, groups and companies are offered - depending on the degree - your experience of superlatives.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":13,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.2509754374279954,\"y\":0.5024594200981988},\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg);background-position:25.097543742799537% 50.24594200981988%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg\" alt=\"\" class=\"wp-image-13\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Family &amp; Leisure - The complete package!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Magic Circus and Silver Trail - here families with children and beginners can gather their first high-rope experiences. Children can climb together with an adult already from 6 years and a body size of approx. 1,20 meters with us. Children up to 14 years of age are allowed to go through the parcours only if accompanied by an adult. For birthday parties, book an exciting afternoon with our barbecue at our log cabin. Schools, we offer a complete educational program with preparation and follow-up in the class community.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":12,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg\" alt=\"\" class=\"wp-image-12\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Companies &amp; Incentives - Finding teams together!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A day in the Skyloft promises a lot of fun and action, as well as many new, valuable experiences in dealing with colleagues, employees or friends.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> We offer targeted management training as well as unforgettable company incentives and train the team ability of your employees.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> Courage, self-confidence, flexibility and risk-tolerance are trained. But also communication, mutual trust, solution-oriented thinking and overcoming internal boundaries.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":10,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg\" alt=\"\" class=\"wp-image-10\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Proficlimber - Not for the faint hearted!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flying Circus, Mammoth Tour, Eagleshorst - these are our three trails for climbers and professionals. For those who love the thrill of kiting, we will take you on the wire rope in our ultimate \"Flying Circus\". Naturally well secured with belt and carabiner. The mammoth tour requires strength and endurance. Only professors can create our eagle horsemanship. Ten very difficult to climb elements at a height of 15 meters are the challenge. Access is only permitted from 16 years.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Offers","","publish","closed","closed","","offers","","","2020-08-07 07:55:11","2020-08-07 07:55:11","","0","http://localhost/?page_id=8","0","page","","0");
INSERT INTO `wp_posts` VALUES("9","1","2020-08-07 06:21:21","2020-08-07 06:21:21","","Seilklettern","","inherit","open","closed","","seilklettern","","","2020-08-07 06:21:21","2020-08-07 06:21:21","","8","http://localhost/wp-content/uploads/2020/08/Bild_08.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("10","1","2020-08-07 06:26:32","2020-08-07 06:26:32","","preparing for the risky jump","Two girls preparing for a jump high above the ground","inherit","open","closed","","preparing-for-the-risky-jump","","","2020-08-07 06:26:32","2020-08-07 06:26:32","","8","http://localhost/wp-content/uploads/2020/08/Bild_21.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("11","1","2020-08-07 06:29:34","2020-08-07 06:29:34","<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75}} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>You decide how high you are going.</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p> Start the mammoth tour, climb the Eagle Trail, choose the Silver Trail, the Magic Circle or the Flying Circus!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> In the Skyloft, you decide how far and how high you are going. Families with children, climbers, athletes, groups and companies are offered - depending on the degree - your experience of superlatives.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75}} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Family &amp; Leisure - The complete package!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Magic Circus and Silver Trail - here families with children and beginners can gather their first high-rope experiences. Children can climb together with an adult already from 6 years and a body size of approx. 1,20 meters with us. Children up to 14 years of age are allowed to go through the parcours only if accompanied by an adult. For birthday parties, book an exciting afternoon with our barbecue at our log cabin. Schools, we offer a complete educational program with preparation and follow-up in the class community.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75}} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Companies &amp; Incentives - Finding teams together!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A day in the Skyloft promises a lot of fun and action, as well as many new, valuable experiences in dealing with colleagues, employees or friends.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> We offer targeted management training as well as unforgettable company incentives and train the team ability of your employees.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> Courage, self-confidence, flexibility and risk-tolerance are trained. But also communication, mutual trust, solution-oriented thinking and overcoming internal boundaries.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":10,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg\" alt=\"\" class=\"wp-image-10\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Proficlimber - Not for the faint hearted!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flying Circus, Mammoth Tour, Eagleshorst - these are our three trails for climbers and professionals. For those who love the thrill of kiting, we will take you on the wire rope in our ultimate \"Flying Circus\". Naturally well secured with belt and carabiner. The mammoth tour requires strength and endurance. Only professors can create our eagle horsemanship. Ten very difficult to climb elements at a height of 15 meters are the challenge. Access is only permitted from 16 years.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Offers","","inherit","closed","closed","","8-revision-v1","","","2020-08-07 06:29:34","2020-08-07 06:29:34","","8","http://localhost/2020/08/07/8-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("12","1","2020-08-07 06:29:46","2020-08-07 06:29:46","","Bild_15","","inherit","open","closed","","bild_15","","","2020-08-07 06:29:46","2020-08-07 06:29:46","","8","http://localhost/wp-content/uploads/2020/08/Bild_15.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("13","1","2020-08-07 06:30:15","2020-08-07 06:30:15","","kleiner Pirat","kleiner Pirat","inherit","open","closed","","kleiner-pirat","","","2020-08-07 06:30:15","2020-08-07 06:30:15","","8","http://localhost/wp-content/uploads/2020/08/Bild_19.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("14","1","2020-08-07 06:30:37","2020-08-07 06:30:37","<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75}} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>You decide how high you are going.</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p> Start the mammoth tour, climb the Eagle Trail, choose the Silver Trail, the Magic Circle or the Flying Circus!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> In the Skyloft, you decide how far and how high you are going. Families with children, climbers, athletes, groups and companies are offered - depending on the degree - your experience of superlatives.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":13,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.2509754374279954,\"y\":0.5024594200981988}} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg);background-position:25.097543742799537% 50.24594200981988%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg\" alt=\"\" class=\"wp-image-13\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Family &amp; Leisure - The complete package!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Magic Circus and Silver Trail - here families with children and beginners can gather their first high-rope experiences. Children can climb together with an adult already from 6 years and a body size of approx. 1,20 meters with us. Children up to 14 years of age are allowed to go through the parcours only if accompanied by an adult. For birthday parties, book an exciting afternoon with our barbecue at our log cabin. Schools, we offer a complete educational program with preparation and follow-up in the class community.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":12,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg\" alt=\"\" class=\"wp-image-12\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Companies &amp; Incentives - Finding teams together!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A day in the Skyloft promises a lot of fun and action, as well as many new, valuable experiences in dealing with colleagues, employees or friends.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> We offer targeted management training as well as unforgettable company incentives and train the team ability of your employees.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> Courage, self-confidence, flexibility and risk-tolerance are trained. But also communication, mutual trust, solution-oriented thinking and overcoming internal boundaries.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":10,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg\" alt=\"\" class=\"wp-image-10\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Proficlimber - Not for the faint hearted!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flying Circus, Mammoth Tour, Eagleshorst - these are our three trails for climbers and professionals. For those who love the thrill of kiting, we will take you on the wire rope in our ultimate \"Flying Circus\". Naturally well secured with belt and carabiner. The mammoth tour requires strength and endurance. Only professors can create our eagle horsemanship. Ten very difficult to climb elements at a height of 15 meters are the challenge. Access is only permitted from 16 years.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Offers","","inherit","closed","closed","","8-revision-v1","","","2020-08-07 06:30:37","2020-08-07 06:30:37","","8","http://localhost/2020/08/07/8-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("16","1","2020-08-07 06:33:57","2020-08-07 06:33:57","<!-- wp:nextend/smartslider3 {\"slider\":\"2\"} -->
<div class=\"wp-block-nextend-smartslider3\">[smartslider3 slider=\"2\"]</div>
<!-- /wp:nextend/smartslider3 -->","Park","","publish","closed","closed","","park","","","2020-08-07 06:43:45","2020-08-07 06:43:45","","0","http://localhost/?page_id=16","0","page","","0");
INSERT INTO `wp_posts` VALUES("17","1","2020-08-07 06:33:57","2020-08-07 06:33:57","","Park","","inherit","closed","closed","","16-revision-v1","","","2020-08-07 06:33:57","2020-08-07 06:33:57","","16","http://localhost/2020/08/07/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("19","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_08","","inherit","open","closed","","bild_08","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_08.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("20","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_07","","inherit","open","closed","","bild_07","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_07.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("21","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_06","","inherit","open","closed","","bild_06","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_06.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("22","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_09","","inherit","open","closed","","bild_09","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_09.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("23","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_05","","inherit","open","closed","","bild_05","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_05.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("24","1","2020-08-07 06:36:33","2020-08-07 06:36:33","","Bild_04","","inherit","open","closed","","bild_04","","","2020-08-07 06:36:33","2020-08-07 06:36:33","","0","http://localhost/wp-content/uploads/2020/08/Bild_04.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("25","1","2020-08-07 06:36:35","2020-08-07 06:36:35","","Bild_11","","inherit","open","closed","","bild_11","","","2020-08-07 06:36:35","2020-08-07 06:36:35","","0","http://localhost/wp-content/uploads/2020/08/Bild_11.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("26","1","2020-08-07 06:36:35","2020-08-07 06:36:35","","Bild_10","","inherit","open","closed","","bild_10","","","2020-08-07 06:36:35","2020-08-07 06:36:35","","0","http://localhost/wp-content/uploads/2020/08/Bild_10.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("27","1","2020-08-07 06:36:35","2020-08-07 06:36:35","","Bild_12","","inherit","open","closed","","bild_12","","","2020-08-07 06:36:35","2020-08-07 06:36:35","","0","http://localhost/wp-content/uploads/2020/08/Bild_12.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("28","1","2020-08-07 06:36:36","2020-08-07 06:36:36","","Bild_13","","inherit","open","closed","","bild_13","","","2020-08-07 06:36:36","2020-08-07 06:36:36","","0","http://localhost/wp-content/uploads/2020/08/Bild_13.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("29","1","2020-08-07 06:36:36","2020-08-07 06:36:36","","Bild_14","","inherit","open","closed","","bild_14","","","2020-08-07 06:36:36","2020-08-07 06:36:36","","0","http://localhost/wp-content/uploads/2020/08/Bild_14.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("30","1","2020-08-07 06:36:37","2020-08-07 06:36:37","","Bild_15","","inherit","open","closed","","bild_15-2","","","2020-08-07 06:36:37","2020-08-07 06:36:37","","0","http://localhost/wp-content/uploads/2020/08/Bild_15.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("31","1","2020-08-07 06:36:38","2020-08-07 06:36:38","","Bild_16","","inherit","open","closed","","bild_16","","","2020-08-07 06:36:38","2020-08-07 06:36:38","","0","http://localhost/wp-content/uploads/2020/08/Bild_16.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("32","1","2020-08-07 06:36:38","2020-08-07 06:36:38","","Bild_17","","inherit","open","closed","","bild_17","","","2020-08-07 06:36:38","2020-08-07 06:36:38","","0","http://localhost/wp-content/uploads/2020/08/Bild_17.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("33","1","2020-08-07 06:36:39","2020-08-07 06:36:39","","Bild_18","","inherit","open","closed","","bild_18","","","2020-08-07 06:36:39","2020-08-07 06:36:39","","0","http://localhost/wp-content/uploads/2020/08/Bild_18.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("34","1","2020-08-07 06:36:41","2020-08-07 06:36:41","","Bild_19","","inherit","open","closed","","bild_19","","","2020-08-07 06:36:41","2020-08-07 06:36:41","","0","http://localhost/wp-content/uploads/2020/08/Bild_19.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("35","1","2020-08-07 06:36:41","2020-08-07 06:36:41","","Bild_20","","inherit","open","closed","","bild_20","","","2020-08-07 06:36:41","2020-08-07 06:36:41","","0","http://localhost/wp-content/uploads/2020/08/Bild_20.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("36","1","2020-08-07 06:36:42","2020-08-07 06:36:42","","Bild_21","","inherit","open","closed","","bild_21","","","2020-08-07 06:36:42","2020-08-07 06:36:42","","0","http://localhost/wp-content/uploads/2020/08/Bild_21.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("37","1","2020-08-07 06:36:42","2020-08-07 06:36:42","","Bild_22","","inherit","open","closed","","bild_22","","","2020-08-07 06:36:42","2020-08-07 06:36:42","","0","http://localhost/wp-content/uploads/2020/08/Bild_22.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("38","1","2020-08-07 06:36:42","2020-08-07 06:36:42","","Bild_23","","inherit","open","closed","","bild_23","","","2020-08-07 06:36:42","2020-08-07 06:36:42","","0","http://localhost/wp-content/uploads/2020/08/Bild_23.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("39","1","2020-08-07 06:36:42","2020-08-07 06:36:42","","Bild_24","","inherit","open","closed","","bild_24","","","2020-08-07 06:36:42","2020-08-07 06:36:42","","0","http://localhost/wp-content/uploads/2020/08/Bild_24.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("40","1","2020-08-07 06:36:43","2020-08-07 06:36:43","","Bild_25","","inherit","open","closed","","bild_25","","","2020-08-07 06:36:43","2020-08-07 06:36:43","","0","http://localhost/wp-content/uploads/2020/08/Bild_25.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("41","1","2020-08-07 06:36:43","2020-08-07 06:36:43","","Bild_26","","inherit","open","closed","","bild_26","","","2020-08-07 06:36:43","2020-08-07 06:36:43","","0","http://localhost/wp-content/uploads/2020/08/Bild_26.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("42","1","2020-08-07 06:36:44","2020-08-07 06:36:44","","Bild_27","","inherit","open","closed","","bild_27","","","2020-08-07 06:36:44","2020-08-07 06:36:44","","0","http://localhost/wp-content/uploads/2020/08/Bild_27.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("43","1","2020-08-07 06:36:45","2020-08-07 06:36:45","","Bild_28","","inherit","open","closed","","bild_28","","","2020-08-07 06:36:45","2020-08-07 06:36:45","","0","http://localhost/wp-content/uploads/2020/08/Bild_28.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("44","1","2020-08-07 06:36:45","2020-08-07 06:36:45","","Bild_29","","inherit","open","closed","","bild_29","","","2020-08-07 06:36:45","2020-08-07 06:36:45","","0","http://localhost/wp-content/uploads/2020/08/Bild_29.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("45","1","2020-08-07 06:36:46","2020-08-07 06:36:46","","Bild_30","","inherit","open","closed","","bild_30","","","2020-08-07 06:36:46","2020-08-07 06:36:46","","0","http://localhost/wp-content/uploads/2020/08/Bild_30.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("46","1","2020-08-07 06:36:47","2020-08-07 06:36:47","","Bild_31","","inherit","open","closed","","bild_31","","","2020-08-07 06:36:47","2020-08-07 06:36:47","","0","http://localhost/wp-content/uploads/2020/08/Bild_31.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("47","1","2020-08-07 06:36:47","2020-08-07 06:36:47","","Bild_01","","inherit","open","closed","","bild_01","","","2020-08-07 06:36:47","2020-08-07 06:36:47","","0","http://localhost/wp-content/uploads/2020/08/Bild_01.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("48","1","2020-08-07 06:36:48","2020-08-07 06:36:48","","Bild_02","","inherit","open","closed","","bild_02","","","2020-08-07 06:36:48","2020-08-07 06:36:48","","0","http://localhost/wp-content/uploads/2020/08/Bild_02.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("49","1","2020-08-07 06:36:48","2020-08-07 06:36:48","","Bild_03","","inherit","open","closed","","bild_03","","","2020-08-07 06:36:48","2020-08-07 06:36:48","","0","http://localhost/wp-content/uploads/2020/08/Bild_03.jpeg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("50","1","2020-08-07 06:39:04","2020-08-07 06:39:04","<!-- wp:nextend/smartslider3 {\"slider\":\"2\"} -->
<div class=\"wp-block-nextend-smartslider3\">[smartslider3 slider=\"2\"]</div>
<!-- /wp:nextend/smartslider3 -->","Park","","inherit","closed","closed","","16-revision-v1","","","2020-08-07 06:39:04","2020-08-07 06:39:04","","16","http://localhost/2020/08/07/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("51","1","2020-08-07 06:40:25","2020-08-07 06:40:25","<!-- wp:paragraph -->
<p>asdf</p>
<!-- /wp:paragraph -->

<!-- wp:nextend/smartslider3 {\"slider\":\"2\"} -->
<div class=\"wp-block-nextend-smartslider3\">[smartslider3 slider=\"2\"]</div>
<!-- /wp:nextend/smartslider3 -->","Park","","inherit","closed","closed","","16-revision-v1","","","2020-08-07 06:40:25","2020-08-07 06:40:25","","16","http://localhost/2020/08/07/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("52","1","2020-08-07 06:40:25","2020-08-07 06:40:25","<!-- wp:paragraph -->
<p>asdf</p>
<!-- /wp:paragraph -->

<!-- wp:nextend/smartslider3 {\"slider\":\"2\"} -->
<div class=\"wp-block-nextend-smartslider3\">[smartslider3 slider=\"2\"]</div>
<!-- /wp:nextend/smartslider3 -->","Park","","inherit","closed","closed","","16-autosave-v1","","","2020-08-07 06:40:25","2020-08-07 06:40:25","","16","http://localhost/2020/08/07/16-autosave-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("53","1","2020-08-07 06:43:45","2020-08-07 06:43:45","<!-- wp:nextend/smartslider3 {\"slider\":\"2\"} -->
<div class=\"wp-block-nextend-smartslider3\">[smartslider3 slider=\"2\"]</div>
<!-- /wp:nextend/smartslider3 -->","Park","","inherit","closed","closed","","16-revision-v1","","","2020-08-07 06:43:45","2020-08-07 06:43:45","","16","http://localhost/2020/08/07/16-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("54","1","2020-08-07 06:43:55","2020-08-07 06:43:55","<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->","Privacy Policy","","inherit","closed","closed","","3-revision-v1","","","2020-08-07 06:43:55","2020-08-07 06:43:55","","3","http://localhost/2020/08/07/3-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("55","1","2020-08-07 06:43:57","2020-08-07 06:43:57","<!-- wp:paragraph -->
<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...or something like this:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>As a new WordPress user, you should go to <a href=\"http://localhost/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>
<!-- /wp:paragraph -->","Sample Page","","inherit","closed","closed","","2-revision-v1","","","2020-08-07 06:43:57","2020-08-07 06:43:57","","2","http://localhost/2020/08/07/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("56","1","2020-08-07 06:46:37","2020-08-07 06:46:37","<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column {\"width\":66.66} -->
<div class=\"wp-block-column\" style=\"flex-basis:66.66%\"><!-- wp:paragraph -->
<p>Adults<br>Children from 6 to 13 years<br>Teenagers from 14 to 18 years<br>Family (2 adults and 2 children)<br>Family (2 adults und 3 children)<br>Group more than 10 adults, per adult<br>Group more than 10 children, per child<br>Students</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":33.33} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">18 EUR<br>
9 EUR<br>
14 EUR<br>
49 EUR<br>
56 EUR<br>
17 EUR<br>
7 EUR<br>
16 EUR</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Prices","","publish","closed","closed","","prices","","","2020-08-07 07:27:05","2020-08-07 07:27:05","","0","http://localhost/?page_id=56","0","page","","0");
INSERT INTO `wp_posts` VALUES("57","1","2020-08-07 06:46:37","2020-08-07 06:46:37","<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column {\"width\":66.66} -->
<div class=\"wp-block-column\" style=\"flex-basis:66.66%\"><!-- wp:paragraph -->
<p>Adults<br>Children from 6 to 13 years<br>Teenagers from 14 to 18 years<br>Family (2 adults and 2 children)<br>Family (2 adults und 3 children)<br>Group more than 10 adults, per adult<br>Group more than 10 children, per child<br>Students</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":33.33} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">18 EUR<br>
9 EUR<br>
14 EUR<br>
49 EUR<br>
56 EUR<br>
17 EUR<br>
7 EUR<br>
16 EUR</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->","Prices","","inherit","closed","closed","","56-revision-v1","","","2020-08-07 06:46:37","2020-08-07 06:46:37","","56","http://localhost/2020/08/07/56-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("58","1","2020-08-07 06:47:36","2020-08-07 06:47:36","<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column {\"width\":66.66} -->
<div class=\"wp-block-column\" style=\"flex-basis:66.66%\"><!-- wp:paragraph -->
<p>Adults<br>Children from 6 to 13 years<br>Teenagers from 14 to 18 years<br>Family (2 adults and 2 children)<br>Family (2 adults und 3 children)<br>Group more than 10 adults, per adult<br>Group more than 10 children, per child<br>Students</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {\"width\":33.33} -->
<div class=\"wp-block-column\" style=\"flex-basis:33.33%\"><!-- wp:paragraph {\"align\":\"right\"} -->
<p class=\"has-text-align-right\">18 EUR<br>
9 EUR<br>
14 EUR<br>
49 EUR<br>
56 EUR<br>
17 EUR<br>
7 EUR<br>
16 EUR</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Prices","","inherit","closed","closed","","56-revision-v1","","","2020-08-07 06:47:36","2020-08-07 06:47:36","","56","http://localhost/2020/08/07/56-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("59","1","2020-08-07 06:48:25","2020-08-07 06:48:25","<label>
    [text* your-name placeholder \"Name\"] </label>

<label>
    [email* your-email placeholder \"Email\"] </label>

<label>
    [textarea your-message placeholder \"Message\"] </label>

[submit \"Submit\"]
1
Skyloft Climbing park \"[your-subject]\"
Skyloft Climbing park <skyloft@example.com>
skyloft@example.com
From: [your-name] <[your-email]>
Subject: Mail from [your-name]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Skyloft Climbing park (http://localhost)
Reply-To: [your-email]




Skyloft Climbing park \"[your-subject]\"
Skyloft Climbing park <skyloft@example.com>
[your-email]
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on Skyloft Climbing park (http://localhost)
Reply-To: skyloft@example.com



Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.
The date format is incorrect.
The date is before the earliest one allowed.
The date is after the latest one allowed.
There was an unknown error uploading the file.
You are not allowed to upload files of this type.
The file is too big.
There was an error uploading the file.
The number format is invalid.
The number is smaller than the minimum allowed.
The number is larger than the maximum allowed.
The answer to the quiz is incorrect.
The e-mail address entered is invalid.
The URL is invalid.
The telephone number is invalid.","Contact form 1","","publish","closed","closed","","contact-form-1","","","2020-08-07 06:53:43","2020-08-07 06:53:43","","0","http://localhost/?post_type=wpcf7_contact_form&#038;p=59","0","wpcf7_contact_form","","0");
INSERT INTO `wp_posts` VALUES("60","1","2020-08-07 06:50:45","2020-08-07 06:50:45","<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">ACME Co.<br>
Some Important Street 123<br>
Main City 54321</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">Phone:  <a href=\"tel:+115554321\">+1 1 555 4321</a><br> E-Mail: <a href=\"mailto:info@skyloft.com\">info@skyloft.com</a></p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph -->
<p> [contact-form-7 id=\"59\" title=\"Contact form 1\"] </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->","Contact","","publish","closed","closed","","contact","","","2020-08-07 08:16:48","2020-08-07 08:16:48","","0","http://localhost/?page_id=60","0","page","","0");
INSERT INTO `wp_posts` VALUES("61","1","2020-08-07 06:50:45","2020-08-07 06:50:45","<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">ACME Co.<br>
Some Important Street 123<br>
Main City 54321</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">Phone:  +1 1 555 4321<br>
E-Mail: info@skyloft.com</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">[contact-form-7 id=\"59\" title=\"Contact form 1\"]</p>
<!-- /wp:paragraph -->","Contact","","inherit","closed","closed","","60-revision-v1","","","2020-08-07 06:50:45","2020-08-07 06:50:45","","60","http://localhost/2020/08/07/60-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("62","1","2020-08-07 06:57:22","2020-08-07 06:57:22","{
    \"twentytwenty::background_color\": {
        \"value\": \"#ffffff\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::header_footer_background_color\": {
        \"value\": \"#005ca8\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::accent_hue_active\": {
        \"value\": \"default\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::accent_hue\": {
        \"value\": 344,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::accent_accessible_colors\": {
        \"value\": {
            \"content\": {
                \"text\": \"#000000\",
                \"accent\": \"#e22658\",
                \"background\": \"#ffffff\",
                \"borders\": \"#dbdbdb\",
                \"secondary\": \"#6d6d6d\"
            },
            \"header-footer\": {
                \"text\": \"#ffffff\",
                \"accent\": \"#f2c9d1\",
                \"background\": \"#005ca8\",
                \"borders\": \"#0073d1\",
                \"secondary\": \"#d4e2f0\"
            }
        },
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::enable_header_search\": {
        \"value\": true,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:56:26\"
    },
    \"twentytwenty::nav_menu_locations[primary]\": {
        \"value\": -1519452122392090600,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"twentytwenty::nav_menu_locations[expanded]\": {
        \"value\": 0,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu[-1519452122392090600]\": {
        \"value\": {
            \"name\": \"header\",
            \"description\": \"\",
            \"parent\": 0,
            \"auto_add\": false
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu_item[-6957494425759777000]\": {
        \"value\": {
            \"object_id\": 5,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 1,
            \"type\": \"post_type\",
            \"title\": \"Start\",
            \"url\": \"http://localhost/start/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"Start\",
            \"nav_menu_term_id\": -1519452122392090600,
            \"_invalid\": false,
            \"type_label\": \"Page\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu_item[-8639485503596702000]\": {
        \"value\": {
            \"object_id\": 8,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 2,
            \"type\": \"post_type\",
            \"title\": \"Offers\",
            \"url\": \"http://localhost/offers/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"Offers\",
            \"nav_menu_term_id\": -1519452122392090600,
            \"_invalid\": false,
            \"type_label\": \"Page\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu_item[-5076439285072536000]\": {
        \"value\": {
            \"object_id\": 16,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 3,
            \"type\": \"post_type\",
            \"title\": \"Park\",
            \"url\": \"http://localhost/park/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"Park\",
            \"nav_menu_term_id\": -1519452122392090600,
            \"_invalid\": false,
            \"type_label\": \"Page\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu_item[-7690606331899873000]\": {
        \"value\": {
            \"object_id\": 56,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 4,
            \"type\": \"post_type\",
            \"title\": \"Prices\",
            \"url\": \"http://localhost/prices/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"Prices\",
            \"nav_menu_term_id\": -1519452122392090600,
            \"_invalid\": false,
            \"type_label\": \"Page\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    },
    \"nav_menu_item[-5456939769445566000]\": {
        \"value\": {
            \"object_id\": 60,
            \"object\": \"page\",
            \"menu_item_parent\": 0,
            \"position\": 5,
            \"type\": \"post_type\",
            \"title\": \"Contact\",
            \"url\": \"http://localhost/contact/\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"status\": \"publish\",
            \"original_title\": \"Contact\",
            \"nav_menu_term_id\": -1519452122392090600,
            \"_invalid\": false,
            \"type_label\": \"Page\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:22\"
    }
}","","","trash","closed","closed","","561b94e7-05b9-46c4-9b9f-b746d89f4b07","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/?p=62","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("63","1","2020-08-07 06:57:22","2020-08-07 06:57:22"," ","","","publish","closed","closed","","63","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/2020/08/07/63/","1","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("64","1","2020-08-07 06:57:22","2020-08-07 06:57:22"," ","","","publish","closed","closed","","64","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/2020/08/07/64/","2","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("65","1","2020-08-07 06:57:22","2020-08-07 06:57:22"," ","","","publish","closed","closed","","65","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/2020/08/07/65/","3","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("66","1","2020-08-07 06:57:22","2020-08-07 06:57:22"," ","","","publish","closed","closed","","66","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/2020/08/07/66/","4","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("67","1","2020-08-07 06:57:22","2020-08-07 06:57:22"," ","","","publish","closed","closed","","67","","","2020-08-07 06:57:22","2020-08-07 06:57:22","","0","http://localhost/2020/08/07/67/","5","nav_menu_item","","0");
INSERT INTO `wp_posts` VALUES("68","1","2020-08-07 06:57:44","2020-08-07 06:57:44","{
    \"twentytwenty::enable_header_search\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:44\"
    },
    \"twentytwenty::show_author_bio\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:57:44\"
    }
}","","","trash","closed","closed","","a8747ab4-dff8-4fab-84b4-736a4cc17e22","","","2020-08-07 06:57:44","2020-08-07 06:57:44","","0","http://localhost/2020/08/07/a8747ab4-dff8-4fab-84b4-736a4cc17e22/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("69","1","2020-08-07 06:58:03","2020-08-07 06:58:03","{
    \"show_on_front\": {
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:58:03\"
    },
    \"page_on_front\": {
        \"value\": \"5\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 06:58:03\"
    }
}","","","trash","closed","closed","","985e3961-ad0c-4914-8d49-2933c1a6f3b1","","","2020-08-07 06:58:03","2020-08-07 06:58:03","","0","http://localhost/2020/08/07/985e3961-ad0c-4914-8d49-2933c1a6f3b1/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("70","1","2020-08-07 07:02:08","2020-08-07 07:02:08","{
    \"old_sidebars_widgets_data\": {
        \"value\": {
            \"wp_inactive_widgets\": [],
            \"sidebar-1\": [
                \"search-2\",
                \"recent-posts-2\",
                \"recent-comments-2\"
            ],
            \"sidebar-2\": [
                \"archives-2\",
                \"categories-2\",
                \"meta-2\"
            ]
        },
        \"type\": \"global_variable\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:02:06\"
    },
    \"skyloft::nav_menu_locations[primary]\": {
        \"value\": 2,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:02:06\"
    }
}","","","trash","closed","closed","","aabaff79-2679-44b7-a72a-136ac80df843","","","2020-08-07 07:02:08","2020-08-07 07:02:08","","0","http://localhost/2020/08/07/aabaff79-2679-44b7-a72a-136ac80df843/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("71","1","2020-08-07 07:06:27","2020-08-07 07:06:27","{
    \"sidebars_widgets[sidebar-1]\": {
        \"value\": [],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:06:27\"
    }
}","","","trash","closed","closed","","336bcda9-8af3-4311-a03a-c5c3c2a3e39d","","","2020-08-07 07:06:27","2020-08-07 07:06:27","","0","http://localhost/2020/08/07/336bcda9-8af3-4311-a03a-c5c3c2a3e39d/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("72","1","2020-08-07 07:09:53","0000-00-00 00:00:00","{
    \"skyloft::theme_option_setting\": {
        \"value\": \"default\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:09:53\"
    },
    \"skyloft::preset_style_setting\": {
        \"value\": \"default\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:09:53\"
    }
}","","","auto-draft","closed","closed","","934f999d-9c5f-406a-a76f-00ba06783e1e","","","2020-08-07 07:09:53","0000-00-00 00:00:00","","0","http://localhost/?p=72","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("73","1","2020-08-07 07:15:52","2020-08-07 07:15:52","{
    \"skyloft::header_banner_title_setting\": {
        \"value\": \"Skyloft Climbing Park\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:15:52\"
    },
    \"skyloft::header_banner_tagline_setting\": {
        \"value\": \"For your excitement!\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:15:52\"
    },
    \"skyloft::header_banner_visibility\": {
        \"value\": false,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:15:52\"
    }
}","","","trash","closed","closed","","d2b681e3-7493-458e-9b9f-e3ff0d686397","","","2020-08-07 07:15:52","2020-08-07 07:15:52","","0","http://localhost/2020/08/07/d2b681e3-7493-458e-9b9f-e3ff0d686397/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("74","1","2020-08-07 07:32:29","2020-08-07 07:32:29","<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">ACME Co.<br>
Some Important Street 123<br>
Main City 54321</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">Phone:  +1 1 555 4321<br> E-Mail: info@skyloft.com</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph -->
<p> [contact-form-7 id=\"59\" title=\"Contact form 1\"] </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->","Contact","","inherit","closed","closed","","60-revision-v1","","","2020-08-07 07:32:29","2020-08-07 07:32:29","","60","http://localhost/2020/08/07/60-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("75","1","2020-08-07 07:41:46","2020-08-07 07:41:46","","logo","","inherit","open","closed","","logo","","","2020-08-07 07:41:46","2020-08-07 07:41:46","","0","http://localhost/wp-content/uploads/2020/08/logo.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("76","1","2020-08-07 07:42:19","2020-08-07 07:42:19","http://localhost/wp-content/uploads/2020/08/cropped-logo.png","cropped-logo.png","","inherit","open","closed","","cropped-logo-png","","","2020-08-07 07:42:19","2020-08-07 07:42:19","","0","http://localhost/wp-content/uploads/2020/08/cropped-logo.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("77","1","2020-08-07 07:42:27","2020-08-07 07:42:27","{
    \"site_icon\": {
        \"value\": 76,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:42:27\"
    },
    \"skyloft::header_textcolor\": {
        \"value\": \"blank\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:42:27\"
    },
    \"skyloft::wp_bootstrap_starter_logo\": {
        \"value\": \"http://localhost/wp-content/uploads/2020/08/logo.png\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:42:27\"
    }
}","","","trash","closed","closed","","01b43599-d78b-4282-adbd-8740cb85be92","","","2020-08-07 07:42:27","2020-08-07 07:42:27","","0","http://localhost/2020/08/07/01b43599-d78b-4282-adbd-8740cb85be92/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("78","1","2020-08-07 07:45:46","2020-08-07 07:45:46","{
    \"skyloft::background_color\": {
        \"value\": \"#ffffff\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2020-08-07 07:45:46\"
    }
}","","","trash","closed","closed","","34c1d3cd-8813-4911-8177-3403addebe5d","","","2020-08-07 07:45:46","2020-08-07 07:45:46","","0","http://localhost/2020/08/07/34c1d3cd-8813-4911-8177-3403addebe5d/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("79","1","2020-08-07 07:55:11","2020-08-07 07:55:11","<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":9,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.5,\"y\":0.75},\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg);background-position:50% 75%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_08-686x1024.jpg\" alt=\"\" class=\"wp-image-9\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>You decide how high you are going.</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p> Start the mammoth tour, climb the Eagle Trail, choose the Silver Trail, the Magic Circle or the Flying Circus!</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> In the Skyloft, you decide how far and how high you are going. Families with children, climbers, athletes, groups and companies are offered - depending on the degree - your experience of superlatives.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":13,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"focalPoint\":{\"x\":0.2509754374279954,\"y\":0.5024594200981988},\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg);background-position:25.097543742799537% 50.24594200981988%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_19-1024x683.jpg\" alt=\"\" class=\"wp-image-13\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Family &amp; Leisure - The complete package!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Magic Circus and Silver Trail - here families with children and beginners can gather their first high-rope experiences. Children can climb together with an adult already from 6 years and a body size of approx. 1,20 meters with us. Children up to 14 years of age are allowed to go through the parcours only if accompanied by an adult. For birthday parties, book an exciting afternoon with our barbecue at our log cabin. Schools, we offer a complete educational program with preparation and follow-up in the class community.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":12,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true,\"className\":\"mb-3\"} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill mb-3\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_15-680x1024.jpg\" alt=\"\" class=\"wp-image-12\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Companies &amp; Incentives - Finding teams together!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A day in the Skyloft promises a lot of fun and action, as well as many new, valuable experiences in dealing with colleagues, employees or friends.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> We offer targeted management training as well as unforgettable company incentives and train the team ability of your employees.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p> Courage, self-confidence, flexibility and risk-tolerance are trained. But also communication, mutual trust, solution-oriented thinking and overcoming internal boundaries.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:media-text {\"mediaPosition\":\"right\",\"mediaId\":10,\"mediaType\":\"image\",\"mediaWidth\":25,\"imageFill\":true} -->
<div class=\"wp-block-media-text alignwide has-media-on-the-right is-image-fill\" style=\"grid-template-columns:auto 25%\"><figure class=\"wp-block-media-text__media\" style=\"background-image:url(http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg);background-position:50% 50%\"><img src=\"http://localhost/wp-content/uploads/2020/08/Bild_21-1024x685.jpg\" alt=\"\" class=\"wp-image-10\"/></figure><div class=\"wp-block-media-text__content\"><!-- wp:heading {\"level\":3} -->
<h3>Proficlimber - Not for the faint hearted!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Flying Circus, Mammoth Tour, Eagleshorst - these are our three trails for climbers and professionals. For those who love the thrill of kiting, we will take you on the wire rope in our ultimate \"Flying Circus\". Naturally well secured with belt and carabiner. The mammoth tour requires strength and endurance. Only professors can create our eagle horsemanship. Ten very difficult to climb elements at a height of 15 meters are the challenge. Access is only permitted from 16 years.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:media-text -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->","Offers","","inherit","closed","closed","","8-revision-v1","","","2020-08-07 07:55:11","2020-08-07 07:55:11","","8","http://localhost/2020/08/07/8-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("80","1","2020-08-07 08:16:48","2020-08-07 08:16:48","<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">ACME Co.<br>
Some Important Street 123<br>
Main City 54321</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {\"align\":\"center\"} -->
<p class=\"has-text-align-center\">Phone:  <a href=\"tel:+115554321\">+1 1 555 4321</a><br> E-Mail: <a href=\"mailto:info@skyloft.com\">info@skyloft.com</a></p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class=\"wp-block-columns\"><!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"><!-- wp:paragraph -->
<p> [contact-form-7 id=\"59\" title=\"Contact form 1\"] </p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class=\"wp-block-column\"></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->","Contact","","inherit","closed","closed","","60-revision-v1","","","2020-08-07 08:16:48","2020-08-07 08:16:48","","60","http://localhost/2020/08/07/60-revision-v1/","0","revision","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("63","2","0");
INSERT INTO `wp_term_relationships` VALUES("64","2","0");
INSERT INTO `wp_term_relationships` VALUES("65","2","0");
INSERT INTO `wp_term_relationships` VALUES("66","2","0");
INSERT INTO `wp_term_relationships` VALUES("67","2","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","nav_menu","","0","5");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("2","header","header","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","aDmin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"80b1ac0580162aff165d586f2155a2f0f279b8cb45f13b4f7fa1090f40abf7be\";a:4:{s:10:\"expiration\";i:1596953390;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36\";s:5:\"login\";i:1596780590;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_user-settings","libraryContent=browse&mfold=o");
INSERT INTO `wp_usermeta` VALUES("18","1","wp_user-settings-time","1596780587");
INSERT INTO `wp_usermeta` VALUES("19","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("20","1","nav_menu_recently_edited","2");
INSERT INTO `wp_usermeta` VALUES("21","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("22","1","metaboxhidden_nav-menus","a:1:{i:0;s:12:\"add-post_tag\";}");
INSERT INTO `wp_usermeta` VALUES("23","1","closedpostboxes_page","a:1:{i:0;s:17:\"sfsi-social-media\";}");
INSERT INTO `wp_usermeta` VALUES("24","1","metaboxhidden_page","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("25","1","aioseop_notice_time_set_review_plugin_cta","1596789945");
INSERT INTO `wp_usermeta` VALUES("26","1","aioseop_notice_display_time_review_plugin_cta","1597999544");
INSERT INTO `wp_usermeta` VALUES("27","1","aioseop_seen_about_page","3.6.2");
INSERT INTO `wp_usermeta` VALUES("28","1","aioseop_dismissed","a:1:{s:10:\"notice-bar\";i:1596789972;}");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `wp_users` VALUES("1","aDmin","$P$Bbr4xo6Bb9ZWZZkRSTMZTazRVsJpYF.","admin","skyloft@example.com","","2020-08-07 06:09:39","","0","aDmin");


